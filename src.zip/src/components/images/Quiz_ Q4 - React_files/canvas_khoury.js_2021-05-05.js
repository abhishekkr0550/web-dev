////////////////////////////////////////////////////////////////////
//
//  Canvas Khoury Javascript file                        
//                                         
//  Updates:                                
//
//  2021-05-05 Created for the purpose of hiding Respondus LockDown Browser in Khoury Subaccount
//
////////////////////////////////////////////////////////////////////


// Remove LTI Tool from course navigation

// $('#left-side a:contains("Respondus LockDown Browser")').remove();

// Remove LTI Tool from navigation tab in course settings

// $('#nav_form li:contains("Respondus LockDown Browser")').remove();



// END