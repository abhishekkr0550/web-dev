(window["canvasWebpackJsonp"]=window["canvasWebpackJsonp"]||[]).push([[3],{sTNg:function(e,n,t){"use strict"
t.d(n,"a",(function(){return $}))
t.d(n,"c",(function(){return H}))
t.d(n,"b",(function(){return oe}))
t.d(n,"d",(function(){return b}))
var a=t("1OyB")
var r=t("vuIU")
var i=t("Ji7U")
var o=t("LK+K")
var s=t("q1tI")
var l=t.n(s)
var c=t("17x9")
var d=t.n(c)
var p=t("jtGx")
var u=d.a.node
var m=d.a.oneOf(["error","hint","success","screenreader-only"])
var b={message:d.a.shape({text:u,type:m})}
var h=t("VTBJ")
var f=t("rePB")
t("DEX3")
var g=t("TSYQ")
var v=t.n(g)
var y=t("rW8M")
var O=t("6SzX")
var j=t("pZ4s")
var k=t("J2CL")
var w=t("KgFQ")
var C=t("BTe1")
function x(e){var n=e.colors,t=e.typography
return{color:n.textDarkest,fontFamily:t.fontFamily,fontWeight:t.fontWeightBold,fontSize:t.fontSizeMedium,lineHeight:t.lineHeightFit}}x.canvas=function(e){return{color:e["ic-brand-font-color-dark"]}}
var _,A,I,E
var F={componentId:"fCrpb",template:function(e){return"\n\n.fCrpb_bGBk,.fCrpb_bGBk.fCrpb_fVUh,label.fCrpb_bGBk{all:initial;animation:none 0s ease 0s 1 normal none running;backface-visibility:visible;background:transparent none repeat 0 0/auto auto padding-box border-box scroll;border:medium none currentColor;border-collapse:separate;border-image:none;border-radius:0;border-spacing:0;bottom:auto;box-shadow:none;box-sizing:content-box;caption-side:top;clear:none;clip:auto;color:#000;column-count:auto;column-fill:balance;column-gap:normal;column-rule:medium none currentColor;column-span:1;column-width:auto;columns:auto;content:normal;counter-increment:none;counter-reset:none;cursor:auto;direction:ltr;display:inline;display:block;empty-cells:show;float:none;font-family:serif;font-size:medium;font-stretch:normal;font-style:normal;font-variant:normal;font-weight:400;height:auto;hyphens:none;left:auto;letter-spacing:normal;line-height:normal;list-style:disc outside none;margin:0;max-height:none;max-width:none;min-height:0;min-width:0;opacity:1;orphans:2;outline:medium none invert;overflow:visible;overflow-x:visible;overflow-y:visible;padding:0;page-break-after:auto;page-break-before:auto;page-break-inside:auto;perspective:none;perspective-origin:50% 50%;position:static;right:auto;tab-size:8;table-layout:auto;text-align:left;text-align-last:auto;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;top:auto;transform:none;transform-origin:50% 50% 0;transform-style:flat;transition:none 0s ease 0s;unicode-bidi:normal;vertical-align:baseline;visibility:visible;white-space:normal;widows:2;width:auto;word-spacing:normal;z-index:auto}\n\n.fCrpb_bGBk.fCrpb_fVUh{display:table;width:100%}\n\n.fCrpb_egrg,.fCrpb_egrg.fCrpb_fVUh,label.fCrpb_egrg{color:".concat(e.color||"inherit",";font-family:").concat(e.fontFamily||"inherit",";font-size:").concat(e.fontSize||"inherit",";font-weight:").concat(e.fontWeight||"inherit",";line-height:").concat(e.lineHeight||"inherit",";margin:0;text-align:inherit}\n\n[dir=ltr] .fCrpb_egrg,[dir=ltr] .fCrpb_egrg.fCrpb_fVUh,[dir=ltr] label.fCrpb_egrg,[dir=rtl] .fCrpb_egrg,[dir=rtl] .fCrpb_egrg.fCrpb_fVUh,[dir=rtl] label.fCrpb_egrg{text-align:inherit}")},root:"fCrpb_bGBk",legend:"fCrpb_fVUh","has-content":"fCrpb_egrg"}
var S=(_=Object(k["j"])(x,F),_(A=(E=I=function(e){Object(i["a"])(t,e)
var n=Object(o["a"])(t)
function t(){Object(a["a"])(this,t)
return n.apply(this,arguments)}Object(r["a"])(t,[{key:"render",value:function(){var e
var n=Object(w["a"])(t,this.props)
var a=(e={},Object(f["a"])(e,F.root,true),Object(f["a"])(e,F["has-content"],Object(y["a"])(this.props.children)),e)
return l.a.createElement(n,Object.assign({},Object(p["a"])(this.props,t.propTypes),{className:v()(a)}),this.props.children)}}])
t.displayName="FormFieldLabel"
return t}(s["Component"]),I.propTypes={as:d.a.elementType,children:d.a.node.isRequired},I.defaultProps={as:"span"},E))||A)
function T(e){var n=e.spacing
return{topMargin:n.xxSmall}}function B(e){var n=e.colors,t=e.typography
return{colorHint:n.textDarkest,colorError:n.textDanger,colorSuccess:n.textSuccess,fontFamily:t.fontFamily,fontWeight:t.fontWeightNormal,fontSize:t.fontSizeSmall,lineHeight:t.lineHeight}}B.canvas=function(e){return{colorHint:e["ic-brand-font-color-dark"]}}
var L,N,R,V
var z={componentId:"bVlfD",template:function(e){return"\n\n.bVlfD_bGBk{display:block;font-family:".concat(e.fontFamily||"inherit",";font-size:").concat(e.fontSize||"inherit",";font-weight:").concat(e.fontWeight||"inherit",";line-height:").concat(e.lineHeight||"inherit","}\n\n.bVlfD_dYYb{color:").concat(e.colorHint||"inherit","}\n\n.bVlfD_ddvR{color:").concat(e.colorError||"inherit","}\n\n.bVlfD_cOXX{color:").concat(e.colorSuccess||"inherit","}")},root:"bVlfD_bGBk",hint:"bVlfD_dYYb",error:"bVlfD_ddvR",success:"bVlfD_cOXX"}
var W=(L=Object(k["j"])(B,z),L(N=(V=R=function(e){Object(i["a"])(t,e)
var n=Object(o["a"])(t)
function t(){Object(a["a"])(this,t)
return n.apply(this,arguments)}Object(r["a"])(t,[{key:"render",value:function(){var e
var n=(e={},Object(f["a"])(e,z.root,true),Object(f["a"])(e,z[this.props.variant],true),e)
return"screenreader-only"!==this.props.variant?l.a.createElement("span",{className:v()(n)},this.props.children):l.a.createElement(O["a"],null,this.props.children)}}])
t.displayName="FormFieldMessage"
return t}(s["Component"]),R.propTypes={variant:m,children:u},R.defaultProps={variant:"hint",children:null},V))||N)
var G,D,M,J
var X={componentId:"fAfJj",template:function(e){return"\n\n.fAfJj_bGBk{margin:calc(-1*".concat(e.topMargin||"inherit",") 0 0 0;padding:0}\n\n.fAfJj_elxg,.fAfJj_bGBk{display:block}")},root:"fAfJj_bGBk",message:"fAfJj_elxg"}
var H=(G=Object(k["j"])(T,X),G(D=(J=M=function(e){Object(i["a"])(t,e)
var n=Object(o["a"])(t)
function t(){Object(a["a"])(this,t)
return n.apply(this,arguments)}Object(r["a"])(t,[{key:"render",value:function(){var e=this.props.messages
return e&&e.length>0?l.a.createElement("span",Object.assign({className:X.root},Object(p["a"])(this.props,t.propTypes)),e.map((function(e,n){return l.a.createElement("span",{key:"error".concat(n),className:X.message},l.a.createElement(W,{variant:e.type},e.text))}))):null}}])
t.displayName="FormFieldMessages"
return t}(s["Component"]),M.propTypes={messages:d.a.arrayOf(b.message)},M.defaultProps={messages:void 0},J))||D)
var P=function(){return{}}
var U,q,Y,K
var Q={componentId:"cWmNi",template:function(e){return"\n\n.cWmNi_bGBk{all:initial;animation:none 0s ease 0s 1 normal none running;backface-visibility:visible;background:transparent none repeat 0 0/auto auto padding-box border-box scroll;border:medium none currentColor;border:0;border-collapse:separate;border-image:none;border-radius:0;border-spacing:0;bottom:auto;box-shadow:none;box-sizing:content-box;caption-side:top;clear:none;clip:auto;color:#000;column-count:auto;column-fill:balance;column-gap:normal;column-rule:medium none currentColor;column-span:1;column-width:auto;columns:auto;content:normal;counter-increment:none;counter-reset:none;cursor:auto;direction:ltr;direction:inherit;display:inline;display:block;empty-cells:show;float:none;font-family:serif;font-size:medium;font-stretch:normal;font-style:normal;font-variant:normal;font-weight:400;height:auto;hyphens:none;left:auto;letter-spacing:normal;line-height:normal;list-style:disc outside none;margin:0;max-height:none;max-width:none;min-height:0;min-width:0;opacity:1;opacity:inherit;orphans:2;outline:medium none invert;overflow:visible;overflow-x:visible;overflow-y:visible;padding:0;page-break-after:auto;page-break-before:auto;page-break-inside:auto;perspective:none;perspective-origin:50% 50%;position:static;right:auto;tab-size:8;table-layout:auto;text-align:left;text-align:start;text-align-last:auto;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;top:auto;transform:none;transform-origin:50% 50% 0;transform-style:flat;transition:none 0s ease 0s;unicode-bidi:normal;vertical-align:baseline;visibility:visible;white-space:normal;widows:2;width:auto;width:100%;word-spacing:normal;z-index:auto}\n\n[dir=ltr] .cWmNi_bGBk{text-align:left}\n\n[dir=rtl] .cWmNi_bGBk{text-align:right}\n\n.cWmNi_eXrk{display:inline-block;vertical-align:middle;width:auto}"},root:"cWmNi_bGBk",inline:"cWmNi_eXrk"}
var Z=(U=Object(k["j"])(P,Q),U(q=(K=Y=function(e){Object(i["a"])(t,e)
var n=Object(o["a"])(t)
function t(e){var r
Object(a["a"])(this,t)
r=n.call(this)
r.handleInputContainerRef=function(e){r.props.inputContainerRef&&r.props.inputContainerRef(e)}
r._messagesId=e.messagesId||Object(C["a"])("FormFieldLayout-messages")
"undefined"!==typeof e.width||!e.inline||e.layout
return r}Object(r["a"])(t,[{key:"renderLabel",value:function(){return this.hasVisibleLabel?l.a.createElement(j["a"].Col,{textAlign:this.props.labelAlign,width:this.inlineContainerAndLabel?"auto":3},l.a.createElement(S,{"aria-hidden":"fieldset"===this.elementType?"true":null},this.props.label)):"fieldset"!==this.elementType?this.props.label:null}},{key:"renderLegend",value:function(){return l.a.createElement(O["a"],{as:"legend"},this.props.label,this.hasMessages&&l.a.createElement(H,{messages:this.props.messages}))}},{key:"renderMessages",value:function(){return l.a.createElement(H,{id:this._messagesId,messages:this.props.messages})}},{key:"renderVisibleMessages",value:function(){return this.hasMessages?l.a.createElement(j["a"].Row,null,l.a.createElement(j["a"].Col,{offset:this.inlineContainerAndLabel?null:3,textAlign:this.inlineContainerAndLabel?"end":null},l.a.createElement(H,{id:this._messagesId,messages:this.props.messages}))):null}},{key:"render",value:function(){var e
var n=this.elementType
var a=(e={},Object(f["a"])(e,Q.root,true),Object(f["a"])(e,Q.inline,this.props.inline),e)
return l.a.createElement(n,Object.assign({},Object(p["a"])(this.props,Object(h["a"])({},t.propTypes,{},j["a"].propTypes)),{className:v()(a),style:{width:this.props.width},"aria-describedby":this.hasMessages?this._messagesId:null}),"fieldset"===this.elementType&&this.renderLegend(),l.a.createElement(j["a"],Object.assign({rowSpacing:"small",colSpacing:"small",startAt:"inline"===this.props.layout&&this.hasVisibleLabel?"medium":null},Object(p["c"])(this.props,j["a"].propTypes)),l.a.createElement(j["a"].Row,null,this.renderLabel(),l.a.createElement(j["a"].Col,{width:this.inlineContainerAndLabel?"auto":null,elementRef:this.handleInputContainerRef},this.props.children)),this.renderVisibleMessages()))}},{key:"hasVisibleLabel",get:function(){return this.props.label&&Object(y["a"])(this.props.label)}},{key:"hasMessages",get:function(){return this.props.messages&&this.props.messages.length>0}},{key:"elementType",get:function(){return Object(w["a"])(t,this.props)}},{key:"inlineContainerAndLabel",get:function(){return this.props.inline&&"inline"===this.props.layout}}])
t.displayName="FormFieldLayout"
return t}(s["Component"]),Y.propTypes={label:d.a.node.isRequired,id:d.a.string,as:d.a.elementType,messages:d.a.arrayOf(b.message),messagesId:d.a.string,children:d.a.node,inline:d.a.bool,layout:d.a.oneOf(["stacked","inline"]),labelAlign:d.a.oneOf(["start","end"]),width:d.a.string,inputContainerRef:d.a.func},Y.defaultProps={id:void 0,width:void 0,messages:void 0,messagesId:void 0,children:null,inline:false,layout:"stacked",as:"label",labelAlign:"end",inputContainerRef:void 0},K))||q)
var $=function(e){Object(i["a"])(t,e)
var n=Object(o["a"])(t)
function t(){Object(a["a"])(this,t)
return n.apply(this,arguments)}Object(r["a"])(t,[{key:"render",value:function(){return l.a.createElement(Z,Object.assign({},Object(p["a"])(this.props,t.propTypes),Object(p["c"])(this.props,Z.propTypes),{vAlign:this.props.vAlign,as:"label",htmlFor:this.props.id}))}}])
t.displayName="FormField"
return t}(s["Component"])
$.propTypes={label:d.a.node.isRequired,id:d.a.string.isRequired,messages:d.a.arrayOf(b.message),messagesId:d.a.string,children:d.a.node,inline:d.a.bool,layout:d.a.oneOf(["stacked","inline"]),labelAlign:d.a.oneOf(["start","end"]),vAlign:d.a.oneOf(["top","middle","bottom"]),width:d.a.string,inputContainerRef:d.a.func}
$.defaultProps={inline:false,layout:"stacked",labelAlign:"end",vAlign:"middle",messages:void 0,messagesId:void 0,children:null,width:void 0,inputContainerRef:void 0}
var ee=function(e){var n=e.borders,t=e.colors,a=e.spacing
return{borderWidth:n.widthSmall,borderStyle:n.style,borderColor:"transparent",borderRadius:n.radiusMedium,errorBorderColor:t.borderDanger,errorFieldsPadding:a.xSmall}}
var ne,te,ae,re
var ie={componentId:"efIdg",template:function(e){return"\n\n.efIdg_cLpc{border:".concat(e.borderWidth||"inherit"," ").concat(e.borderStyle||"inherit"," ").concat(e.borderColor||"inherit",";border-radius:").concat(e.borderRadius||"inherit",";display:block}\n\n.efIdg_cLpc.efIdg_fszt{border-color:").concat(e.errorBorderColor||"inherit",";padding:").concat(e.errorFieldsPadding||"inherit","}\n\n.efIdg_cLpc.efIdg_ywdX{cursor:not-allowed;opacity:0.6;pointer-events:none}")},fields:"efIdg_cLpc",invalid:"efIdg_fszt",disabled:"efIdg_ywdX"}
var oe=(ne=Object(k["j"])(ee,ie),ne(te=(re=ae=function(e){Object(i["a"])(t,e)
var n=Object(o["a"])(t)
function t(){Object(a["a"])(this,t)
return n.apply(this,arguments)}Object(r["a"])(t,[{key:"renderColumns",value:function(){return s["Children"].map(this.props.children,(function(e,n){return e?l.a.createElement(j["a"].Col,{width:e.props&&e.props.width?"auto":null,key:n},e):null}))}},{key:"renderChildren",value:function(){return l.a.createElement(j["a"],{colSpacing:this.props.colSpacing,rowSpacing:this.props.rowSpacing,vAlign:this.props.vAlign,startAt:this.props.startAt||("columns"===this.props.layout?"medium":null)},l.a.createElement(j["a"].Row,null,this.renderColumns()))}},{key:"renderFields",value:function(){var e
return l.a.createElement("span",{key:"fields",className:v()((e={},Object(f["a"])(e,ie.fields,true),Object(f["a"])(e,ie.invalid,this.invalid),Object(f["a"])(e,ie.disabled,this.props.disabled),e))},this.renderChildren())}},{key:"render",value:function(){return l.a.createElement(Z,Object.assign({},Object(p["a"])(this.props,t.propTypes),Object(p["c"])(this.props,Z.propTypes),{vAlign:this.props.vAlign,layout:"inline"===this.props.layout?"inline":"stacked",label:this.props.description,"aria-disabled":this.props.disabled?"true":null,"aria-invalid":this.invalid?"true":null}),this.renderFields())}},{key:"invalid",get:function(){return this.props.messages&&this.props.messages.findIndex((function(e){return"error"===e.type}))>=0}}])
t.displayName="FormFieldGroup"
return t}(s["Component"]),ae.propTypes={description:d.a.node.isRequired,as:d.a.elementType,messages:d.a.arrayOf(b.message),messagesId:d.a.string,disabled:d.a.bool,children:d.a.node,layout:d.a.oneOf(["stacked","columns","inline"]),rowSpacing:d.a.oneOf(["none","small","medium","large"]),colSpacing:d.a.oneOf(["none","small","medium","large"]),vAlign:d.a.oneOf(["top","middle","bottom"]),startAt:d.a.oneOf(["small","medium","large","x-large",null])},ae.defaultProps={children:null,layout:void 0,startAt:void 0,messages:void 0,messagesId:void 0,as:"fieldset",disabled:false,rowSpacing:"medium",colSpacing:"small",vAlign:"middle"},re))||te)}}])

//# sourceMappingURL=3-c-d9d3e4a39c.js.map