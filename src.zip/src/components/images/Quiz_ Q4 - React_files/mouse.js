"use strict";
eesy.define([], function () {
    return {
        x: 0,
        y: 0,
        lastelement: undefined,
        lasturl: undefined,
        hintmode: false
    };
});
//# sourceMappingURL=mouse.js.map