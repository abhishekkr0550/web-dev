(window["canvasWebpackJsonp"]=window["canvasWebpackJsonp"]||[]).push([[41],{"+XDm":function(e,t,i){var n=i("JPst")
var o=i("HeW1")
var a=i("uCtj")
var r=i("ldnB")
var s=i("md8m")
var l=i("gopi")
var d=i("EnmO")
var u=i("4NNp")
var c=i("elqR")
var m=i("tSde")
t=n(false)
var p=o(a)
var f=o(r)
var h=o(s)
var g=o(l)
var b=o(d)
var v=o(u)
var y=o(c)
var j=o(m)
t.push([e.i,".mejs-offscreen{clip:rect(1px 1px 1px 1px);clip:rect(1px,1px,1px,1px);clip-path:polygon(0px 0,0 0,0 0,0 0);position:absolute!important;height:1px;width:1px;overflow:hidden}.mejs-container{position:relative;background:#000;font-family:Helvetica,Arial,serif;text-align:left;vertical-align:top;text-indent:0}.mejs-fill-container,.mejs-fill-container .mejs-container{width:100%;height:100%}.mejs-fill-container{overflow:hidden}.mejs-container:focus{outline:0}.me-plugin{position:absolute}.mejs-embed,.mejs-embed body{width:100%;height:100%;margin:0;padding:0;background:#000;overflow:hidden}.mejs-fullscreen{overflow:hidden!important}.mejs-container-fullscreen{position:fixed;left:0;top:0;right:0;bottom:0;overflow:hidden;z-index:1000}.mejs-container-fullscreen .mejs-mediaelement,.mejs-container-fullscreen video{width:100%;height:100%}.mejs-clear{clear:both}.mejs-background{position:absolute;top:0;left:0}.mejs-mediaelement{position:absolute;top:0;left:0;width:100%;height:100%}.mejs-poster{position:absolute;top:0;left:0;background-size:contain;background-position:50% 50%;background-repeat:no-repeat}:root .mejs-poster img{display:none}.mejs-poster img{border:0;padding:0}.mejs-overlay{position:absolute;top:0;left:0}.mejs-overlay-play{cursor:pointer}.mejs-overlay-button{position:absolute;top:50%;left:50%;width:100px;height:100px;margin:-50px 0 0 -50px;background:url("+p+") no-repeat}.no-svg .mejs-overlay-button{background-image:url("+f+")}.mejs-overlay:hover .mejs-overlay-button{background-position:0 -100px}.mejs-overlay-loading{position:absolute;top:50%;left:50%;width:80px;height:80px;margin:-40px 0 0 -40px;background:#333;background:url("+h+");background:rgba(0,0,0,.9);background:-webkit-gradient(linear,0 0,0 100%,from(rgba(50,50,50,.9)),to(rgba(0,0,0,.9)));background:-webkit-linear-gradient(top,rgba(50,50,50,.9),rgba(0,0,0,.9));background:-moz-linear-gradient(top,rgba(50,50,50,.9),rgba(0,0,0,.9));background:-o-linear-gradient(top,rgba(50,50,50,.9),rgba(0,0,0,.9));background:-ms-linear-gradient(top,rgba(50,50,50,.9),rgba(0,0,0,.9));background:linear-gradient(rgba(50,50,50,.9),rgba(0,0,0,.9))}.mejs-overlay-loading span{display:block;width:80px;height:80px;background:transparent url("+g+") 50% 50% no-repeat}.mejs-container .mejs-controls{position:absolute;list-style-type:none;margin:0;padding:0;bottom:0;left:0;background:url("+h+");background:rgba(0,0,0,.7);background:-webkit-gradient(linear,0 0,0 100%,from(rgba(50,50,50,.7)),to(rgba(0,0,0,.7)));background:-webkit-linear-gradient(top,rgba(50,50,50,.7),rgba(0,0,0,.7));background:-moz-linear-gradient(top,rgba(50,50,50,.7),rgba(0,0,0,.7));background:-o-linear-gradient(top,rgba(50,50,50,.7),rgba(0,0,0,.7));background:-ms-linear-gradient(top,rgba(50,50,50,.7),rgba(0,0,0,.7));background:linear-gradient(rgba(50,50,50,.7),rgba(0,0,0,.7));height:30px;width:100%}.mejs-container .mejs-controls div{list-style-type:none;background-image:none;display:block;float:left;margin:0;padding:0;width:26px;height:26px;font-size:11px;line-height:11px;font-family:Helvetica,Arial,serif;border:0}.mejs-controls .mejs-button button{cursor:pointer;display:block;font-size:0;line-height:0;text-decoration:none;margin:7px 5px;padding:0;position:absolute;height:16px;width:16px;border:0;background:transparent url("+b+") no-repeat}.no-svg .mejs-controls .mejs-button button{background-image:url("+v+")}.mejs-controls .mejs-button button:focus{outline:dotted 1px #999}.mejs-container .mejs-controls .mejs-time{color:#fff;display:block;height:17px;width:auto;padding:10px 3px 0;overflow:hidden;text-align:center;-moz-box-sizing:content-box;-webkit-box-sizing:content-box;box-sizing:content-box}.mejs-container .mejs-controls .mejs-time a{color:#fff;font-size:11px;line-height:12px;display:block;float:left;margin:1px 2px 0 0;width:auto}.mejs-controls .mejs-play button{background-position:0 0}.mejs-controls .mejs-pause button{background-position:0 -16px}.mejs-controls .mejs-stop button{background-position:-112px 0}.mejs-controls div.mejs-time-rail{direction:ltr;width:200px;padding-top:5px}.mejs-controls .mejs-time-rail span,.mejs-controls .mejs-time-rail a{display:block;position:absolute;width:180px;height:10px;-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px;cursor:pointer}.mejs-controls .mejs-time-rail .mejs-time-total{margin:5px;background:#333;background:rgba(50,50,50,.8);background:-webkit-gradient(linear,0 0,0 100%,from(rgba(30,30,30,.8)),to(rgba(60,60,60,.8)));background:-webkit-linear-gradient(top,rgba(30,30,30,.8),rgba(60,60,60,.8));background:-moz-linear-gradient(top,rgba(30,30,30,.8),rgba(60,60,60,.8));background:-o-linear-gradient(top,rgba(30,30,30,.8),rgba(60,60,60,.8));background:-ms-linear-gradient(top,rgba(30,30,30,.8),rgba(60,60,60,.8));background:linear-gradient(rgba(30,30,30,.8),rgba(60,60,60,.8))}.mejs-controls .mejs-time-rail .mejs-time-buffering{width:100%;background-image:-o-linear-gradient(-45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:-webkit-gradient(linear,0 100%,100% 0,color-stop(0.25,rgba(255,255,255,.15)),color-stop(0.25,transparent),color-stop(0.5,transparent),color-stop(0.5,rgba(255,255,255,.15)),color-stop(0.75,rgba(255,255,255,.15)),color-stop(0.75,transparent),to(transparent));background-image:-webkit-linear-gradient(-45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:-moz-linear-gradient(-45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:-ms-linear-gradient(-45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:linear-gradient(-45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);-webkit-background-size:15px 15px;-moz-background-size:15px 15px;-o-background-size:15px 15px;background-size:15px 15px;-webkit-animation:buffering-stripes 2s linear infinite;-moz-animation:buffering-stripes 2s linear infinite;-ms-animation:buffering-stripes 2s linear infinite;-o-animation:buffering-stripes 2s linear infinite;animation:buffering-stripes 2s linear infinite}@-webkit-keyframes buffering-stripes{from{background-position:0 0}to{background-position:30px 0}}@-moz-keyframes buffering-stripes{from{background-position:0 0}to{background-position:30px 0}}@-ms-keyframes buffering-stripes{from{background-position:0 0}to{background-position:30px 0}}@-o-keyframes buffering-stripes{from{background-position:0 0}to{background-position:30px 0}}@keyframes buffering-stripes{from{background-position:0 0}to{background-position:30px 0}}.mejs-controls .mejs-time-rail .mejs-time-loaded{background:#3caac8;background:rgba(60,170,200,.8);background:-webkit-gradient(linear,0 0,0 100%,from(rgba(44,124,145,.8)),to(rgba(78,183,212,.8)));background:-webkit-linear-gradient(top,rgba(44,124,145,.8),rgba(78,183,212,.8));background:-moz-linear-gradient(top,rgba(44,124,145,.8),rgba(78,183,212,.8));background:-o-linear-gradient(top,rgba(44,124,145,.8),rgba(78,183,212,.8));background:-ms-linear-gradient(top,rgba(44,124,145,.8),rgba(78,183,212,.8));background:linear-gradient(rgba(44,124,145,.8),rgba(78,183,212,.8));width:0}.mejs-controls .mejs-time-rail .mejs-time-current{background:#fff;background:rgba(255,255,255,.8);background:-webkit-gradient(linear,0 0,0 100%,from(rgba(255,255,255,.9)),to(rgba(200,200,200,.8)));background:-webkit-linear-gradient(top,rgba(255,255,255,.9),rgba(200,200,200,.8));background:-moz-linear-gradient(top,rgba(255,255,255,.9),rgba(200,200,200,.8));background:-o-linear-gradient(top,rgba(255,255,255,.9),rgba(200,200,200,.8));background:-ms-linear-gradient(top,rgba(255,255,255,.9),rgba(200,200,200,.8));background:linear-gradient(rgba(255,255,255,.9),rgba(200,200,200,.8));width:0}.mejs-controls .mejs-time-rail .mejs-time-handle{display:none;position:absolute;margin:0;width:10px;background:#fff;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;cursor:pointer;border:solid 2px #333;top:-2px;text-align:center}.mejs-controls .mejs-time-rail .mejs-time-float{position:absolute;display:none;background:#eee;width:36px;height:17px;border:solid 1px #333;top:-26px;margin-left:-18px;text-align:center;color:#111}.mejs-controls .mejs-time-rail .mejs-time-float-current{margin:2px;width:30px;display:block;text-align:center;left:0}.mejs-controls .mejs-time-rail .mejs-time-float-corner{position:absolute;display:block;width:0;height:0;line-height:0;border:solid 5px #eee;border-color:#eee transparent transparent;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0;top:15px;left:13px}.mejs-long-video .mejs-controls .mejs-time-rail .mejs-time-float{width:48px}.mejs-long-video .mejs-controls .mejs-time-rail .mejs-time-float-current{width:44px}.mejs-long-video .mejs-controls .mejs-time-rail .mejs-time-float-corner{left:18px}.mejs-controls .mejs-fullscreen-button button{background-position:-32px 0}.mejs-controls .mejs-unfullscreen button{background-position:-32px -16px}.mejs-controls .mejs-volume-button{}.mejs-controls .mejs-mute button{background-position:-16px -16px}.mejs-controls .mejs-unmute button{background-position:-16px 0}.mejs-controls .mejs-volume-button{position:relative}.mejs-controls .mejs-volume-button .mejs-volume-slider{height:115px;width:25px;background:url("+h+");background:rgba(50,50,50,.7);-webkit-border-radius:0;-moz-border-radius:0;border-radius:0;top:-115px;left:0;z-index:1;position:absolute;margin:0}.mejs-controls .mejs-volume-button:hover{-webkit-border-radius:0 0 4px 4px;-moz-border-radius:0 0 4px 4px;border-radius:0 0 4px 4px}.mejs-controls .mejs-volume-button .mejs-volume-slider .mejs-volume-total{position:absolute;left:11px;top:8px;width:2px;height:100px;background:#ddd;background:rgba(255,255,255,.5);margin:0}.mejs-controls .mejs-volume-button .mejs-volume-slider .mejs-volume-current{position:absolute;left:11px;top:8px;width:2px;height:100px;background:#ddd;background:rgba(255,255,255,.9);margin:0}.mejs-controls .mejs-volume-button .mejs-volume-slider .mejs-volume-handle{position:absolute;left:4px;top:-3px;width:16px;height:6px;background:#ddd;background:rgba(255,255,255,.9);cursor:N-resize;-webkit-border-radius:1px;-moz-border-radius:1px;border-radius:1px;margin:0}.mejs-controls a.mejs-horizontal-volume-slider{height:26px;width:56px;position:relative;display:block;float:left;vertical-align:middle}.mejs-controls .mejs-horizontal-volume-slider .mejs-horizontal-volume-total{position:absolute;left:0;top:11px;width:50px;height:8px;margin:0;padding:0;font-size:1px;-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px;background:#333;background:rgba(50,50,50,.8);background:-webkit-gradient(linear,0 0,0 100%,from(rgba(30,30,30,.8)),to(rgba(60,60,60,.8)));background:-webkit-linear-gradient(top,rgba(30,30,30,.8),rgba(60,60,60,.8));background:-moz-linear-gradient(top,rgba(30,30,30,.8),rgba(60,60,60,.8));background:-o-linear-gradient(top,rgba(30,30,30,.8),rgba(60,60,60,.8));background:-ms-linear-gradient(top,rgba(30,30,30,.8),rgba(60,60,60,.8));background:linear-gradient(rgba(30,30,30,.8),rgba(60,60,60,.8))}.mejs-controls .mejs-horizontal-volume-slider .mejs-horizontal-volume-current{position:absolute;left:0;top:11px;width:50px;height:8px;margin:0;padding:0;font-size:1px;-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px;background:#fff;background:rgba(255,255,255,.8);background:-webkit-gradient(linear,0 0,0 100%,from(rgba(255,255,255,.9)),to(rgba(200,200,200,.8)));background:-webkit-linear-gradient(top,rgba(255,255,255,.9),rgba(200,200,200,.8));background:-moz-linear-gradient(top,rgba(255,255,255,.9),rgba(200,200,200,.8));background:-o-linear-gradient(top,rgba(255,255,255,.9),rgba(200,200,200,.8));background:-ms-linear-gradient(top,rgba(255,255,255,.9),rgba(200,200,200,.8));background:linear-gradient(rgba(255,255,255,.9),rgba(200,200,200,.8))}.mejs-controls .mejs-horizontal-volume-slider .mejs-horizontal-volume-handle{display:none}.mejs-controls .mejs-captions-button{position:relative}.mejs-controls .mejs-captions-button button{background-position:-48px 0}.mejs-controls .mejs-captions-button .mejs-captions-selector{position:absolute;bottom:26px;right:-51px;width:85px;height:100px;background:url("+h+");background:rgba(50,50,50,.7);border:solid 1px transparent;padding:10px 10px 0;overflow:hidden;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.mejs-controls .mejs-captions-button .mejs-captions-selector ul{margin:0;padding:0;display:block;list-style-type:none!important;overflow:hidden}.mejs-controls .mejs-captions-button .mejs-captions-selector ul li{margin:0 0 6px;padding:0;list-style-type:none!important;display:block;color:#fff;overflow:hidden}.mejs-controls .mejs-captions-button .mejs-captions-selector ul li input{clear:both;float:left;margin:3px 3px 0 5px}.mejs-controls .mejs-captions-button .mejs-captions-selector ul li label{width:55px;float:left;padding:4px 0 0;line-height:15px;font-family:Helvetica,Arial,serif;font-size:10px}.mejs-controls .mejs-captions-button .mejs-captions-translations{font-size:10px;margin:0 0 5px}.mejs-chapters{position:absolute;top:0;left:0;border-right:solid 1px #fff;width:10000px;z-index:1}.mejs-chapters .mejs-chapter{position:absolute;float:left;background:#222;background:rgba(0,0,0,.7);background:-webkit-gradient(linear,0 0,0 100%,from(rgba(50,50,50,.7)),to(rgba(0,0,0,.7)));background:-webkit-linear-gradient(top,rgba(50,50,50,.7),rgba(0,0,0,.7));background:-moz-linear-gradient(top,rgba(50,50,50,.7),rgba(0,0,0,.7));background:-o-linear-gradient(top,rgba(50,50,50,.7),rgba(0,0,0,.7));background:-ms-linear-gradient(top,rgba(50,50,50,.7),rgba(0,0,0,.7));background:linear-gradient(rgba(50,50,50,.7),rgba(0,0,0,.7));filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, startColorstr=#323232, endColorstr=#000000);overflow:hidden;border:0}.mejs-chapters .mejs-chapter .mejs-chapter-block{font-size:11px;color:#fff;padding:5px;display:block;border-right:solid 1px #333;border-bottom:solid 1px #333;cursor:pointer}.mejs-chapters .mejs-chapter .mejs-chapter-block-last{border-right:0}.mejs-chapters .mejs-chapter .mejs-chapter-block:hover{background:#666;background:rgba(102,102,102,.7);background:-webkit-gradient(linear,0 0,0 100%,from(rgba(102,102,102,.7)),to(rgba(50,50,50,.6)));background:-webkit-linear-gradient(top,rgba(102,102,102,.7),rgba(50,50,50,.6));background:-moz-linear-gradient(top,rgba(102,102,102,.7),rgba(50,50,50,.6));background:-o-linear-gradient(top,rgba(102,102,102,.7),rgba(50,50,50,.6));background:-ms-linear-gradient(top,rgba(102,102,102,.7),rgba(50,50,50,.6));background:linear-gradient(rgba(102,102,102,.7),rgba(50,50,50,.6));filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, startColorstr=#666666, endColorstr=#323232)}.mejs-chapters .mejs-chapter .mejs-chapter-block .ch-title{font-size:12px;font-weight:700;display:block;white-space:nowrap;text-overflow:ellipsis;margin:0 0 3px;line-height:12px}.mejs-chapters .mejs-chapter .mejs-chapter-block .ch-timespan{font-size:12px;line-height:12px;margin:3px 0 4px;display:block;white-space:nowrap;text-overflow:ellipsis}.mejs-captions-layer{position:absolute;bottom:0;left:0;text-align:center;line-height:20px;font-size:16px;color:#fff}.mejs-captions-layer a{color:#fff;text-decoration:underline}.mejs-captions-layer[lang=ar]{font-size:20px;font-weight:400}.mejs-captions-position{position:absolute;width:100%;bottom:15px;left:0}.mejs-captions-position-hover{bottom:35px}.mejs-captions-text,.mejs__captions-text *{padding:0;background:url("+h+");background:rgba(20,20,20,.5);white-space:pre-wrap;-webkit-box-shadow:5px 0 0 rgba(20,20,20,.5),-5px 0 0 rgba(20,20,20,.5);box-shadow:5px 0 0 rgba(20,20,20,.5),-5px 0 0 rgba(20,20,20,.5)}.me-cannotplay{}.me-cannotplay a{color:#fff;font-weight:700}.me-cannotplay span{padding:15px;display:block}.mejs-controls .mejs-loop-off button{background-position:-64px -16px}.mejs-controls .mejs-loop-on button{background-position:-64px 0}.mejs-controls .mejs-backlight-off button{background-position:-80px -16px}.mejs-controls .mejs-backlight-on button{background-position:-80px 0}.mejs-controls .mejs-picturecontrols-button{background-position:-96px 0}.mejs-contextmenu{position:absolute;width:150px;padding:10px;border-radius:4px;top:0;left:0;background:#fff;border:solid 1px #999;z-index:1001}.mejs-contextmenu .mejs-contextmenu-separator{height:1px;font-size:0;margin:5px 6px;background:#333}.mejs-contextmenu .mejs-contextmenu-item{font-family:Helvetica,Arial,serif;font-size:12px;padding:4px 6px;cursor:pointer;color:#333}.mejs-contextmenu .mejs-contextmenu-item:hover{background:#2C7C91;color:#fff}.mejs-controls .mejs-sourcechooser-button{position:relative}.mejs-controls .mejs-sourcechooser-button button{background-position:-128px 0}.mejs-controls .mejs-sourcechooser-button .mejs-sourcechooser-selector{position:absolute;bottom:26px;right:-10px;width:130px;height:100px;background:url("+h+");background:rgba(50,50,50,.7);border:solid 1px transparent;padding:10px;overflow:hidden;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.mejs-controls .mejs-sourcechooser-button .mejs-sourcechooser-selector ul{margin:0;padding:0;display:block;list-style-type:none!important;overflow:hidden}.mejs-controls .mejs-sourcechooser-button .mejs-sourcechooser-selector ul li{margin:0 0 6px;padding:0;list-style-type:none!important;display:block;color:#fff;overflow:hidden}.mejs-controls .mejs-sourcechooser-button .mejs-sourcechooser-selector ul li input{clear:both;float:left;margin:3px 3px 0 5px}.mejs-controls .mejs-sourcechooser-button .mejs-sourcechooser-selector ul li label{width:100px;float:left;padding:4px 0 0;line-height:15px;font-family:Helvetica,Arial,serif;font-size:10px}.mejs-postroll-layer{position:absolute;bottom:0;left:0;width:100%;height:100%;background:url("+h+");background:rgba(50,50,50,.7);z-index:1000;overflow:hidden}.mejs-postroll-layer-content{width:100%;height:100%}.mejs-postroll-close{position:absolute;right:0;top:0;background:url("+h+");background:rgba(50,50,50,.7);color:#fff;padding:4px;z-index:100;cursor:pointer}div.mejs-speed-button{width:46px!important;position:relative}.mejs-controls .mejs-button.mejs-speed-button button{background:transparent;width:36px;font-size:11px;line-height:normal;color:#fff}.mejs-controls .mejs-speed-button .mejs-speed-selector{position:absolute;top:-100px;left:-10px;width:60px;height:100px;background:url("+h+");background:rgba(50,50,50,.7);border:solid 1px transparent;padding:0;overflow:hidden;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.mejs-controls .mejs-speed-button .mejs-speed-selector ul li label.mejs-speed-selected{color:rgba(33,248,248,1)}.mejs-controls .mejs-speed-button .mejs-speed-selector ul{margin:0;padding:0;display:block;list-style-type:none!important;overflow:hidden}.mejs-controls .mejs-speed-button .mejs-speed-selector ul li{margin:0 0 6px;padding:0 10px;list-style-type:none!important;display:block;color:#fff;overflow:hidden}.mejs-controls .mejs-speed-button .mejs-speed-selector ul li input{clear:both;float:left;margin:3px 3px 0 5px}.mejs-controls .mejs-speed-button .mejs-speed-selector ul li label{width:60px;float:left;padding:4px 0 0;line-height:15px;font-family:Helvetica,Arial,serif;font-size:11px;color:#fff;margin-left:5px;cursor:pointer}.mejs-controls .mejs-speed-button .mejs-speed-selector ul li:hover{background-color:#c8c8c8!important;background-color:rgba(255,255,255,.4)!important}.mejs-controls .mejs-button.mejs-jump-forward-button{background:transparent url("+y+") no-repeat 3px 3px}.mejs-controls .mejs-button.mejs-jump-forward-button button{background:transparent;font-size:9px;line-height:normal;color:#fff}.mejs-controls .mejs-button.mejs-skip-back-button{background:transparent url("+j+") no-repeat 3px 3px}.mejs-controls .mejs-button.mejs-skip-back-button button{background:transparent;font-size:9px;line-height:normal;color:#fff}",""])
e.exports=t},"/oRJ":function(e,t,i){"use strict"
i.d(t,"a",(function(){return n}))
function n(e){const t="about:blank"
try{const i=new URL(e,window.location.origin)
if("javascript:"===i.protocol)return t
return e}catch(e){return t}}},"4NNp":function(e,t,i){e.exports=i.p+"24a0227fbdd3acfd86ff03fc3fc6c8a4.png"},"4fRt":function(e,t,i){"use strict"
var n=i("HGxv")
var o=n["default"].scoped("jquery_media_comments")
var a=i("Y/W1")
var r=i.n(a)
var s=i("XKWA")
var l=i.n(s)
var d=i("U4Vp")
var u=i("ouhR")
var c=i.n(u)
const m={ENTER:13,ESC:27,SPACE:32,LEFT:37,UP:38,RIGHT:39,DOWN:40,PAGE_UP:33,PAGE_DOWN:34,M:77,F:70,G_REWIND:227,G_FORWARD:228}
const p={captions:".mejs-captions-button",fullscreen:".mejs-fullscreen-button",playpause:".mejs-playpause-button",progress:".mejs-time-rail",source:".mejs-sourcechooser-button",speed:".mejs-speed-button",volume:".mejs-volume-button"}
function f(e,t){const i=e.filter(t).first()
const n=e.index(i)
return n<0?0:n}function h(e,t,i,n){this.player=t
this.media=i
this.event=n
this.keyCode=n.keyCode
this.isFullScreen=e.MediaFeatures.hasTrueNativeFullScreen&&e.MediaFeatures.isFullScreen()||t.isFullScreen
this.isFirefox=e.MediaFeatures.isFirefox}h.keyCodes=m
h.prototype._targetControl=function(e){return c()(this.event.target).closest(e)}
h.prototype.handlerKey=function(){const e=Object.keys(p).find(e=>this._targetControl(p[e]).length)
return e||"player"}
h.prototype.dispatch=function(){this.event.preventDefault()
const e=this.handlerKey()+"Handler"
this[e]()}
h.prototype.captionsHandler=function(){let e
const{player:t,event:i}=this
const n=c()(t.captionsButton).find(".mejs-captions-selector input[type=radio]")
const o=f(n,(e,i)=>"none"===i.value&&null==t.selectedTrack||t.selectedTrack&&i.value===t.selectedTrack.srclang)
switch(this.keyCode){case m.DOWN:e=Math.min(o+1,n.length-1)
n.slice(e).first().focus().click()
break
case m.UP:e=Math.max(o-1,0)
n.slice(e).first().focus().click()
break
case m.ENTER:"a"===i.target.tagName.toLowerCase()&&c()(i.target)[0].click()}}
h.prototype.fullscreenHandler=function(){const{player:e,event:t}=this
switch(this.keyCode){case m.SPACE:if(this.isFirefox)break
case m.ENTER:c()(t.target)[0].click()
break
case m.ESC:this.isFullScreen&&e.exitFullScreen()}}
h.prototype.playpauseHandler=function(){const{player:e,media:t}=this
let i
switch(this.keyCode){case m.LEFT:case m.DOWN:case m.G_REWIND:i=Math.max(t.currentTime-e.options.defaultSeekBackwardInterval(t),0)
t.setCurrentTime(i)
break
case m.RIGHT:case m.UP:case m.G_FORWARD:i=Math.min(t.currentTime+e.options.defaultSeekForwardInterval(t),t.duration)
t.setCurrentTime(i)
break
case m.PAGE_DOWN:i=Math.max(t.currentTime-e.options.defaultJumpBackwardInterval(t),0)
t.setCurrentTime(i)
break
case m.PAGE_UP:i=Math.min(t.currentTime+e.options.defaultJumpForwardInterval(t),t.duration)
t.setCurrentTime(i)
break
case m.SPACE:if(this.isFirefox)break
case m.ENTER:t.paused?t.play():t.pause()}}
h.prototype.progressHandler=function(){}
h.prototype.sourceHandler=function(){let e
const{player:t}=this
const i=c()(t.sourcechooserButton).find(".mejs-sourcechooser-selector input[type=radio]")
const n=f(i,(e,i)=>i.value===t.media.src)
switch(this.keyCode){case m.DOWN:e=Math.min(n+1,i.length-1)
i.slice(e).first().focus().click()
break
case m.UP:e=Math.max(n-1,0)
i.slice(e).first().focus().click()}}
h.prototype.speedHandler=function(){let e
const{player:t}=this
const i=c()(t.speedButton).find(".mejs-speed-selector input[type=radio]")
const n=f(i,(e,i)=>parseFloat(i.value)===t.media.playbackRate)
switch(this.keyCode){case m.DOWN:e=Math.min(n+1,i.length-1)
i.slice(e).first().focus().click()
break
case m.UP:e=Math.max(n-1,0)
i.slice(e).first().focus().click()}}
h.prototype.volumeHandler=function(){const{player:e,media:t}=this
let i
switch(this.keyCode){case m.SPACE:if(this.isFirefox)break
case m.ENTER:e.setMuted(!e.media.muted)
break
case m.LEFT:i=Math.max(0,t.volume-.1)
t.setVolume(i)
break
case m.RIGHT:i=Math.min(t.volume+.1,1)
t.setVolume(i)
break
case m.PAGE_DOWN:i=Math.max(0,t.volume-.5)
t.setVolume(i)
break
case m.PAGE_UP:i=Math.min(t.volume+.5,1)
t.setVolume(i)}}
h.prototype.playerHandler=function(){const{player:e,media:t,event:i}=this
let n
let o
switch(this.keyCode){case m.LEFT:case m.G_REWIND:n=Math.max(t.currentTime-e.options.defaultSeekBackwardInterval(t),0)
t.setCurrentTime(n)
break
case m.RIGHT:case m.G_FORWARD:n=Math.min(t.currentTime+e.options.defaultSeekForwardInterval(t),t.duration)
t.setCurrentTime(n)
break
case m.PAGE_DOWN:n=Math.max(t.currentTime-e.options.defaultJumpBackwardInterval(t),0)
t.setCurrentTime(n)
break
case m.PAGE_UP:n=Math.min(t.currentTime+e.options.defaultJumpForwardInterval(t),t.duration)
t.setCurrentTime(n)
break
case m.F:c()(i.target).find(".mejs-fullscreen-button > button")[0].click()
break
case m.UP:o=t.volume
t.setVolume(Math.min(o+.1,1))
break
case m.DOWN:o=t.volume
t.setVolume(Math.max(0,o-.1))
break
case m.M:e.setMuted(!e.media.muted)
break
case m.SPACE:if(this.isFirefox)break
case m.ENTER:t.paused?t.play():t.pause()}}
var g=h
var b=i("gI0r")
var v=i("/oRJ")
const y={getElement(e,t,i,n){const o="video"===e?` width="${i}" height="${n}"`:""
const a=`<${e} ${o} preload="metadata" controls>${t}</${e}>`
return c()(a)}}
const j=550
const k=448
c.a.extend(d["a"].MediaElementDefaults,{pluginPath:"/images/mediaelement/",defaultVideoWidth:j,defaultVideoHeight:k})
d["a"].MepDefaults.success=function(e,t){i.e(4279).then(i.bind(null,"eTZi")).then(({default:t})=>{t(this.mediaCommentId,e,INST.kalturaSettings)})
return e.play()}
d["a"].MepDefaults.features.push("googleanalytics")
const w=d["a"].MepDefaults.features.indexOf("tracks")+1
d["a"].MepDefaults.features.splice(w,0,"sourcechooser")
d["a"].MepDefaults.features.splice(w,0,"speed")
function x(e){const t=new c.a.Deferred
c.a.getJSON(`/media_objects/${e}/info`,e=>{const i=e.media_sources.filter(e=>"audio/mp3"!==e.content_type).sort((e,t)=>parseInt(e.bitrate,10)-parseInt(t.bitrate,10)).map(e=>`<source\n            type='${Object(b["a"])(e.content_type)}'\n            src='${Object(v["a"])(Object(b["a"])(e.url))}'\n            title='${Object(b["a"])(e.width)}x${Object(b["a"])(e.height)} ${Object(b["a"])(Math.floor(e.bitrate/1024))} kbps'\n          />`)
const n=r.a.map(e.media_tracks,e=>{const t=d["a"].language.codes[e.locale]||e.locale
return`<track kind='${Object(b["a"])(e.kind)}' label='${Object(b["a"])(t)}' src='${Object(b["a"])(e.url)}' srclang='${Object(b["a"])(e.locale)}' />`})
const o=r.a.map(e.media_sources,e=>e.content_type)
return t.resolve({sources:i,tracks:n,types:o,can_add_captions:e.can_add_captions})})
return t}function T({sourcesAndTracks:e,mediaType:t,height:i,width:n,mediaPlayerOptions:o}){let a="video"===t?"video":"audio"
const r=e.sources.concat(e.tracks).join("")
function s(){const e=c.a.extend({mode:"auto"},d["a"].MediaElementDefaults,d["a"].MepDefaults,o)
const t=y.getElement("audio",r)
const i=d["a"].HtmlMediaElementShim.determinePlayback(t[0],e,d["a"].MediaFeatures.supportsMediaTag,true,null)
return"native"!==i.method}if("audio"===t&&e.types[0].match(/^video\//)&&s()){a="video"
o.mode="auto_plugin"
o.isVideo=false
o.videoHeight=i=30}return y.getElement(a,r,n,i)}const _={create(e,t,i,n){c()("#media_recorder_container").removeAttr("id")
this.attr("id","media_recorder_container")
l.a.unsubscribe("media_comment_created")
l.a.subscribe("media_comment_created",e=>t(e.id,e.mediaType,e.title))
const o={modal:false,defaultTitle:n}
c.a.isFunction(i)&&(o.close=i.bind(this))
return c.a.mediaComment.init(e,o)},show_inline(e,t="video",i){const n=c()(this).closest(".instructure_file_link_holder").andSelf().first()
n.text(o.t("loading","Loading media..."))
const a=function(e,i){const n=Math.min(i.closest("div,p,table").width()||j,j)
const a=Math.round(n/336*240)
return x(e).done(s=>{if(s.sources.length){const o={can_add_captions:s.can_add_captions,mediaCommentId:e,googleAnalyticsTitle:e,menuTimeoutMouseLeave:50,success(e){i.focus()
e.play()},keyActions:[{keys:r.a.values(g.keyCodes),action(e,t,i,n){if(e.isVideo){e.showControls()
e.startControlsTimer()}const o=new g(d["a"],e,t,n)
o.dispatch()}}]}
const l=T({sourcesAndTracks:s,mediaPlayerOptions:o,mediaType:t,height:a,width:n})
l.appendTo(i.html(""))
const u=new MediaElementPlayer(l,o)
l.data("mediaelementplayer",u)}else i.text(o.t("media_still_converting","Media is currently being converted, please try again in a little bit."))})}
if("maybe"===e){const e=i.replace(/\/download.*/,"")
const t=()=>n.text(o.t("Media has been queued for conversion, please try again in a little bit."))
const r=function(e){if(e.attachment&&"maybe"!==e.attachment.media_entry_id){n.text("")
return a(e.attachment.media_entry_id,n)}return t()}
return c.a.ajaxJSON(e,"GET",{},r,t)}return a(e,n)},show(e,t="video",i=null){c()(".play_media_comment").find(".ui-dialog-titlebar-close").click()
const n=c()(this)
const a=n.data("media_comment_dialog")
if(!a){let a,r
if("video"===t){a=426
r=j}else{a=180
r=400}const s=c()('<div style="overflow: hidden; padding: 0;" />')
"audio"===t&&s.css("padding-top","120px")
s.dialog({dialogClass:"play_media_comment",title:o.t("titles.play_comment","Play Media Comment"),width:r,height:a+60,modal:false,resizable:false,close:()=>{const e=n.data("mediaelementplayer")
e&&e.pause()
i&&i.focus()},open:e=>{c()(e.currentTarget).closest(".ui-dialog").attr("role","dialog").attr("aria-label",o.t("Play Media Comment"))
c()(e.currentTarget).parent().find(".ui-dialog-titlebar-close").focus()}})
return s.disableWhileLoading(x(e).done(i=>{if(i.sources.length){const o={can_add_captions:i.can_add_captions,mediaCommentId:e,googleAnalyticsTitle:e}
const l=T({sourcesAndTracks:i,mediaPlayerOptions:o,mediaType:t,height:a,width:r})
l.appendTo(s.html(""))
n.data({mediaelementplayer:new MediaElementPlayer(l,o),media_comment_dialog:s})}else s.text(o.t("media_still_converting","Media is currently being converted, please try again in a little bit."))}))}a.dialog("open")}}
c.a.fn.mediaComment=function(e,...t){if(!INST.kalturaSettings)return console.log("Kaltura has not been enabled for this account")
_[e].apply(this,t)
return this}},"65NJ":function(e,t,i){"use strict"
var n=i("ouhR")
var o=i.n(n)
i("w2hD")
o.a.fn.scrollToVisible=function(e){const t={}
const i=o()(e)
if(0===i.length)return
let n=i.offset(),a=i.outerWidth(),r=i.outerHeight(),s=n.top,l=s+r,d=n.left,u=d+a,c="html,body"==this.selector?o.a.windowScrollTop():this.scrollTop(),m=this.scrollLeft(),p=this.outerHeight(),f=this.outerWidth()
if("html,body"!=this.selector){let e=o()("body").offset()
this.each((function(){try{e=o()(this).offset()
return false}catch(e){}}))
s-=e.top
l-=e.top
d-=e.left
u-=e.left}if("HTML"==this[0].tagName||"BODY"==this[0].tagName){p=o()(window).height()
o()("#wizard_box:visible").length>0&&(p-=o()("#wizard_box:visible").height())
f=o()(window).width()
s-=c
d-=m
l-=c
u-=m}s<0||p<r&&l>p?t.scrollTop=s+c:l>p&&(t.scrollTop=l+c-p+20)
d<0?t.scrollLeft=d+m:u>f&&(t.scrollLeft=u+m-f+20)
1==t.scrollTop&&(t.scrollTop=0)
1==t.scrollLeft&&(t.scrollLeft=0)
this.scrollTop(t.scrollTop)
this.scrollLeft(t.scrollLeft)
return this}},"7hm3":function(e,t,i){"use strict"
var n=i("ouhR")
var o=i.n(n)
i("MIhX")
i("dJId")
o.a.widget("ui.progressbar",{version:"@VERSION",options:{value:0,max:100},min:0,_create:function(){this.element.addClass("ui-progressbar ui-widget ui-widget-content ui-corner-all").attr({role:"progressbar","aria-valuemin":this.min,"aria-valuemax":this.options.max,"aria-valuenow":this._value()})
this.valueDiv=o()("<div class='ui-progressbar-value ui-widget-header ui-corner-left'></div>").appendTo(this.element)
this.oldValue=this._value()
this._refreshValue()},_destroy:function(){this.element.removeClass("ui-progressbar ui-widget ui-widget-content ui-corner-all").removeAttr("role").removeAttr("aria-valuemin").removeAttr("aria-valuemax").removeAttr("aria-valuenow")
this.valueDiv.remove()},value:function(e){if(void 0===e)return this._value()
this._setOption("value",e)
return this},_setOption:function(e,t){if("value"===e){this.options.value=t
this._refreshValue()
this._value()===this.options.max&&this._trigger("complete")}this._super(e,t)},_value:function(){var e=this.options.value
"number"!==typeof e&&(e=0)
return Math.min(this.options.max,Math.max(this.min,e))},_percentage:function(){return 100*this._value()/this.options.max},_refreshValue:function(){var e=this.value(),t=this._percentage()
if(this.oldValue!==e){this.oldValue=e
this._trigger("change")}this.valueDiv.toggle(e>this.min).toggleClass("ui-corner-right",e===this.options.max).width(t.toFixed(0)+"%")
this.element.attr("aria-valuenow",e)}})},"9tPo":function(e,t){e.exports=function(e){var t="undefined"!==typeof window&&window.location
if(!t)throw new Error("fixUrls requires window.location")
if(!e||"string"!==typeof e)return e
var i=t.protocol+"//"+t.host
var n=i+t.pathname.replace(/\/[^\/]*$/,"/")
var o=e.replace(/url\s*\(((?:[^)(]|\((?:[^)(]+|\([^)(]*\))*\))*)\)/gi,(function(e,t){var o=t.trim().replace(/^"(.*)"$/,(function(e,t){return t})).replace(/^'(.*)'$/,(function(e,t){return t}))
if(/^(#|data:|http:\/\/|https:\/\/|file:\/\/\/|\s*$)/i.test(o))return e
var a
a=0===o.indexOf("//")?o:0===o.indexOf("/")?i+o:n+o.replace(/^\.\//,"")
return"url("+JSON.stringify(a)+")"}))
return o}},BHdR:function(e,t){(function(e){e.extend(mejs.MepDefaults,{playText:"",pauseText:""})
e.extend(MediaElementPlayer.prototype,{buildplaypause:function(t,i,n,o){var a=this,r=a.options,s=r.playText?r.playText:mejs.i18n.t("mejs.play"),l=r.pauseText?r.pauseText:mejs.i18n.t("mejs.pause"),d=e('<div class="mejs-button mejs-playpause-button mejs-play" ><button type="button" aria-controls="'+a.id+'" title="'+s+'" aria-label="'+l+'"></button></div>').appendTo(i).click((function(e){e.preventDefault()
o.paused?o.play():o.pause()
return false})),u=d.find("button")
function c(e){if("play"===e){d.removeClass("mejs-play").addClass("mejs-pause")
u.attr({title:l,"aria-label":l})}else{d.removeClass("mejs-pause").addClass("mejs-play")
u.attr({title:s,"aria-label":s})}}c("pse")
o.addEventListener("play",(function(){a.options.playbackRate&&(o.playbackRate=a.options.playbackRate)
c("play")}),false)
o.addEventListener("playing",(function(){c("play")}),false)
o.addEventListener("pause",(function(){a.options.playbackRate&&(o.playbackRate=a.options.playbackRate)
c("pse")}),false)
o.addEventListener("paused",(function(){c("pse")}),false)
o.addEventListener("unstarted",(function(){c("pse")}),false)}})})(mejs.$)},Dh7j:function(e,t,i){"use strict"
var n=i("HGxv")
var o=n["default"].scoped("media_comments_publicjs")
var a=i("Y/W1")
var r=i.n(a)
var s=i("XKWA")
var l=i.n(s)
var d=i("ouhR")
var u=i.n(d)
var c=i("gI0r")
i("4fRt")
i("dhbk")
i("ESjL")
i("8JEM")
i("aq8L")
i("7hm3")
const m=e=>e.default?e.default:e
let p
u.a.mediaComment=function(e,t,i){const n=u()("<div/>")
u()("body").append(n.hide())
u.a.fn.mediaComment.apply(n,arguments)}
u.a.mediaComment.partnerData=function(e){const t={context_code:u.a.mediaComment.contextCode(),root_account_id:ENV.DOMAIN_ROOT_ACCOUNT_ID,context_source:ENV.CONTEXT_ACTION_SOURCE}
ENV.SIS_SOURCE_ID&&(t.sis_source_id=ENV.SIS_SOURCE_ID)
ENV.SIS_USER_ID&&(t.sis_user_id=ENV.SIS_USER_ID)
return JSON.stringify(t)}
u.a.mediaComment.contextCode=function(){return ENV.media_comment_asset_string||ENV.context_asset_string||"user_"+ENV.current_user_id}
function f(e,t){const i=u.a.mediaComment.contextCode()
const n={2:"image",5:"audio"}[e.mediaType]||t?"audio":"video"
i&&u.a.ajaxJSON("/media_objects","POST",{id:e.entryId,type:n,context_code:i,title:e.title,user_entered_title:e.userTitle},e=>{l.a.publish("media_object_created",e)},u.a.noop)
l.a.publish("media_comment_created",{id:e.entryId,mediaType:n,title:e.userTitle})}const h={}
u.a.mediaComment.entryAdded=function(e,t,i,n){if(!e||h[e])return
h[e]=true
const o={mediaType:t,entryId:e,title:i,userTitle:n}
f(o)}
u.a.mediaComment.audio_delegate={readyHandler(){try{u()("#audio_upload")[0].setMediaType("audio")}catch(e){u.a.mediaComment.upload_delegate.setupErrorHandler()}},selectHandler(){u.a.mediaComment.upload_delegate.selectHandler("audio")},singleUploadCompleteHandler(e){u.a.mediaComment.upload_delegate.singleUploadCompleteHandler("audio",e)},allUploadsCompleteHandler(){u.a.mediaComment.upload_delegate.allUploadsCompleteHandler("audio")},entriesAddedHandler(e){u.a.mediaComment.upload_delegate.entriesAddedHandler("audio",e)},progressHandler(e){u.a.mediaComment.upload_delegate.progressHandler("audio",e[0],e[1],e[2])},uploadErrorHandler(){u.a.mediaComment.upload_delegate.uploadErrorHandler("audio")}}
u.a.mediaComment.video_delegate={readyWatcher:null,expectReady(){if(u.a.mediaComment.video_delegate.readyWatcher)return
u.a.mediaComment.video_delegate.readyWatcher=setTimeout(u.a.mediaComment.upload_delegate.setupErrorHandler,2e3)},readyHandler(){try{u()("#video_upload")[0].setMediaType("video")}catch(e){u.a.mediaComment.upload_delegate.setupErrorHandler()}clearTimeout(u.a.mediaComment.video_delegate.readyWatcher)
u.a.mediaComment.video_delegate.readyWatcher=true},selectHandler(){u.a.mediaComment.upload_delegate.selectHandler("video")},singleUploadCompleteHandler(e){u.a.mediaComment.upload_delegate.singleUploadCompleteHandler("video",e)},allUploadsCompleteHandler(){u.a.mediaComment.upload_delegate.allUploadsCompleteHandler("video")},entriesAddedHandler(e){u.a.mediaComment.upload_delegate.entriesAddedHandler("video",e)},progressHandler(e){u.a.mediaComment.upload_delegate.progressHandler("video",e[0],e[1],e[2])},uploadErrorHandler(){u.a.mediaComment.upload_delegate.uploadErrorHandler("video")}}
u.a.mediaComment.upload_delegate={currentType:"audio",submit(){const e=u.a.mediaComment.upload_delegate.currentType
let t=u()("#"+e+"_upload")[0].getFiles()
t.length>1&&u()("#"+e+"_upload")[0].removeFiles(0,t.length-2)
t=u()("#"+e+"_upload")[0].getFiles()
if(0==t.length)return
u()("#media_upload_progress").css("visibility","visible").progressbar({value:1})
u()("#media_upload_submit").attr("disabled",true).text(o.t("messages.submitting","Submitting Media File..."))
u()("#"+e+"_upload")[0].upload()},selectHandler(e){u.a.mediaComment.upload_delegate.currentType=e
try{var t=u()("#"+e+"_upload")[0].getFiles()}catch(e){u.a.mediaComment.upload_delegate.setupErrorHandler()
return}t.length>1&&u()("#"+e+"_upload")[0].removeFiles(0,t.length-2)
const i=u()("#"+e+"_upload")[0].getFiles()[0]
u()("#media_upload_settings .icon").attr("src","/images/file-"+e+".png")
u()("#media_upload_submit").show()
u()("#media_upload_submit").attr("disabled",!i)
u()("#media_upload_settings").css("visibility",i?"visible":"hidden")
u()("#media_upload_title").val(i.title)
u()("#media_upload_display_title").text(i.title)
u()("#media_upload_file_size").text(u.a.fileSize(i.bytesTotal))
u()("#media_upload_feedback_text").html("")
u()("#media_upload_feedback").css("visibility","hidden")
if(i.bytesTotal>INST.kalturaSettings.max_file_size_bytes){u()("#media_upload_feedback_text").html(o.t("errors.file_too_large","*This file is too large.* The maximum size is %{size}MB.",{size:INST.kalturaSettings.max_file_size_bytes/1048576,wrapper:"<b>$1</b>"}))
u()("#media_upload_feedback").css("visibility","visible")
u()("#media_upload_submit").hide()
return}u()("#media_upload_submit").click()},singleUploadCompleteHandler(e,t){u()("#media_upload_progress").progressbar("option","value",100)},allUploadsCompleteHandler(e){u()("#media_upload_progress").progressbar("option","value",100)
u()("#"+e+"_upload")[0].addEntries()},entriesAddedHandler(e,t){u()("#media_upload_progress").progressbar("option","value",100)
const i=t[0]
u()("#media_upload_submit").text(o.t("messages.submitted","Submitted Media File!"))
setTimeout(()=>{u()("#media_comment_dialog").dialog("close")},1500)
"audio"==e?i.entryType=5:"video"==e&&(i.entryType=1)
u.a.mediaComment.entryAdded(i.entryId,i.entryType,i.title)},progressHandler(e,t,i,n){const o=100*t/i
u()("#media_upload_progress").progressbar("option","value",o)},uploadErrorHandler(e){const t=u()("#"+e+"_upload")[0].getError()
u()("#media_upload_errors").text(o.t("errors.upload_failed","Upload failed with error:")+" "+t)
u()("#media_upload_progress").hide()},setupErrorHandler(){u()("#media_upload_feedback_text").text(o.t("errors.media_comment_installation_broken","Media comment uploading has not been set up properly. Please contact your administrator."))
u()("#media_upload_feedback").css("visibility","visible")
u()("#audio_upload_holder").css("visibility","hidden")
u()("#video_upload_holder").css("visibility","hidden")}}
let g=false
let b=null
u.a.mediaComment.init=function(e,t){Promise.all([i.e(9),i.e(23),i.e(32),i.e(3863)]).then((()=>{const n=i("ufgb")
b=b||new Date
e=e||"any"
t=t||{}
let a=u.a.trim(u()("#identity .user_name").text()||"")
a&&(a=a+": "+(new Date).toString("ddd MMM d, yyyy"))
const r=t.defaultTitle||a||o.t("titles.media_contribution","Media Contribution")
const s=function(){let i,a
if(INST.kalturaSettings.js_uploader){i=p.getKs()
a=p.getUid()}else{i=d.data("ks")
a=d.data("uid")||"ANONYMOUS"}u()("#video_record_title,#audio_record_title").val(r)
d.dialog({title:o.t("titles.record_upload_media_comment","Record/Upload Media Comment"),width:560,height:475,modal:true})
d.dialog("option","close",()=>{u()("#audio_record").before("<div id='audio_record'/>").remove()
u()("#video_record").before("<div id='video_record'/>").remove()
t&&t.close&&u.a.isFunction(t.close)&&t.close.call(d)})
u()("#audio_record").before("<div id='audio_record'/>").remove()
u()("#video_record").before("<div id='video_record'/>").remove()
if("video"==e){u()("#video_record_option").click()
u()("#media_record_option_holder").hide()
u()("#audio_upload_holder").hide()
u()("#video_upload_holder").show()}else if("audio"==e){u()("#audio_record_option").click()
u()("#media_record_option_holder").hide()
u()("#audio_upload_holder").show()
u()("#video_upload_holder").hide()}else{u()("#video_record_option").click()
u()("#audio_upload_holder").show()
u()("#video_upload_holder").show()}u()(document).triggerHandler("reset_media_comment_forms")
const s=u.a.trim(u()("#identity .user_name").text())+" "+(new Date).toISOString()
setTimeout(()=>{var e={host:location.protocol+"//"+INST.kalturaSettings.domain,rtmpHost:"rtmp://"+(INST.kalturaSettings.rtmp_domain||INST.kalturaSettings.domain),kshowId:"-1",pid:INST.kalturaSettings.partner_id,subpid:INST.kalturaSettings.subpartner_id,uid:a,ks:i,themeUrl:"/media_record/skin.swf",localeUrl:"/media_record/locale.xml",thumbOffset:"1",licenseType:"CC-0.1",showUi:"true",useCamera:"0",maxFileSize:INST.kalturaSettings.max_file_size_bytes/1048576,maxUploads:1,partnerData:u.a.mediaComment.partnerData(),partner_data:u.a.mediaComment.partnerData(),entryName:s,soundcodec:"Speex",autoPreview:"0"}
var t={align:"middle",quality:"high",bgcolor:"#ffffff",name:"KRecordAudio",allowScriptAccess:"sameDomain",type:"application/x-shockwave-flash",pluginspage:"http://www.adobe.com/go/getflashplayer",wmode:"opaque"}
u()("#audio_record").text(o.t("messages.flash_required_record_audio","Flash required for recording audio."))
n.embedSWF("/media_record/KRecord.swf","audio_record","400","300","9.0.0",false,e,t)
t=u.a.extend({},t,{name:"KRecordVideo"})
e=u.a.extend({},e,{useCamera:"1"})
u()("#video_record").html("Flash required for recording video.")
n.embedSWF("/media_record/KRecord.swf","video_record","400","300","9.0.0",false,e,t)},10)
let l={host:location.protocol+"//"+INST.kalturaSettings.domain,partnerId:INST.kalturaSettings.partner_id,subPId:INST.kalturaSettings.subpartner_id,uid:a,entryId:"-1",ks:i,thumbOffset:"1",licenseType:"CC-0.1",maxFileSize:INST.kalturaSettings.max_file_size_bytes/1048576,maxUploads:1,partnerData:u.a.mediaComment.partnerData(),partner_data:u.a.mediaComment.partnerData(),uiConfId:INST.kalturaSettings.upload_ui_conf,jsDelegate:"$.mediaComment.audio_delegate"}
const c={align:"middle",quality:"high",bgcolor:"#ffffff",name:"KUpload",allowScriptAccess:"always",type:"application/x-shockwave-flash",pluginspage:"http://www.adobe.com/go/getflashplayer",wmode:"transparent"}
u()("#audio_upload").text(o.t("messages.flash_required_upload_audio","Flash required for uploading audio."))
var m="180"
var f="50"
n.embedSWF("//"+INST.kalturaSettings.domain+"/kupload/ui_conf_id/"+INST.kalturaSettings.upload_ui_conf,"audio_upload",m,f,"9.0.0",false,l,c)
l=u.a.extend({},l,{jsDelegate:"$.mediaComment.video_delegate"})
u()("#video_upload").text(o.t("messages.flash_required_upload_video","Flash required for uploading video."))
m="180"
f="50"
n.embedSWF("//"+INST.kalturaSettings.domain+"/kupload/ui_conf_id/"+INST.kalturaSettings.upload_ui_conf,"video_upload",m,f,"9.0.0",false,l,c)
let h,b,v
let y,j
let k,w,x
let T,_
g=true
setInterval(()=>{if(g){h=u()("#audio_record_holder")
b=u()("#audio_record")
v=u()("#audio_record_meter")
y=0
j=0
k=u()("#video_record_holder")
w=u()("#video_record")
x=u()("#video_record_meter")
T=0
_=0
g=false}y++
T++
let e=null,t=null
b&&b[0]&&b[0].getMicophoneActivityLevel&&b.parent().length?e=b[0].getMicophoneActivityLevel():b=u()("#audio_record")
w&&w[0]&&w[0].getMicophoneActivityLevel&&w.parent().length?t=w[0].getMicophoneActivityLevel():w=u()("#video_record")
if(null!=e){e=Math.max(e,j)
if(e>-1&&!h.hasClass("with_volume")){v.css("display","none")
u()("#audio_record_holder").addClass("with_volume").animate({width:420},()=>{v.css("display","")})}if(y>4){j=0
y=0
var i=(e-e%10)/10
v.attr("class","volume_meter band_"+i)}else j=e}if(null!=t){t=Math.max(t,_)
if(t>-1&&!k.hasClass("with_volume")){x.css("display","none")
u()("#video_record_holder").addClass("with_volume").animate({width:420},()=>{x.css("display","")})}if(T>4){_=0
T=0
i=(t-t%10)/10
x.attr("class","volume_meter band_"+i)}else _=t}},20)}
if(INST.kalturaSettings.js_uploader){const n=m(i("w6Bb"))
p=new n(e,t)
p.onReady=s
p.addEntry=f
const o=i("RGX7").getBrowser
const a=o();("Chrome"===a.name&&Number(a.version)>=68||"Firefox"===a.name&&Number(a.version)>=61)&&Promise.all([i.e(1),i.e(2),i.e(3),i.e(5),i.e(15),i.e(17),i.e(95),i.e(4136)]).then(i.bind(null,"2Ema")).then(({default:e})=>{let t
const i=()=>{const i=document.getElementById("record_media_tab")
if(i){e(i,p.doUploadByFile)
clearInterval(t)}}
t=setInterval(i,10)})}const l=new Date
l-b>3e5&&u()("#media_comment_dialog").dialog("close").remove()
b=l
var d=u()("#media_comment_dialog")
if(0!=d.length||INST.kalturaSettings.js_uploader)INST.kalturaSettings.js_uploader||s()
else{const e=u()("<div/>").attr("id","media_comment_dialog")
e.text(o.t("messages.loading","Loading..."))
e.dialog({title:o.t("titles.record_upload_media_comment","Record/Upload Media Comment"),resizable:false,width:470,height:300,modal:true})
u.a.ajaxJSON("/api/v1/services/kaltura_session","POST",{},t=>{e.data("ks",t.ks)
e.data("uid",t.uid)},t=>{false==t.logged_in?e.data("ks-error",o.t("errors.must_be_logged_in","You must be logged in to record media.")):e.data("ks-error",o.t("errors.load_failed","Media Comment Application failed to load.  Please try again."))})
var c=function(){if(e.data("ks")){const t=m(i("0FQW"))
e.html(t())
i("UEsX")
e.find("#media_record_tabs").tabs({activate:u.a.mediaComment.video_delegate.expectReady})
s()}else e.data("ks-error")?e.html(e.data("ks-error")):setTimeout(c,500)}
c()
d=u()("#media_comment_dialog")
d=e}}).bind(null,i)).catch(i.oe)}
u()(document).ready((function(){u()(document).bind("reset_media_comment_forms",()=>{u()("#audio_record_holder_message,#video_record_holder_message").removeClass("saving").find(".recorder_message").html("Saving Recording...<img src='/images/media-saving.gif'/>")
u()("#audio_record_holder").stop(true,true).clearQueue().css("width","").removeClass("with_volume")
u()("#video_record_holder").stop(true,true).clearQueue().css("width","").removeClass("with_volume")
u()("#media_upload_submit").text(o.t("buttons.submit","Submit Media File")).attr("disabled",true)
u()("#media_upload_settings").css("visibility","hidden")
u()("#media_upload_progress").css("visibility","hidden").progressbar().progressbar("option","value",1)
u()("#media_upload_title").val("")
let e=u()("#audio_upload")[0]&&u()("#audio_upload")[0].getFiles&&u()("#audio_upload")[0].getFiles()
e&&u()("#audio_upload")[0].removeFiles&&e.length>0&&u()("#audio_upload")[0].removeFiles(0,e.length-1)
e=u()("#video_upload")[0]&&u()("#video_upload")[0].getFiles&&u()("#video_upload")[0].getFiles()
e&&u()("#video_upload")[0].removeFiles&&e.length>0&&u()("#video_upload")[0].removeFiles(0,e.length-1)})
u()("#media_upload_submit").live("click",e=>{u.a.mediaComment.upload_delegate.submit()})
u()("#video_record_option,#audio_record_option").live("click",(function(e){e.preventDefault()
u()("#video_record_option,#audio_record_option").removeClass("selected_option")
u()(this).addClass("selected_option")
u()("#audio_record_holder").stop(true,true).clearQueue().css("width","").removeClass("with_volume")
u()("#video_record_holder").stop(true,true).clearQueue().css("width","").removeClass("with_volume")
if("audio_record_option"==u()(this).attr("id")){u()("#video_record_holder_holder").hide()
u()("#audio_record_holder_holder").show()}else{u()("#video_record_holder_holder").show()
u()("#audio_record_holder_holder").hide()}}))}))
u()(document).bind("media_recording_error",()=>{u()("#audio_record_holder_message,#video_record_holder_message").find(".recorder_message").html(Object(c["a"])(o.t("errors.save_failed","Saving appears to have failed.  Please close this popup to try again."))+"<div style='font-size: 0.8em; margin-top: 20px;'>"+Object(c["a"])(o.t("errors.persistent_problem","If this problem keeps happening, you may want to try recording your media locally and then uploading the saved file instead."))+"</div>")})
window.mediaCommentCallback=function(e){r.a.each(e,f)
u()("#media_comment_create_dialog").empty().dialog("close")}
window.beforeAddEntry=function(){const e=Math.random()
u.a.mediaComment.lastAddAttemptId=e
setTimeout(()=>{u.a.mediaComment.lastAddAttemptId==e&&u()(document).triggerHandler("media_recording_error")},3e4)
u()("#audio_record_holder_message,#video_record_holder_message").addClass("saving")}
window.addEntryFail=function(){u()(document).triggerHandler("media_recording_error")}
window.addEntryFailed=function(){u()(document).triggerHandler("media_recording_error")}
window.addEntryComplete=function(e){u.a.mediaComment.lastAddAttemptId=null
u()("#audio_record_holder_message,#video_record_holder_message").removeClass("saving")
try{let t=null
u.a.isArray(e)||(e=[e])
for(let i=0;i<e.length;i++){const n=e[i]
0==u()("#media_record_tabs").tabs("option","selected")?t=u()("#video_record_title,#audio_record_title").filter(":visible:first").val():u()("#media_record_tabs").tabs("option","selected")
1==n.entryType&&u()("#audio_record_option").hasClass("selected_option")&&(n.entryType=5)
u.a.mediaComment.entryAdded(n.entryId,n.entryType,n.entryName,t)
u()("#media_comment_dialog").dialog("close")}}catch(e){console.log(e)
alert(o.t("errors.save_failed_try_again","Entry failed to save.  Please try again."))}}},EScf:function(e,t){(function(e){e.extend(mejs.MepDefaults,{duration:-1,timeAndDurationSeparator:"<span> | </span>"})
e.extend(MediaElementPlayer.prototype,{buildcurrent:function(t,i,n,o){var a=this
e('<div class="mejs-time" role="timer" aria-live="off"><span class="mejs-currenttime">'+mejs.Utility.secondsToTimeCode(0,t.options)+"</span></div>").appendTo(i)
a.currenttime=a.controls.find(".mejs-currenttime")
o.addEventListener("timeupdate",(function(){a.controlsAreVisible&&t.updateCurrent()}),false)},buildduration:function(t,i,n,o){var a=this
if(i.children().last().find(".mejs-currenttime").length>0)e(a.options.timeAndDurationSeparator+'<span class="mejs-duration">'+mejs.Utility.secondsToTimeCode(a.options.duration,a.options)+"</span>").appendTo(i.find(".mejs-time"))
else{i.find(".mejs-currenttime").parent().addClass("mejs-currenttime-container")
e('<div class="mejs-time mejs-duration-container"><span class="mejs-duration">'+mejs.Utility.secondsToTimeCode(a.options.duration,a.options)+"</span></div>").appendTo(i)}a.durationD=a.controls.find(".mejs-duration")
o.addEventListener("timeupdate",(function(){a.controlsAreVisible&&t.updateDuration()}),false)},updateCurrent:function(){var e=this
var t=e.media.currentTime
isNaN(t)&&(t=0)
e.currenttime&&e.currenttime.html(mejs.Utility.secondsToTimeCode(t,e.options))},updateDuration:function(){var e=this
var t=e.media.duration
e.options.duration>0&&(t=e.options.duration)
isNaN(t)&&(t=0)
e.container.toggleClass("mejs-long-video",t>3600)
e.durationD&&t>0&&e.durationD.html(mejs.Utility.secondsToTimeCode(t,e.options))}})})(mejs.$)},EnmO:function(e,t,i){e.exports=i.p+"40f56f5a736da4effeb790cedb8a52f0.svg"},G7rK:function(e,t){(function(e){e.extend(mejs.MepDefaults,{muteText:mejs.i18n.t("mejs.mute-toggle"),allyVolumeControlText:mejs.i18n.t("mejs.volume-help-text"),hideVolumeOnTouchDevices:true,audioVolume:"horizontal",videoVolume:"vertical"})
e.extend(MediaElementPlayer.prototype,{buildvolume:function(t,i,n,o){if((mejs.MediaFeatures.isAndroid||mejs.MediaFeatures.isiOS)&&this.options.hideVolumeOnTouchDevices)return
function a(){return"function"===typeof o.getVolume?o.getVolume():o.volume}var r=this,s=r.isVideo?r.options.videoVolume:r.options.audioVolume,l="horizontal"==s?e('<div class="mejs-button mejs-volume-button mejs-mute"><button type="button" aria-controls="'+r.id+'" title="'+r.options.muteText+'" aria-label="'+r.options.muteText+'"></button></div><a href="javascript:void(0);" class="mejs-horizontal-volume-slider"><span class="mejs-offscreen">'+r.options.allyVolumeControlText+'</span><div class="mejs-horizontal-volume-total"></div><div class="mejs-horizontal-volume-current"></div><div class="mejs-horizontal-volume-handle"></div></a>').appendTo(i):e('<div class="mejs-button mejs-volume-button mejs-mute"><button type="button" aria-controls="'+r.id+'" title="'+r.options.muteText+'" aria-label="'+r.options.muteText+'"></button><a href="javascript:void(0);" class="mejs-volume-slider mejs-offscreen"><span class="mejs-offscreen">'+r.options.allyVolumeControlText+'</span><div class="mejs-volume-total"></div><div class="mejs-volume-current"></div><div class="mejs-volume-handle"></div></a></div>').appendTo(i),d=r.container.find(".mejs-volume-slider, .mejs-horizontal-volume-slider"),u=r.container.find(".mejs-volume-total, .mejs-horizontal-volume-total"),c=r.container.find(".mejs-volume-current, .mejs-horizontal-volume-current"),m=r.container.find(".mejs-volume-handle, .mejs-horizontal-volume-handle"),p=function(e,t){if(!d.is(":visible")&&"undefined"==typeof t){d.show()
p(e,true)
d.hide()
return}if(d.hasClass("mejs-offscreen")&&"undefined"==typeof t){d.removeClass("mejs-offscreen")
p(e,true)
d.addClass("mejs-offscreen")
return}e=Math.max(0,e)
e=Math.min(e,1)
if(0===e){l.removeClass("mejs-mute").addClass("mejs-unmute")
l.children("button").attr("title",mejs.i18n.t("mejs.unmute")).attr("aria-label",mejs.i18n.t("mejs.unmute"))}else{l.removeClass("mejs-unmute").addClass("mejs-mute")
l.children("button").attr("title",mejs.i18n.t("mejs.mute")).attr("aria-label",mejs.i18n.t("mejs.mute"))}var i=u.position()
if("vertical"==s){var n=u.height(),o=n-n*e
m.css("top",Math.round(i.top+o-m.height()/2))
c.height(n-o)
c.css("top",i.top+o)}else{var a=u.width(),r=a*e
m.css("left",Math.round(i.left+r-m.width()/2))
c.width(Math.round(r))}},f=function(e){var t=null,i=u.offset()
if("vertical"===s){var n=u.height(),a=e.pageY-i.top
t=(n-a)/n
if(0===i.top||0===i.left)return}else{var r=u.width(),l=e.pageX-i.left
t=l/r}t=Math.max(0,t)
t=Math.min(t,1)
p(t)
0===t?o.setMuted(true):o.setMuted(false)
o.setVolume(t)},h=false,g=false
l.hover((function(){d.removeClass("mejs-offscreen")
g=true}),(function(){g=false
h||"vertical"!=s||d.addClass("mejs-offscreen")}))
var b=function(e){var t=Math.floor(100*a(o))
d.attr({"aria-label":mejs.i18n.t("mejs.volume-slider"),"aria-valuemin":0,"aria-valuemax":100,"aria-valuenow":t,"aria-valuetext":t+"%",role:"slider",tabindex:0})}
var v=mejs.Utility.debounce((function(t){setTimeout((function(){var t=e(document.activeElement).closest(".mejs-mute")
t.length||g||"vertical"!=s||d.addClass("mejs-offscreen")}),0)}),100)
d.bind("mouseover",(function(){g=true})).bind("mousedown",(function(e){f(e)
r.globalBind("mousemove.vol",(function(e){f(e)}))
r.globalBind("mouseup.vol",(function(){h=false
r.globalUnbind(".vol")
g||"vertical"!=s||d.addClass("mejs-offscreen")}))
h=true
return false})).bind("keydown",(function(e){var t=e.keyCode
var i=a()
switch(t){case 38:i=Math.min(i+.1,1)
break
case 40:i=Math.max(0,i-.1)
break
default:return true}h=false
p(i)
o.setVolume(i)
return false})).bind("focus",(function(){d.removeClass("mejs-offscreen")})).on("focusout",v)
l.find("button").click((function(){o.setMuted(!o.muted)})).bind("focus",(function(){d.removeClass("mejs-offscreen")})).on("focusout",v)
o.addEventListener("volumechange",(function(e){if(!h)if(o.muted){p(0)
l.removeClass("mejs-mute").addClass("mejs-unmute")}else{p(a())
l.removeClass("mejs-unmute").addClass("mejs-mute")}b(e)}),false)
0===t.options.startVolume&&o.setMuted(true)
"native"===o.pluginType&&o.setVolume(t.options.startVolume)
r.container.on("controlsresize",(function(){if(o.muted){p(0)
l.removeClass("mejs-mute").addClass("mejs-unmute")}else{p(a())
l.removeClass("mejs-unmute").addClass("mejs-mute")}}))}})})(mejs.$)},HeW1:function(e,t,i){"use strict"
e.exports=function(e,t){t||(t={})
e=e&&e.__esModule?e.default:e
if("string"!==typeof e)return e;/^['"].*['"]$/.test(e)&&(e=e.slice(1,-1))
t.hash&&(e+=t.hash)
if(/["'() \t\n]/.test(e)||t.needQuotes)return'"'.concat(e.replace(/"/g,'\\"').replace(/\n/g,"\\n"),'"')
return e}},JPst:function(e,t,i){"use strict"
e.exports=function(e){var t=[]
t.toString=function(){return this.map((function(t){var i=n(t,e)
if(t[2])return"@media ".concat(t[2]," {").concat(i,"}")
return i})).join("")}
t.i=function(e,i,n){"string"===typeof e&&(e=[[null,e,""]])
var o={}
if(n)for(var a=0;a<this.length;a++){var r=this[a][0]
null!=r&&(o[r]=true)}for(var s=0;s<e.length;s++){var l=[].concat(e[s])
if(n&&o[l[0]])continue
i&&(l[2]?l[2]="".concat(i," and ").concat(l[2]):l[2]=i)
t.push(l)}}
return t}
function n(e,t){var i=e[1]||""
var n=e[3]
if(!n)return i
if(t&&"function"===typeof btoa){var a=o(n)
var r=n.sources.map((function(e){return"/*# sourceURL=".concat(n.sourceRoot||"").concat(e," */")}))
return[i].concat(r).concat([a]).join("\n")}return[i].join("\n")}function o(e){var t=btoa(unescape(encodeURIComponent(JSON.stringify(e))))
var i="sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(t)
return"/*# ".concat(i," */")}},Mn3D:function(e,t,i){var n=i("UYA0")
"string"===typeof n&&(n=[[e.i,n,""]])
var o
var a={hmr:true}
a.transform=o
a.insertInto=void 0
i("aET+")(n,a)
n.locals&&(e.exports=n.locals)
false},MoxK:function(e,t){var n=n||{}
n.version="2.23.5"
n.meIndex=0
n.plugins={silverlight:[{version:[3,0],types:["video/mp4","video/m4v","video/mov","video/wmv","audio/wma","audio/m4a","audio/mp3","audio/wav","audio/mpeg"]}],flash:[{version:[9,0,124],types:["video/mp4","video/m4v","video/mov","video/flv","video/rtmp","video/x-flv","audio/flv","audio/x-flv","audio/mp3","audio/m4a","audio/mp4","audio/mpeg","video/dailymotion","video/x-dailymotion","application/x-mpegURL","audio/ogg"]}],youtube:[{version:null,types:["video/youtube","video/x-youtube","audio/youtube","audio/x-youtube"]}],vimeo:[{version:null,types:["video/vimeo","video/x-vimeo"]}]}
n.Utility={encodeUrl:function(e){return encodeURIComponent(e)},escapeHTML:function(e){return e.toString().split("&").join("&amp;").split("<").join("&lt;").split('"').join("&quot;")},absolutizeUrl:function(e){var t=document.createElement("div")
t.innerHTML='<a href="'+this.escapeHTML(e)+'">x</a>'
return t.firstChild.href},getScriptPath:function(e){var t,i,n,o,a,r,s=0,l="",d="",u=document.getElementsByTagName("script"),c=u.length,m=e.length
for(;s<c;s++){o=u[s].src
i=o.lastIndexOf("/")
if(i>-1){r=o.substring(i+1)
a=o.substring(0,i+1)}else{r=o
a=""}for(t=0;t<m;t++){d=e[t]
n=r.indexOf(d)
if(n>-1){l=a
break}}if(""!==l)break}return l},calculateTimeFormat:function(e,t,i){e<0&&(e=0)
"undefined"==typeof i&&(i=25)
var n=t.timeFormat,o=n[0],a=n[1]==n[0],r=a?2:1,s=":",l=Math.floor(e/3600)%24,d=Math.floor(e/60)%60,u=Math.floor(e%60),c=Math.floor((e%1*i).toFixed(3)),m=[[c,"f"],[u,"s"],[d,"m"],[l,"h"]]
n.length<r&&(s=n[r])
var p=false
for(var f=0,h=m.length;f<h;f++)if(-1!==n.indexOf(m[f][1]))p=true
else if(p){var g=false
for(var b=f;b<h;b++)if(m[b][0]>0){g=true
break}if(!g)break
a||(n=o+n)
n=m[f][1]+s+n
a&&(n=m[f][1]+n)
o=m[f][1]}t.currentTimeFormat=n},twoDigitsString:function(e){if(e<10)return"0"+e
return String(e)},secondsToTimeCode:function(e,t){e<0&&(e=0)
if("object"!==typeof t){var n="m:ss"
n=arguments[1]?"hh:mm:ss":n
n=arguments[2]?n+":ff":n
t={currentTimeFormat:n,framesPerSecond:arguments[3]||25}}var o=t.framesPerSecond
"undefined"===typeof o&&(o=25)
n=t.currentTimeFormat
var a=Math.floor(e/3600)%24,r=Math.floor(e/60)%60,s=Math.floor(e%60),l=Math.floor((e%1*o).toFixed(3))
lis=[[l,"f"],[s,"s"],[r,"m"],[a,"h"]]
var d=n
for(i=0,len=lis.length;i<len;i++){d=d.replace(lis[i][1]+lis[i][1],this.twoDigitsString(lis[i][0]))
d=d.replace(lis[i][1],lis[i][0])}return d},timeCodeToSeconds:function(e,t,i,n){"undefined"==typeof i?i=false:"undefined"==typeof n&&(n=25)
var o=e.split(":"),a=parseInt(o[0],10),r=parseInt(o[1],10),s=parseInt(o[2],10),l=0,d=0
i&&(l=parseInt(o[3])/n)
d=3600*a+60*r+s+l
return d},convertSMPTEtoSeconds:function(e){if("string"!=typeof e)return false
e=e.replace(",",".")
var t=0,i=-1!=e.indexOf(".")?e.split(".")[1].length:0,n=1
e=e.split(":").reverse()
for(var o=0;o<e.length;o++){n=1
o>0&&(n=Math.pow(60,o))
t+=Number(e[o])*n}return Number(t.toFixed(i))},removeSwf:function(e){var t=document.getElementById(e)
if(t&&/object|embed/i.test(t.nodeName))if(n.MediaFeatures.isIE){t.style.display="none";(function(){4==t.readyState?n.Utility.removeObjectInIE(e):setTimeout(arguments.callee,10)})()}else t.parentNode.removeChild(t)},removeObjectInIE:function(e){var t=document.getElementById(e)
if(t){for(var i in t)"function"==typeof t[i]&&(t[i]=null)
t.parentNode.removeChild(t)}},determineScheme:function(e){if(e&&-1!=e.indexOf("://"))return e.substr(0,e.indexOf("://")+3)
return"//"},debounce:function(e,t,i){var n
return function(){var o=this,a=arguments
var r=function(){n=null
i||e.apply(o,a)}
var s=i&&!n
clearTimeout(n)
n=setTimeout(r,t)
s&&e.apply(o,a)}},isNodeAfter:function(e,t){return!!(e&&t&&"function"===typeof e.compareDocumentPosition&&e.compareDocumentPosition(t)&Node.DOCUMENT_POSITION_PRECEDING)}}
n.PluginDetector={hasPluginVersion:function(e,t){var i=this.plugins[e]
t[1]=t[1]||0
t[2]=t[2]||0
return i[0]>t[0]||i[0]==t[0]&&i[1]>t[1]||i[0]==t[0]&&i[1]==t[1]&&i[2]>=t[2]},nav:window.navigator,ua:window.navigator.userAgent.toLowerCase(),plugins:[],addPlugin:function(e,t,i,n,o){this.plugins[e]=this.detectPlugin(t,i,n,o)},detectPlugin:function(e,t,i,n){var o,a,r,s=[0,0,0]
if("undefined"!=typeof this.nav.plugins&&"object"==typeof this.nav.plugins[e]){o=this.nav.plugins[e].description
if(o&&!("undefined"!=typeof this.nav.mimeTypes&&this.nav.mimeTypes[t]&&!this.nav.mimeTypes[t].enabledPlugin)){s=o.replace(e,"").replace(/^\s+/,"").replace(/\sr/gi,".").split(".")
for(a=0;a<s.length;a++)s[a]=parseInt(s[a].match(/\d+/),10)}}else if("undefined"!=typeof window.ActiveXObject)try{r=new ActiveXObject(i)
r&&(s=n(r))}catch(e){}return s}}
n.PluginDetector.addPlugin("flash","Shockwave Flash","application/x-shockwave-flash","ShockwaveFlash.ShockwaveFlash",(function(e){var t=[],i=e.GetVariable("$version")
if(i){i=i.split(" ")[1].split(",")
t=[parseInt(i[0],10),parseInt(i[1],10),parseInt(i[2],10)]}return t}))
n.PluginDetector.addPlugin("silverlight","Silverlight Plug-In","application/x-silverlight-2","AgControl.AgControl",(function(e){var t=[0,0,0,0],i=function(e,t,i,n){while(e.isVersionSupported(t[0]+"."+t[1]+"."+t[2]+"."+t[3]))t[i]+=n
t[i]-=n}
i(e,t,0,1)
i(e,t,1,1)
i(e,t,2,1e4)
i(e,t,2,1e3)
i(e,t,2,100)
i(e,t,2,10)
i(e,t,2,1)
i(e,t,3,1)
return t}))
n.MediaFeatures={init:function(){var e,t,i=this,o=document,a=n.PluginDetector.nav,r=n.PluginDetector.ua.toLowerCase(),s=["source","track","audio","video"]
i.isiPad=null!==r.match(/ipad/i)
i.isiPhone=null!==r.match(/iphone/i)
i.isiOS=i.isiPhone||i.isiPad
i.isAndroid=null!==r.match(/android/i)
i.isBustedAndroid=null!==r.match(/android 2\.[12]/)
i.isBustedNativeHTTPS="https:"===location.protocol&&(null!==r.match(/android [12]\./)||null!==r.match(/macintosh.* version.* safari/))
i.isIE=-1!=a.appName.toLowerCase().indexOf("microsoft")||null!==a.appName.toLowerCase().match(/trident/gi)
i.isChrome=null!==r.match(/chrome/gi)
i.isChromium=null!==r.match(/chromium/gi)
i.isFirefox=null!==r.match(/firefox/gi)
i.isWebkit=null!==r.match(/webkit/gi)
i.isGecko=null!==r.match(/gecko/gi)&&!i.isWebkit&&!i.isIE
i.isOpera=null!==r.match(/opera/gi)
i.hasTouch="ontouchstart"in window
i.svgAsImg=!!document.implementation.hasFeature("http://www.w3.org/TR/SVG11/feature#Image","1.1")
for(e=0;e<s.length;e++)t=document.createElement(s[e])
i.supportsMediaTag="undefined"!==typeof t.canPlayType||i.isBustedAndroid
try{t.canPlayType("video/mp4")}catch(e){i.supportsMediaTag=false}i.supportsPointerEvents=function(){var e=document.createElement("a").style
e.cssText="pointer-events:auto"
return"auto"===e.pointerEvents}()
i.hasFirefoxPluginMovingProblem=false
i.hasiOSFullScreen="undefined"!==typeof t.webkitEnterFullscreen
i.hasNativeFullscreen="undefined"!==typeof t.requestFullscreen
i.hasWebkitNativeFullScreen="undefined"!==typeof t.webkitRequestFullScreen
i.hasMozNativeFullScreen="undefined"!==typeof t.mozRequestFullScreen
i.hasMsNativeFullScreen="undefined"!==typeof t.msRequestFullscreen
i.hasTrueNativeFullScreen=i.hasWebkitNativeFullScreen||i.hasMozNativeFullScreen||i.hasMsNativeFullScreen
i.nativeFullScreenEnabled=i.hasTrueNativeFullScreen
i.hasMozNativeFullScreen?i.nativeFullScreenEnabled=document.mozFullScreenEnabled:i.hasMsNativeFullScreen&&(i.nativeFullScreenEnabled=document.msFullscreenEnabled)
i.isChrome&&(i.hasiOSFullScreen=false)
if(i.hasTrueNativeFullScreen){i.fullScreenEventName=""
i.hasWebkitNativeFullScreen?i.fullScreenEventName="webkitfullscreenchange":i.hasMozNativeFullScreen?i.fullScreenEventName="mozfullscreenchange":i.hasMsNativeFullScreen&&(i.fullScreenEventName="MSFullscreenChange")
i.isFullScreen=function(){if(i.hasMozNativeFullScreen)return o.mozFullScreen
if(i.hasWebkitNativeFullScreen)return o.webkitIsFullScreen
if(i.hasMsNativeFullScreen)return null!==o.msFullscreenElement}
i.requestFullScreen=function(e){i.hasWebkitNativeFullScreen?e.webkitRequestFullScreen():i.hasMozNativeFullScreen?e.mozRequestFullScreen():i.hasMsNativeFullScreen&&e.msRequestFullscreen()}
i.cancelFullScreen=function(){i.hasWebkitNativeFullScreen?document.webkitCancelFullScreen():i.hasMozNativeFullScreen?document.mozCancelFullScreen():i.hasMsNativeFullScreen&&document.msExitFullscreen()}}if(i.hasiOSFullScreen&&r.match(/mac os x 10_5/i)){i.hasNativeFullScreen=false
i.hasiOSFullScreen=false}}}
n.MediaFeatures.init()
n.HtmlMediaElement={pluginType:"native",isFullScreen:false,setCurrentTime:function(e){this.currentTime=e},setMuted:function(e){this.muted=e},setVolume:function(e){this.volume=e},stop:function(){this.pause()},setSrc:function(e){var t=this.getElementsByTagName("source")
while(t.length>0)this.removeChild(t[0])
if("string"==typeof e)this.src=e
else{var i,n
for(i=0;i<e.length;i++){n=e[i]
if(this.canPlayType(n.type)){this.src=n.src
break}}}},setVideoSize:function(e,t){this.width=e
this.height=t}}
n.PluginMediaElement=function(e,t,i){this.id=e
this.pluginType=t
this.src=i
this.events={}
this.attributes={}}
n.PluginMediaElement.prototype={pluginElement:null,pluginType:"",isFullScreen:false,playbackRate:-1,defaultPlaybackRate:-1,seekable:[],played:[],paused:true,ended:false,seeking:false,duration:0,error:null,tagName:"",muted:false,volume:1,currentTime:0,play:function(){if(null!=this.pluginApi){"youtube"==this.pluginType||"vimeo"==this.pluginType?this.pluginApi.playVideo():this.pluginApi.playMedia()
this.paused=false}},load:function(){if(null!=this.pluginApi){"youtube"==this.pluginType||"vimeo"==this.pluginType||this.pluginApi.loadMedia()
this.paused=false}},pause:function(){if(null!=this.pluginApi){"youtube"==this.pluginType||"vimeo"==this.pluginType?1==this.pluginApi.getPlayerState()&&this.pluginApi.pauseVideo():this.pluginApi.pauseMedia()
this.paused=true}},stop:function(){if(null!=this.pluginApi){"youtube"==this.pluginType||"vimeo"==this.pluginType?this.pluginApi.stopVideo():this.pluginApi.stopMedia()
this.paused=true}},canPlayType:function(e){var t,i,o,a=n.plugins[this.pluginType]
for(t=0;t<a.length;t++){o=a[t]
if(n.PluginDetector.hasPluginVersion(this.pluginType,o.version))for(i=0;i<o.types.length;i++)if(e==o.types[i])return"probably"}return""},positionFullscreenButton:function(e,t,i){null!=this.pluginApi&&this.pluginApi.positionFullscreenButton&&this.pluginApi.positionFullscreenButton(Math.floor(e),Math.floor(t),i)},hideFullscreenButton:function(){null!=this.pluginApi&&this.pluginApi.hideFullscreenButton&&this.pluginApi.hideFullscreenButton()},setSrc:function(e){if("string"==typeof e){this.pluginApi.setSrc(n.Utility.absolutizeUrl(e))
this.src=n.Utility.absolutizeUrl(e)}else{var t,i
for(t=0;t<e.length;t++){i=e[t]
if(this.canPlayType(i.type)){this.pluginApi.setSrc(n.Utility.absolutizeUrl(i.src))
this.src=n.Utility.absolutizeUrl(i.src)
break}}}},setCurrentTime:function(e){if(null!=this.pluginApi){"youtube"==this.pluginType||"vimeo"==this.pluginType?this.pluginApi.seekTo(e):this.pluginApi.setCurrentTime(e)
this.currentTime=e}},setVolume:function(e){if(null!=this.pluginApi){"youtube"==this.pluginType?this.pluginApi.setVolume(100*e):this.pluginApi.setVolume(e)
this.volume=e}},setMuted:function(e){if(null!=this.pluginApi){if("youtube"==this.pluginType){e?this.pluginApi.mute():this.pluginApi.unMute()
this.muted=e
this.dispatchEvent({type:"volumechange"})}else this.pluginApi.setMuted(e)
this.muted=e}},setVideoSize:function(e,t){if(this.pluginElement&&this.pluginElement.style){this.pluginElement.style.width=e+"px"
this.pluginElement.style.height=t+"px"}null!=this.pluginApi&&this.pluginApi.setVideoSize&&this.pluginApi.setVideoSize(e,t)},setFullscreen:function(e){null!=this.pluginApi&&this.pluginApi.setFullscreen&&this.pluginApi.setFullscreen(e)},enterFullScreen:function(){null!=this.pluginApi&&this.pluginApi.setFullscreen&&this.setFullscreen(true)},exitFullScreen:function(){null!=this.pluginApi&&this.pluginApi.setFullscreen&&this.setFullscreen(false)},addEventListener:function(e,t,i){this.events[e]=this.events[e]||[]
this.events[e].push(t)},removeEventListener:function(e,t){if(!e){this.events={}
return true}var i=this.events[e]
if(!i)return true
if(!t){this.events[e]=[]
return true}for(var n=0;n<i.length;n++)if(i[n]===t){this.events[e].splice(n,1)
return true}return false},dispatchEvent:function(e){var t,i=this.events[e.type]
if(i)for(t=0;t<i.length;t++)i[t].apply(this,[e])},hasAttribute:function(e){return e in this.attributes},removeAttribute:function(e){delete this.attributes[e]},getAttribute:function(e){if(this.hasAttribute(e))return this.attributes[e]
return null},setAttribute:function(e,t){this.attributes[e]=t},remove:function(){n.Utility.removeSwf(this.pluginElement.id)}}
n.MediaElementDefaults={mode:"auto",plugins:["flash","silverlight","youtube","vimeo"],enablePluginDebug:false,httpsBasicAuthSite:false,type:"",pluginPath:n.Utility.getScriptPath(["mediaelement.js","mediaelement.min.js","mediaelement-and-player.js","mediaelement-and-player.min.js"]),flashName:"flashmediaelement.swf",flashStreamer:"",flashScriptAccess:"sameDomain",enablePluginSmoothing:false,enablePseudoStreaming:false,pseudoStreamingStartQueryParam:"start",silverlightName:"silverlightmediaelement.xap",defaultVideoWidth:480,defaultVideoHeight:270,pluginWidth:-1,pluginHeight:-1,pluginVars:[],timerRate:250,startVolume:.8,customError:"",youtubePlayerVars:{controls:0},success:function(){},error:function(){}}
n.MediaElement=function(e,t){return n.HtmlMediaElementShim.create(e,t)}
n.HtmlMediaElementShim={create:function(e,t){var i,o,a={},r="string"==typeof e?document.getElementById(e):e,s=r.tagName.toLowerCase(),l="audio"===s||"video"===s,d=l?r.getAttribute("src"):r.getAttribute("href"),u=r.getAttribute("poster"),c=r.getAttribute("autoplay"),m=r.getAttribute("preload"),p=r.getAttribute("controls")
for(o in n.MediaElementDefaults)a[o]=n.MediaElementDefaults[o]
for(o in t)a[o]=t[o]
d="undefined"==typeof d||null===d||""==d?null:d
u="undefined"==typeof u||null===u?"":u
m="undefined"==typeof m||null===m||"false"===m?"none":m
c=!("undefined"==typeof c||null===c||"false"===c)
p=!("undefined"==typeof p||null===p||"false"===p)
i=this.determinePlayback(r,a,n.MediaFeatures.supportsMediaTag,l,d)
i.url=null!==i.url?n.Utility.absolutizeUrl(i.url):""
i.scheme=n.Utility.determineScheme(i.url)
if("native"==i.method){if(n.MediaFeatures.isBustedAndroid){r.src=i.url
r.addEventListener("click",(function(){r.play()}),false)}return this.updateNative(i,a,c,m)}if(""!==i.method)return this.createPlugin(i,a,u,c,m,p)
this.createErrorMessage(i,a,u)
return this},determinePlayback:function(e,t,i,o,a){var r,s,l,d,u,c,m,p,f,h,g,b=[],v={method:"",url:"",htmlMediaElement:e,isVideo:"audio"!==e.tagName.toLowerCase(),scheme:""}
if("undefined"!=typeof t.type&&""!==t.type)if("string"==typeof t.type)b.push({type:t.type,url:a})
else for(r=0;r<t.type.length;r++)b.push({type:t.type[r],url:a})
else if(null!==a){c=this.formatType(a,e.getAttribute("type"))
b.push({type:c,url:a})}else for(r=0;r<e.childNodes.length;r++){u=e.childNodes[r]
if(1==u.nodeType&&"source"==u.tagName.toLowerCase()){a=u.getAttribute("src")
c=this.formatType(a,u.getAttribute("type"))
g=u.getAttribute("media");(!g||!window.matchMedia||window.matchMedia&&window.matchMedia(g).matches)&&b.push({type:c,url:a})}}!o&&b.length>0&&null!==b[0].url&&this.getTypeFromFile(b[0].url).indexOf("audio")>-1&&(v.isVideo=false)
v.isVideo&&n.MediaFeatures.isBustedAndroid&&(e.canPlayType=function(e){return null!==e.match(/video\/(mp4|m4v)/gi)?"maybe":""})
v.isVideo&&n.MediaFeatures.isChromium&&(e.canPlayType=function(e){return null!==e.match(/video\/(webm|ogv|ogg)/gi)?"maybe":""})
if(i&&("auto"===t.mode||"auto_plugin"===t.mode||"native"===t.mode)&&!(n.MediaFeatures.isBustedNativeHTTPS&&true===t.httpsBasicAuthSite)){if(!o){h=document.createElement(v.isVideo?"video":"audio")
e.parentNode.insertBefore(h,e)
e.style.display="none"
v.htmlMediaElement=e=h}for(r=0;r<b.length;r++)if("video/m3u8"==b[r].type||""!==e.canPlayType(b[r].type).replace(/no/,"")||""!==e.canPlayType(b[r].type.replace(/mp3/,"mpeg")).replace(/no/,"")||""!==e.canPlayType(b[r].type.replace(/m4a/,"mp4")).replace(/no/,"")){v.method="native"
v.url=b[r].url
break}if("native"===v.method){null!==v.url&&(e.src=v.url)
if("auto_plugin"!==t.mode)return v}}if("auto"===t.mode||"auto_plugin"===t.mode||"shim"===t.mode)for(r=0;r<b.length;r++){c=b[r].type
for(s=0;s<t.plugins.length;s++){m=t.plugins[s]
p=n.plugins[m]
for(l=0;l<p.length;l++){f=p[l]
if(null==f.version||n.PluginDetector.hasPluginVersion(m,f.version))for(d=0;d<f.types.length;d++)if(c.toLowerCase()==f.types[d].toLowerCase()){v.method=m
v.url=b[r].url
return v}}}}if("auto_plugin"===t.mode&&"native"===v.method)return v
""===v.method&&b.length>0&&(v.url=b[0].url)
return v},formatType:function(e,t){return e&&!t?this.getTypeFromFile(e):t&&~t.indexOf(";")?t.substr(0,t.indexOf(";")):t},getTypeFromFile:function(e){e=e.split("?")[0]
var t=e.substring(e.lastIndexOf(".")+1).toLowerCase(),i=/(mp4|m4v|ogg|ogv|m3u8|webm|webmv|flv|wmv|mpeg|mov)/gi.test(t)?"video/":"audio/"
return this.getTypeFromExtension(t,i)},getTypeFromExtension:function(e,t){t=t||""
switch(e){case"mp4":case"m4v":case"m4a":case"f4v":case"f4a":return t+"mp4"
case"flv":return t+"x-flv"
case"webm":case"webma":case"webmv":return t+"webm"
case"ogg":case"oga":case"ogv":return t+"ogg"
case"m3u8":return"application/x-mpegurl"
case"ts":return t+"mp2t"
default:return t+e}},createErrorMessage:function(e,t,i){var o=e.htmlMediaElement,a=document.createElement("div"),r=t.customError
a.className="me-cannotplay"
try{a.style.width=o.width+"px"
a.style.height=o.height+"px"}catch(e){}if(!r){r='<a href="'+e.url+'">'
""!==i&&(r+='<img src="'+i+'" width="100%" height="100%" alt="" />')
r+="<span>"+n.i18n.t("mejs.download-file")+"</span></a>"}a.innerHTML=r
o.parentNode.insertBefore(a,o)
o.style.display="none"
t.error(o)},createPlugin:function(e,t,i,o,a,r){var s,l,d,u=e.htmlMediaElement,c=1,m=1,p="me_"+e.method+"_"+n.meIndex++,f=new n.PluginMediaElement(p,e.method,e.url),h=document.createElement("div")
f.tagName=u.tagName
for(var g=0;g<u.attributes.length;g++){var b=u.attributes[g]
b.specified&&f.setAttribute(b.name,b.value)}l=u.parentNode
while(null!==l&&null!=l.tagName&&"body"!==l.tagName.toLowerCase()&&null!=l.parentNode&&null!=l.parentNode.tagName&&null!=l.parentNode.constructor&&"ShadowRoot"===l.parentNode.constructor.name){if("p"===l.parentNode.tagName.toLowerCase()){l.parentNode.parentNode.insertBefore(l,l.parentNode)
break}l=l.parentNode}if(e.isVideo){c=t.pluginWidth>0?t.pluginWidth:t.videoWidth>0?t.videoWidth:null!==u.getAttribute("width")?u.getAttribute("width"):t.defaultVideoWidth
m=t.pluginHeight>0?t.pluginHeight:t.videoHeight>0?t.videoHeight:null!==u.getAttribute("height")?u.getAttribute("height"):t.defaultVideoHeight
c=n.Utility.encodeUrl(c)
m=n.Utility.encodeUrl(m)}else if(t.enablePluginDebug){c=320
m=240}f.success=t.success
h.className="me-plugin"
h.id=p+"_container"
e.isVideo?u.parentNode.insertBefore(h,u):document.body.insertBefore(h,document.body.childNodes[0])
if("flash"===e.method||"silverlight"===e.method){var v="audio/mp4"===u.getAttribute("type"),y=u.getElementsByTagName("source")
if(y&&!v){g=0
for(var j=y.length;g<j;g++)"audio/mp4"===y[g].getAttribute("type")&&(v=true)}d=["id="+p,"isvideo="+(e.isVideo||v?"true":"false"),"autoplay="+(o?"true":"false"),"preload="+a,"width="+c,"startvolume="+t.startVolume,"timerrate="+t.timerRate,"flashstreamer="+t.flashStreamer,"height="+m,"pseudostreamstart="+t.pseudoStreamingStartQueryParam]
null!==e.url&&("flash"==e.method?d.push("file="+n.Utility.encodeUrl(e.url)):d.push("file="+e.url))
t.enablePluginDebug&&d.push("debug=true")
t.enablePluginSmoothing&&d.push("smoothing=true")
t.enablePseudoStreaming&&d.push("pseudostreaming=true")
r&&d.push("controls=true")
t.pluginVars&&(d=d.concat(t.pluginVars))
window[p+"_init"]=function(){switch(f.pluginType){case"flash":f.pluginElement=f.pluginApi=document.getElementById(p)
break
case"silverlight":f.pluginElement=document.getElementById(f.id)
f.pluginApi=f.pluginElement.Content.MediaElementJS}null!=f.pluginApi&&f.success&&f.success(f,u)}
window[p+"_event"]=function(e,t){var i,n,o
i={type:e,target:f}
for(n in t){f[n]=t[n]
i[n]=t[n]}o=t.bufferedTime||0
i.target.buffered=i.buffered={start:function(e){return 0},end:function(e){return o},length:1}
f.dispatchEvent(i)}}switch(e.method){case"silverlight":h.innerHTML='<object data="data:application/x-silverlight-2," type="application/x-silverlight-2" id="'+p+'" name="'+p+'" width="'+c+'" height="'+m+'" class="mejs-shim"><param name="initParams" value="'+d.join(",")+'" /><param name="windowless" value="true" /><param name="background" value="black" /><param name="minRuntimeVersion" value="3.0.0.0" /><param name="autoUpgrade" value="true" /><param name="source" value="'+t.pluginPath+t.silverlightName+'" /></object>'
break
case"flash":if(n.MediaFeatures.isIE){s=document.createElement("div")
h.appendChild(s)
s.outerHTML='<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="//download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab" id="'+p+'" width="'+c+'" height="'+m+'" class="mejs-shim"><param name="movie" value="'+t.pluginPath+t.flashName+"?"+(new Date).getTime()+'" /><param name="flashvars" value="'+d.join("&amp;")+'" /><param name="quality" value="high" /><param name="bgcolor" value="#000000" /><param name="wmode" value="transparent" /><param name="allowScriptAccess" value="'+t.flashScriptAccess+'" /><param name="allowFullScreen" value="true" /><param name="scale" value="default" /></object>'}else h.innerHTML='<embed id="'+p+'" name="'+p+'" play="true" loop="false" quality="high" bgcolor="#000000" wmode="transparent" allowScriptAccess="'+t.flashScriptAccess+'" allowFullScreen="true" type="application/x-shockwave-flash" pluginspage="//www.macromedia.com/go/getflashplayer" src="'+t.pluginPath+t.flashName+'" flashvars="'+d.join("&")+'" width="'+c+'" height="'+m+'" scale="default"class="mejs-shim"></embed>'
break
case"youtube":var k
if(-1!=e.url.lastIndexOf("youtu.be")){k=e.url.substr(e.url.lastIndexOf("/")+1);-1!=k.indexOf("?")&&(k=k.substr(0,k.indexOf("?")))}else{var w=e.url.match(/[?&]v=([^&#]+)|&|#|$/)
w&&(k=w[1])}youtubeSettings={container:h,containerId:h.id,pluginMediaElement:f,pluginId:p,videoId:k,height:m,width:c,scheme:e.scheme,playerVars:t.youtubePlayerVars}
window.postMessage?n.YouTubeApi.enqueueIframe(youtubeSettings):n.PluginDetector.hasPluginVersion("flash",[10,0,0])&&n.YouTubeApi.createFlash(youtubeSettings,t)
break
case"vimeo":var x=p+"_player"
f.vimeoid=e.url.substr(e.url.lastIndexOf("/")+1)
h.innerHTML='<iframe src="'+e.scheme+"player.vimeo.com/video/"+f.vimeoid+"?api=1&portrait=0&byline=0&title=0&player_id="+x+'" width="'+c+'" height="'+m+'" frameborder="0" class="mejs-shim" id="'+x+'" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>'
if("function"==typeof $f){var T=$f(h.childNodes[0]),_=-1
T.addEvent("ready",(function(){T.playVideo=function(){T.api("play")}
T.stopVideo=function(){T.api("unload")}
T.pauseVideo=function(){T.api("pause")}
T.seekTo=function(e){T.api("seekTo",e)}
T.setVolume=function(e){T.api("setVolume",e)}
T.setMuted=function(e){if(e){T.lastVolume=T.api("getVolume")
T.api("setVolume",0)}else{T.api("setVolume",T.lastVolume)
delete T.lastVolume}}
T.getPlayerState=function(){return _}
function e(e,t,i,n){var o={type:i,target:t}
if("timeupdate"==i){t.currentTime=o.currentTime=n.seconds
t.duration=o.duration=n.duration}t.dispatchEvent(o)}T.addEvent("play",(function(){_=1
e(T,f,"play")
e(T,f,"playing")}))
T.addEvent("pause",(function(){_=2
e(T,f,"pause")}))
T.addEvent("finish",(function(){_=0
e(T,f,"ended")}))
T.addEvent("playProgress",(function(t){e(T,f,"timeupdate",t)}))
T.addEvent("seek",(function(t){_=3
e(T,f,"seeked",t)}))
T.addEvent("loadProgress",(function(t){_=3
e(T,f,"progress",t)}))
f.pluginElement=h
f.pluginApi=T
f.success(f,f.pluginElement)}))}else console.warn("You need to include froogaloop for vimeo to work")}u.style.display="none"
u.removeAttribute("autoplay")
return f},updateNative:function(e,t,i,o){var a,r=e.htmlMediaElement
for(a in n.HtmlMediaElement)r[a]=n.HtmlMediaElement[a]
t.success(r,r)
return r}}
function o(){var e=null
var t=function(){clearInterval(e)
e=null}
return function(i,o,a){!e&&a?e=setInterval((function(){document.body.contains(o.pluginElement)?n.YouTubeApi.createEvent(i,o,"timeupdate"):t()}),250):e&&!a&&t()}}n.YouTubeApi={isIframeStarted:false,isIframeLoaded:false,loadIframeApi:function(e){if(!this.isIframeStarted){var t=document.createElement("script")
t.src=e.scheme+"www.youtube.com/player_api"
var i=document.getElementsByTagName("script")[0]
i.parentNode.insertBefore(t,i)
this.isIframeStarted=true}},iframeQueue:[],enqueueIframe:function(e){if(this.isLoaded)this.createIframe(e)
else{this.loadIframeApi(e)
this.iframeQueue.push(e)}},createIframe:function(e){var t,i=e.pluginMediaElement,o=new YT.Player(e.containerId,{height:e.height,width:e.width,videoId:e.videoId,playerVars:e.playerVars,events:{onReady:function(a){o.setVideoSize=function(e,t){o.setSize(e,t)}
e.pluginMediaElement.pluginApi=o
e.pluginMediaElement.pluginElement=document.getElementById(e.containerId)
i.success(i,i.pluginElement)
n.YouTubeApi.createEvent(o,i,"loadstart")
n.YouTubeApi.createEvent(o,i,"canplay")
n.YouTubeApi.createEvent(o,i,"loadedmetadata")
var r=e.pluginMediaElement.pluginApi.seekTo.bind(o)
e.pluginMediaElement.pluginApi.seekTo=function(e,a){var s=o.getCurrentTime()
var l=function(){clearTimeout(t)
t=setTimeout((function(){if(o.getCurrentTime()===s)return l()
n.YouTubeApi.createEvent(o,i,"seeked")
n.YouTubeApi.createEvent(o,i,"timeupdate")}),50)}
r(e,a)
l()}
"undefined"!==typeof i.attributes.autoplay&&o.playVideo()
var s=o.setVolume.bind(o)
o.setVolume=function(e){s(e)
setTimeout((function(){n.YouTubeApi.createEvent(o,i,"volumechange")}),100)}},onStateChange:function(e){n.YouTubeApi.handleStateChange(e.data,o,i)}}})},createEvent:function(e,t,i){var n={type:i,target:t}
if(e&&e.getDuration){t.currentTime=n.currentTime=e.getCurrentTime()
t.duration=n.duration=e.getDuration()
n.paused=t.paused
n.ended=t.ended
n.muted=e.isMuted()
n.volume=e.getVolume()/100
n.bytesTotal=e.getVideoBytesTotal()
n.bufferedBytes=e.getVideoBytesLoaded()
var o=n.bufferedBytes/n.bytesTotal*n.duration
n.target.buffered=n.buffered={start:function(e){return 0},end:function(e){return o},length:1}}t.dispatchEvent(n)},iFrameReady:function(){this.isLoaded=true
this.isIframeLoaded=true
while(this.iframeQueue.length>0){var e=this.iframeQueue.pop()
this.createIframe(e)}},flashPlayers:{},createFlash:function(e){this.flashPlayers[e.pluginId]=e
var t,i=e.scheme+"www.youtube.com/apiplayer?enablejsapi=1&amp;playerapiid="+e.pluginId+"&amp;version=3&amp;autoplay=0&amp;controls=0&amp;modestbranding=1&loop=0"
if(n.MediaFeatures.isIE){t=document.createElement("div")
e.container.appendChild(t)
t.outerHTML='<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="'+e.scheme+'download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab" id="'+e.pluginId+'" width="'+e.width+'" height="'+e.height+'" class="mejs-shim"><param name="movie" value="'+i+'" /><param name="wmode" value="transparent" /><param name="allowScriptAccess" value="'+options.flashScriptAccess+'" /><param name="allowFullScreen" value="true" /></object>'}else e.container.innerHTML='<object type="application/x-shockwave-flash" id="'+e.pluginId+'" data="'+i+'" width="'+e.width+'" height="'+e.height+'" style="visibility: visible; " class="mejs-shim"><param name="allowScriptAccess" value="'+options.flashScriptAccess+'"><param name="wmode" value="transparent"></object>'},flashReady:function(e){var t=this.flashPlayers[e],i=document.getElementById(e),o=t.pluginMediaElement
o.pluginApi=o.pluginElement=i
t.success(o,o.pluginElement)
i.cueVideoById(t.videoId)
var a=t.containerId+"_callback"
window[a]=function(e){n.YouTubeApi.handleStateChange(e,i,o)}
i.addEventListener("onStateChange",a)
setInterval((function(){n.YouTubeApi.createEvent(i,o,"timeupdate")}),250)
n.YouTubeApi.createEvent(i,o,"loadstart")
n.YouTubeApi.createEvent(i,o,"canplay")},toggleTimeupdates:o(),handleStateChange:function(e,t,i){switch(e){case YT.PlayerState.UNSTARTED:i.paused=true
i.ended=true
n.YouTubeApi.createEvent(t,i,"unstarted")
n.YouTubeApi.toggleTimeupdates(t,i,false)
break
case YT.PlayerState.ENDED:i.paused=false
i.ended=true
n.YouTubeApi.createEvent(t,i,"ended")
n.YouTubeApi.toggleTimeupdates(t,i,false)
break
case YT.PlayerState.PLAYING:i.paused=false
i.ended=false
n.YouTubeApi.createEvent(t,i,"play")
n.YouTubeApi.createEvent(t,i,"playing")
n.YouTubeApi.toggleTimeupdates(t,i,true)
break
case YT.PlayerState.PAUSED:i.paused=true
i.ended=false
n.YouTubeApi.createEvent(t,i,"pause")
n.YouTubeApi.toggleTimeupdates(t,i,false)
break
case YT.PlayerState.BUFFERING:n.YouTubeApi.createEvent(t,i,"progress")
break
case YT.PlayerState.CUED:}}}
window.onYouTubePlayerAPIReady=function(){n.YouTubeApi.iFrameReady()}
window.onYouTubePlayerReady=function(e){n.YouTubeApi.flashReady(e)}
window.mejs=n
window.MediaElement=n.MediaElement;(function(e,t,i,n){var o={default:"en",locale:{language:i.i18n&&i.i18n.locale.language||"",strings:i.i18n&&i.i18n.locale.strings||{}},pluralForms:[function(){return arguments[1]},function(){var e=arguments
return 1===e[0]?e[1]:e[2]},function(){var e=arguments
return[0,1].indexOf(e[0])>-1?e[1]:e[2]},function(){var e=arguments
return e[0]%10===1&&e[0]%100!==11?e[1]:0!==e[0]?e[2]:e[3]},function(){var e=arguments
return 1===e[0]||11===e[0]?e[1]:2===e[0]||12===e[0]?e[2]:e[0]>2&&e[0]<20?e[3]:e[4]},function(){return 1===args[0]?args[1]:0===args[0]||args[0]%100>0&&args[0]%100<20?args[2]:args[3]},function(){var e=arguments
return e[0]%10===1&&e[0]%100!==11?e[1]:e[0]%10>=2&&(e[0]%100<10||e[0]%100>=20)?e[2]:[3]},function(){var e=arguments
return e[0]%10===1&&e[0]%100!==11?e[1]:e[0]%10>=2&&e[0]%10<=4&&(e[0]%100<10||e[0]%100>=20)?e[2]:e[3]},function(){var e=arguments
return 1===e[0]?e[1]:e[0]>=2&&e[0]<=4?e[2]:e[3]},function(){var e=arguments
return 1===e[0]?e[1]:e[0]%10>=2&&e[0]%10<=4&&(e[0]%100<10||e[0]%100>=20)?e[2]:e[3]},function(){var e=arguments
return e[0]%100===1?e[2]:e[0]%100===2?e[3]:e[0]%100===3||e[0]%100===4?e[4]:e[1]},function(){var e=arguments
return 1===e[0]?e[1]:2===e[0]?e[2]:e[0]>2&&e[0]<7?e[3]:e[0]>6&&e[0]<11?e[4]:e[5]},function(){var e=arguments
return 0===e[0]?e[1]:1===e[0]?e[2]:2===e[0]?e[3]:e[0]%100>=3&&e[0]%100<=10?e[4]:e[0]%100>=11?e[5]:e[6]},function(){var e=arguments
return 1===e[0]?e[1]:0===e[0]||e[0]%100>1&&e[0]%100<11?e[2]:e[0]%100>10&&e[0]%100<20?e[3]:e[4]},function(){var e=arguments
return e[0]%10===1?e[1]:e[0]%10===2?e[2]:e[3]},function(){var e=arguments
return 11!==e[0]&&e[0]%10===1?e[1]:e[2]},function(){var e=arguments
return 1===e[0]?e[1]:e[0]%10>=2&&e[0]%10<=4&&(e[0]%100<10||e[0]%100>=20)?e[2]:e[3]},function(){var e=arguments
return 1===e[0]?e[1]:2===e[0]?e[2]:8!==e[0]&&11!==e[0]?e[3]:e[4]},function(){var e=arguments
return 0===e[0]?e[1]:e[2]},function(){var e=arguments
return 1===e[0]?e[1]:2===e[0]?e[2]:3===e[0]?e[3]:e[4]},function(){var e=arguments
return 0===e[0]?e[1]:1===e[0]?e[2]:e[3]}],getLanguage:function(){var e=o.locale.language||o["default"]
return/^(x\-)?[a-z]{2,}(\-\w{2,})?(\-\w{2,})?$/.exec(e)?e:o["default"]},t:function(e,t){if("string"===typeof e&&e.length){var i,n,a=o.getLanguage(),r=function(e,t,i){if("object"!==typeof e||"number"!==typeof t||"number"!==typeof i)return e
if("string"===typeof e)return e
return o.pluralForms[i].apply(null,[t].concat(e))},s=function(e){var t={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}
return e.replace(/[&<>"]/g,(function(e){return t[e]}))}
if(o.locale.strings&&o.locale.strings[a]){i=o.locale.strings[a][e]
if("number"===typeof t){n=o.locale.strings[a]["mejs.plural-form"]
i=r.apply(null,[i,t,n])}}if(!i&&o.locale.strings&&o.locale.strings[o["default"]]){i=o.locale.strings[o["default"]][e]
if("number"===typeof t){n=o.locale.strings[o["default"]]["mejs.plural-form"]
i=r.apply(null,[i,t,n])}}i=i||e
"number"===typeof t&&(i=i.replace("%1",t))
return s(i)}return e}}
"undefined"!==typeof mejsL10n&&(o.locale.language=mejsL10n.language)
i.i18n=o})(document,window,n);(function(e,t){"use strict"
"undefined"!==typeof mejsL10n&&(e[mejsL10n.language]=mejsL10n.strings)})(n.i18n.locale.strings);(function(e){"use strict"
void 0===e.en&&(e.en={"mejs.plural-form":1,"mejs.download-file":"Download File","mejs.fullscreen-off":"Turn off Fullscreen","mejs.fullscreen-on":"Go Fullscreen","mejs.download-video":"Download Video","mejs.fullscreen":"Fullscreen","mejs.time-jump-forward":["Jump forward 1 second","Jump forward %1 seconds"],"mejs.play":"Play","mejs.pause":"Pause","mejs.close":"Close","mejs.time-slider":"Time Slider","mejs.time-help-text":"Use Left/Right Arrow keys to advance one second, Up/Down arrows to advance ten seconds.","mejs.time-skip-back":["Skip back 1 second","Skip back %1 seconds"],"mejs.captions-subtitles":"Captions/Subtitles","mejs.none":"None","mejs.mute-toggle":"Mute Toggle","mejs.volume-help-text":"Use Up/Down Arrow keys to increase or decrease volume.","mejs.unmute":"Unmute","mejs.mute":"Mute","mejs.volume-slider":"Volume Slider","mejs.video-player":"Video Player","mejs.audio-player":"Audio Player","mejs.ad-skip":"Skip ad","mejs.ad-skip-info":["Skip in 1 second","Skip in %1 seconds"],"mejs.source-chooser":"Source Chooser"})})(n.i18n.locale.strings)},O3h1:function(e,t,i){var n={"./me-i18n-locale-cs":["Zjte",3698],"./me-i18n-locale-cs.js":["Zjte",3698],"./me-i18n-locale-de":["C7He",3699],"./me-i18n-locale-de.js":["C7He",3699],"./me-i18n-locale-en":["tYpR",3700],"./me-i18n-locale-en.js":["tYpR",3700],"./me-i18n-locale-es":["KY2I",3701],"./me-i18n-locale-es.js":["KY2I",3701],"./me-i18n-locale-fr":["HiGp",3702],"./me-i18n-locale-fr.js":["HiGp",3702],"./me-i18n-locale-hu":["/Xzx",3703],"./me-i18n-locale-hu.js":["/Xzx",3703],"./me-i18n-locale-it":["bsL9",3704],"./me-i18n-locale-it.js":["bsL9",3704],"./me-i18n-locale-ja":["aVOL",3705],"./me-i18n-locale-ja.js":["aVOL",3705],"./me-i18n-locale-ko":["xv0d",3706],"./me-i18n-locale-ko.js":["xv0d",3706],"./me-i18n-locale-nl":["GE+S",3707],"./me-i18n-locale-nl.js":["GE+S",3707],"./me-i18n-locale-pl":["x7au",3708],"./me-i18n-locale-pl.js":["x7au",3708],"./me-i18n-locale-pt":["on1a",3710],"./me-i18n-locale-pt-br":["OMPk",3709],"./me-i18n-locale-pt-br.js":["OMPk",3709],"./me-i18n-locale-pt.js":["on1a",3710],"./me-i18n-locale-ro":["Wvze",3711],"./me-i18n-locale-ro.js":["Wvze",3711],"./me-i18n-locale-ru":["5Xva",3712],"./me-i18n-locale-ru.js":["5Xva",3712],"./me-i18n-locale-sk":["jZcU",3713],"./me-i18n-locale-sk.js":["jZcU",3713],"./me-i18n-locale-zh":["s1kf",3715],"./me-i18n-locale-zh-cn":["s2+q",3714],"./me-i18n-locale-zh-cn.js":["s2+q",3714],"./me-i18n-locale-zh.js":["s1kf",3715]}
function o(e){if(!i.o(n,e))return Promise.resolve().then((function(){var t=new Error("Cannot find module '"+e+"'")
t.code="MODULE_NOT_FOUND"
throw t}))
var t=n[e],o=t[0]
return i.e(t[1]).then((function(){return i.t(o,7)}))}o.keys=function(){return Object.keys(n)}
o.id="O3h1"
e.exports=o},U4Vp:function(e,t,i){"use strict"
i("ouhR")
i("MoxK")
i("mVe5")
i("Yn//")
i("ucra")
i("BHdR")
i("gH2L")
i("ZDlt")
i("EScf")
i("G7rK")
i("uwCX")
i("V/2H")
i("okCx")
i("iG+V")
i("ZgOa")
i("Mn3D")
var n=i("HGxv")
var o=n["default"].scoped("mepfeaturetracksinstructure")
i("gI0r")
var a=i("stQK");(function(e){e.extend(mejs.MepDefaults,{startLanguage:"",tracksText:"",tracksAriaLive:false,hideCaptionsButtonWhenEmpty:true,toggleCaptionsButtonWhenOnlyOne:false,slidesSelector:""})
e.extend(MediaElementPlayer.prototype,{hasChapters:false,cleartracks(e,t,i,n){if(e){e.captions&&e.captions.remove()
e.chapters&&e.chapters.remove()
e.captionsText&&e.captionsText.remove()
e.captionsButton&&e.captionsButton.remove()}},buildtracks(t,i,n,a){if(0==t.tracks.length&&!t.options.can_add_captions)return
let r,s,l=this,d=l.options.tracksAriaLive?'role="log" aria-live="assertive" aria-atomic="false"':"",u=l.options.tracksText?l.options.tracksText:o.t("Captions/Subtitles")
if(l.domNode.textTracks)for(r=l.domNode.textTracks.length-1;r>=0;r--)l.domNode.textTracks[r].mode="hidden"
l.cleartracks(t,i,n,a)
t.chapters=e('<div class="mejs-chapters mejs-layer"></div>').prependTo(n).hide()
t.captions=e('<div class="mejs-captions-layer mejs-layer"><div class="mejs-captions-position mejs-captions-position-hover" '+d+'><span class="mejs-captions-text"></span></div></div>').prependTo(n).hide()
t.captionsText=t.captions.find(".mejs-captions-text")
t.captionsButton=e('<div class="mejs-button mejs-captions-button"><button type="button" aria-controls="'+l.id+'" title="'+u+'" aria-label="'+u+'"></button><div class="mejs-captions-selector mejs-offscreen" role="menu" aria-expanded="false" aria-hidden="true"><ul><li><input type="radio" name="'+t.id+'_captions" id="'+t.id+'_captions_none" value="none" checked="checked" role="menuitemradio" aria-selected="true" aria-label="'+mejs.i18n.t("mejs.none")+'" tabindex="-1" /><label for="'+t.id+'_captions_none" aria-hidden="true">'+mejs.i18n.t("mejs.none")+"</label></li></ul></div></div>").appendTo(i)
let c=0
for(r=0;r<t.tracks.length;r++){s=t.tracks[r].kind
"subtitles"!==s&&"captions"!==s||c++}let m="none"
if(l.options.toggleCaptionsButtonWhenOnlyOne&&1==c)t.captionsButton.on("click",()=>{null===t.selectedTrack&&(m=t.tracks[0].srclang)
t.setTrack(m)})
else{let i
t.captionsButton.hover(()=>{clearTimeout(i)
t.showCaptionsSelector()},()=>{i=setTimeout(()=>{t.hideCaptionsSelector()},l.options.menuTimeoutMouseLeave)}).on("keydown",(function(i){if("a"===i.target.tagName.toLowerCase())return true
const n=i.keyCode
switch(n){case 32:mejs.MediaFeatures.isFirefox||t.showCaptionsSelector()
e(this).find(".mejs-captions-selector").find("input[type=radio]:checked").first().focus()
break
case 13:t.showCaptionsSelector()
e(this).find(".mejs-captions-selector").find("input[type=radio]:checked").first().focus()
break
case 27:t.hideCaptionsSelector()
e(this).find("button").focus()
break
default:return true}})).on("focusout",mejs.Utility.debounce(i=>{setTimeout(()=>{const i=e(document.activeElement).closest(".mejs-captions-selector")
i.length||t.hideCaptionsSelector()},0)},100)).on("click","input[type=radio]",(function(){m=this.value
t.setTrack(m)})).on("click","button",(function(){if(e(this).siblings(".mejs-captions-selector").hasClass("mejs-offscreen")){t.showCaptionsSelector()
e(this).siblings(".mejs-captions-selector").find("input[type=radio]:checked").first().focus()}else t.hideCaptionsSelector()}))}t.options.alwaysShowControls?t.container.find(".mejs-captions-position").addClass("mejs-captions-position-hover"):t.container.bind("controlsshown",()=>{t.container.find(".mejs-captions-position").addClass("mejs-captions-position-hover")}).bind("controlshidden",()=>{a.paused||t.container.find(".mejs-captions-position").removeClass("mejs-captions-position-hover")})
t.trackToLoad=-1
t.selectedTrack=null
t.isLoadingTrack=false
for(r=0;r<t.tracks.length;r++){s=t.tracks[r].kind
"subtitles"!==s&&"captions"!==s||t.addTrackButton(t.tracks[r].srclang,t.tracks[r].label,t.tracks[r].src)}t.options.can_add_captions&&t.addUploadTrackButton()
t.loadNextTrack()
a.addEventListener("timeupdate",()=>{t.displayCaptions()},false)
if(""!==t.options.slidesSelector){t.slidesContainer=e(t.options.slidesSelector)
a.addEventListener("timeupdate",()=>{t.displaySlides()},false)}a.addEventListener("loadedmetadata",()=>{t.displayChapters()},false)
t.container.hover(()=>{if(t.hasChapters){t.chapters.removeClass("mejs-offscreen")
t.chapters.fadeIn(200).height(t.chapters.find(".mejs-chapter").outerHeight())}},(function(){t.hasChapters&&!a.paused&&t.chapters.fadeOut(200,(function(){e(this).addClass("mejs-offscreen")
e(this).css("display","block")}))}))
l.container.on("controlsresize",()=>{l.adjustLanguageBox()})
null!==t.node.getAttribute("autoplay")&&t.chapters.addClass("mejs-offscreen")},hideCaptionsSelector(){this.captionsButton.find(".mejs-captions-selector").addClass("mejs-offscreen").attr("aria-expanded","false").attr("aria-hidden","true").find("input[type=radio]").attr("tabindex","-1")
this.captionsButton.find(".mejs-captions-selector a").attr("tabindex","-1")},showCaptionsSelector(){this.captionsButton.find(".mejs-captions-selector").removeClass("mejs-offscreen").attr("aria-expanded","true").attr("aria-hidden","false").find("input[type=radio]").attr("tabindex","0")
this.captionsButton.find(".mejs-captions-selector a").attr("tabindex","0")},setTrackAriaLabel(){let e=this.options.tracksText
const t=this.selectedTrack
t&&(e+=": "+t.label)
this.captionsButton.find("button").attr("aria-label",e).attr("title",e)},setTrack(t){let i,n=this
e(this).attr("aria-selected",true).attr("checked","checked")
e(this).closest(".mejs-captions-selector").find("input[type=radio]").not(this).attr("aria-selected","false").removeAttr("checked")
if("none"==t){n.selectedTrack=null
n.captionsButton.removeClass("mejs-captions-enabled")}else for(i=0;i<n.tracks.length;i++)if(n.tracks[i].srclang==t){null===n.selectedTrack&&n.captionsButton.addClass("mejs-captions-enabled")
n.selectedTrack=n.tracks[i]
n.captions.attr("lang",n.selectedTrack.srclang)
n.displayCaptions()
break}n.setTrackAriaLabel()},loadNextTrack(){const e=this
e.trackToLoad++
if(e.trackToLoad<e.tracks.length){e.isLoadingTrack=true
e.loadTrack(e.trackToLoad)}else{e.isLoadingTrack=false
e.checkForTracks()}},loadTrack(t){const i=this,n=i.tracks[t],o=function(){n.isLoaded=true
i.enableTrackButton(n.srclang,n.label)
i.loadNextTrack()}
void 0===n.src&&""===n.src||e.ajax({url:n.src,dataType:"text",success(e){"string"===typeof e&&/<tt\s+xml/gi.exec(e)?n.entries=mejs.TrackFormatParser.dfxp.parse(e):n.entries=mejs.TrackFormatParser.webvtt.parse(e)
o()
"chapters"==n.kind&&i.media.addEventListener("play",()=>{i.media.duration>0&&i.displayChapters(n)},false)
"slides"==n.kind&&i.setupSlides(n)},error(){i.removeTrackButton(n.srclang)
i.loadNextTrack()}})},enableTrackButton(t,i){const n=this
""===i&&(i=mejs.language.codes[t]||t)
n.captionsButton.find("input[value="+t+"]").prop("disabled",false).attr("aria-label",i).siblings("label").text(i)
n.options.startLanguage==t&&e("#"+n.id+"_captions_"+t).prop("checked",true).trigger("click")
n.adjustLanguageBox()},removeTrackButton(e){const t=this
t.captionsButton.find("input[value="+e+"]").closest("li").remove()
t.adjustLanguageBox()},addUploadTrackButton(){const t=this
e('<a href="#" role="button" class="upload-track" tabindex="-1">Upload subtitles</a>').appendTo(t.captionsButton.find("ul")).wrap("<li>").click(e=>{e.preventDefault()
Promise.all([i.e(1),i.e(2),i.e(3),i.e(9),i.e(4168)]).then(i.bind(null,"KWYq")).then(({default:e})=>{new e(t.options.mediaCommentId,t.media.src)})})
t.adjustLanguageBox()},addTrackButton(t,i,n){const a=this
const r=`${a.id}_captions_${t}`
""===i&&(i=mejs.language.codes[t]||t)
const s=e("<li>")
s.append(e('<input type="radio" disabled="disabled" aria-selected="false" tabindex="-1">').attr("name",a.id+"_captions").attr("id",r).attr("aria-label",i).val(t)).append(e('<label aria-hidden="true">').attr("for",r).text(i))
a.options.can_add_captions&&s.append(e('<a href="#" role="button" data-remove="li" tabindex="-1">').attr("data-confirm",o.t("Are you sure you want to delete this track?")).attr("data-url",n).attr("aria-label",o.t("Delete track")).append(e('<span aria-hidden="true">').text("x")))
a.captionsButton.find("ul").append(s)
a.adjustLanguageBox()
a.container.find(".mejs-captions-translations option[value="+t+"]").remove()},adjustLanguageBox(){const e=this
e.captionsButton.find(".mejs-captions-selector").height(e.captionsButton.find(".mejs-captions-selector ul").outerHeight(true)+e.captionsButton.find(".mejs-captions-translations").outerHeight(true))},checkForTracks(){let e=this,t=false
if(e.options.hideCaptionsButtonWhenEmpty){for(let i=0;i<e.tracks.length;i++){const n=e.tracks[i].kind
if(("subtitles"===n||"captions"===n)&&e.tracks[i].isLoaded){t=true
break}}if(!t&&!e.options.can_add_captions){e.captionsButton.hide()
e.setControlsSize()}}},sanitize(e){const t=new DOMParser
const i=t.parseFromString(e,"text/html")
const n=["i","b","u","v","c","ruby","rt","lang","link"]
let o=Array.from(i.body.children||[])
while(o.length){const e=o.shift()
n.includes(e.tagName.toLowerCase())?o=o.concat(Array.from(e.children||[])):e.parentNode.removeChild(e)}const a=i.body.getElementsByTagName("*")
for(let e=0,t=a.length;e<t;e++){const t=a[e].attributes,i=Array.prototype.slice.call(t)
for(let t=0,n=i.length;t<n;t++)i[t].name.startsWith("on")||i[t].value.startsWith("javascript")?a[e].parentNode.removeChild(a[e]):("style"===i[t].name||i[t].name.startsWith("data-"))&&a[e].removeAttribute(i[t].name)}return i.body.innerHTML},displayCaptions(){if("undefined"===typeof this.tracks)return
let e,t=this,i=t.selectedTrack
if(null!==i&&i.isLoaded){for(e=0;e<i.entries.times.length;e++)if(t.media.currentTime>=i.entries.times[e].start&&t.media.currentTime<=i.entries.times[e].stop){t.captionsText.html(t.sanitize(i.entries.text[e])).attr("class","mejs-captions-text "+(i.entries.times[e].identifier||""))
t.captions.show().height(0)
return}t.captions.hide()}else t.captions.hide()},setupSlides(e){const t=this
t.slides=e
t.slides.entries.imgs=[t.slides.entries.text.length]
t.showSlide(0)},showSlide(t){if("undefined"===typeof this.tracks||"undefined"===typeof this.slidesContainer)return
let i=this,n=i.slides.entries.text[t],o=i.slides.entries.imgs[t]
"undefined"===typeof o||"undefined"===typeof o.fadeIn?i.slides.entries.imgs[t]=o=e('<img src="'+n+'">').on("load",()=>{o.appendTo(i.slidesContainer).hide().fadeIn().siblings(":visible").fadeOut()}):o.is(":visible")||o.is(":animated")||o.fadeIn().siblings(":visible").fadeOut()},displaySlides(){if("undefined"===typeof this.slides)return
let e,t=this,i=t.slides
for(e=0;e<i.entries.times.length;e++)if(t.media.currentTime>=i.entries.times[e].start&&t.media.currentTime<=i.entries.times[e].stop){t.showSlide(e)
return}},displayChapters(){let e,t=this
for(e=0;e<t.tracks.length;e++)if("chapters"==t.tracks[e].kind&&t.tracks[e].isLoaded){t.drawChapters(t.tracks[e])
t.hasChapters=true
break}},drawChapters(t){let i,n,o=this,a=0,r=0
o.chapters.empty()
for(i=0;i<t.entries.times.length;i++){n=t.entries.times[i].stop-t.entries.times[i].start
a=Math.floor(n/o.media.duration*100);(a+r>100||i==t.entries.times.length-1&&a+r<100)&&(a=100-r)
o.chapters.append(e('<div class="mejs-chapter" rel="'+t.entries.times[i].start+'" style="left: '+r.toString()+"%;width: "+a.toString()+'%;"><div class="mejs-chapter-block'+(i==t.entries.times.length-1?" mejs-chapter-block-last":"")+'"><span class="ch-title">'+o.sanitize(t.entries.text[i])+'</span><span class="ch-time">'+mejs.Utility.secondsToTimeCode(t.entries.times[i].start,o.options)+"&ndash;"+mejs.Utility.secondsToTimeCode(t.entries.times[i].stop,o.options)+"</span></div></div>"))
r+=a}o.chapters.find("div.mejs-chapter").click((function(){o.media.setCurrentTime(parseFloat(e(this).attr("rel")))
o.media.paused&&o.media.play()}))
o.chapters.show()}})
mejs.language={codes:a["a"]}
mejs.TrackFormatParser={webvtt:{pattern_timecode:/^((?:[0-9]{1,2}:)?[0-9]{2}:[0-9]{2}([,.][0-9]{1,3})?) --\> ((?:[0-9]{1,2}:)?[0-9]{2}:[0-9]{2}([,.][0-9]{3})?)(.*)$/,parse(t){let i,n,o,a=0,r=mejs.TrackFormatParser.split2(t,/\r?\n/),s={text:[],times:[]}
for(;a<r.length;a++){i=this.pattern_timecode.exec(r[a])
if(i&&a<r.length){a-1>=0&&""!==r[a-1]&&(o=r[a-1])
a++
n=r[a]
a++
while(""!==r[a]&&a<r.length){n=n+"\n"+r[a]
a++}n=e.trim(n).replace(/(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/gi,"<a href='$1' target='_blank'>$1</a>")
s.text.push(n)
s.times.push({identifier:o,start:0===mejs.Utility.convertSMPTEtoSeconds(i[1])?.2:mejs.Utility.convertSMPTEtoSeconds(i[1]),stop:mejs.Utility.convertSMPTEtoSeconds(i[3]),settings:i[5]})}o=""}return s}},dfxp:{parse(t){t=e(t).filter("tt")
let i,n,o=0,a=t.children("div").eq(0),r=a.find("p"),s=t.find("#"+a.attr("style")),l={text:[],times:[]}
if(s.length){const e=s.removeAttr("id").get(0).attributes
if(e.length){i={}
for(o=0;o<e.length;o++)i[e[o].name.split(":")[1]]=e[o].value}}for(o=0;o<r.length;o++){var d
const t={start:null,stop:null,style:null}
r.eq(o).attr("begin")&&(t.start=mejs.Utility.convertSMPTEtoSeconds(r.eq(o).attr("begin")))
!t.start&&r.eq(o-1).attr("end")&&(t.start=mejs.Utility.convertSMPTEtoSeconds(r.eq(o-1).attr("end")))
r.eq(o).attr("end")&&(t.stop=mejs.Utility.convertSMPTEtoSeconds(r.eq(o).attr("end")))
!t.stop&&r.eq(o+1).attr("begin")&&(t.stop=mejs.Utility.convertSMPTEtoSeconds(r.eq(o+1).attr("begin")))
if(i){d=""
for(const e in i)d+=e+":"+i[e]+";"}d&&(t.style=d)
0===t.start&&(t.start=.2)
l.times.push(t)
n=e.trim(r.eq(o).html()).replace(/(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/gi,"<a href='$1' target='_blank'>$1</a>")
l.text.push(n)}return l}},split2:(e,t)=>e.split(t)}
3!="x\n\ny".split(/\n/gi).length&&(mejs.TrackFormatParser.split2=function(e,t){let i,n=[],o=""
for(i=0;i<e.length;i++){o+=e.substring(i,i+1)
if(t.test(o)){n.push(o.replace(t,""))
o=""}}n.push(o)
return n})})(mejs.$)
const r=window.MediaElementPlayer.prototype.buildsourcechooser
window.MediaElementPlayer.prototype.buildsourcechooser=function(e,t,i,n){if(!e.isVideo)return
return r.apply(this,arguments)}
window.mejs.MepDefaults.speeds.push("0.50")
i("O3h1")("./me-i18n-locale-"+window.ENV.LOCALE).then(e=>{e&&(window.mejs.i18n.locale.language=window.ENV.LOCALE)}).catch(()=>{})
t["a"]=window.mejs},UYA0:function(e,t,i){var n=i("JPst")
t=n(false)
t.push([e.i,'/*\n * Copyright (C) 2014 - present Instructure, Inc.\n *\n * This file is part of Canvas.\n *\n * Canvas is free software: you can redistribute it and/or modify it under\n * the terms of the GNU Affero General Public License as published by the Free\n * Software Foundation, version 3 of the License.\n *\n * Canvas is distributed in the hope that it will be useful, but WITHOUT ANY\n * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR\n * A PARTICULAR PURPOSE. See the GNU Affero General Public License for more\n * details.\n *\n * You should have received a copy of the GNU Affero General Public License along\n * with this program. If not, see <http://www.gnu.org/licenses/>.\n */\n\n/* customizations to mediaelementplayer css */\n\n/*\n  Because this file is not proccessed by our brandable_css sass pipeline,\n  it cannot use our sass-direction helpers. So we have to handle RTL manually\n  by putting direction-specific styles in [dir="ltr"] or [dir="rtl"] blocks.\n*/\n/* stylelint-disable property-disallowed-list, declaration-property-value-disallowed-list */\n\n/* good menu widths */\n.mejs-sourcechooser-selector {\n  width: 160px;\n}\n.mejs-sourcechooser-selector label {\n  width: 160px !important;\n}\n\n.mejs-captions-selector {\n  width: 105px;\n}\n[dir="ltr"]  .mejs-captions-selector { text-align: left }\n[dir="rtl"]  .mejs-captions-selector { text-align: right }\n\n.mejs-captions-selector label {\n  width: 70px !important;\n}\n\n/* Subtitile upload link */\n.mejs-captions-selector .upload-track {\n  color: white;\n  margin-top: 3px;\n  margin-bottom: 5px;\n}\n[dir="ltr"] .mejs-captions-selector .upload-track {\n  margin-right: 0px;\n  margin-left: 5px;\n  float: left;\n}\n[dir="rtl"] .mejs-captions-selector .upload-track {\n  margin-left: 0px;\n  margin-right: 5px;\n  float: right;\n}\n\n/* "x" button to remove a subtitle */\n.mejs-captions-selector a[data-remove] {\n  position: absolute;\n  top: 0;\n  color: white;\n}\n[dir="ltr"] .mejs-captions-selector a[data-remove] { right: 0 }\n[dir="rtl"] .mejs-captions-selector a[data-remove] { left: 0 }\n\n\n/* style menu items without a radio button */\n.mejs-button [role="menu"] {\n  padding: 0 !important;\n}\n /* compensate for above 0 padding */\n .mejs-button [role="menu"] ul li {\n  position: relative;\n  padding: 0 10px !important;\n}\n/* add a hover effect */\n.mejs-button [role="menu"] ul li:hover {\n  background-color: #c8c8c8 !important;\n  background-color: rgba(255, 255, 255, 0.4) !important;\n}\n.mejs-button [role="menu"] ul li input {\n  border: 0;\n  clip: rect(0 0 0 0);\n  position: absolute;\n  overflow: hidden;\n  margin: -1px;\n  padding: 0;\n  width: 1px;\n  height: 1px;\n}\n.mejs-button [role="menu"] ul li label {\n  cursor: pointer;\n}\n[dir="ltr"] .mejs-button [role="menu"] ul li label { margin-left: 5px }\n[dir="rtl"] .mejs-button [role="menu"] ul li label { margin-right: 5px }\n\n\n.mejs-button [role="menu"] label.mejs-selected {\n  color: #21f8f8 !important;\n}\n\n/* stylelint-enable property-disallowed-list, declaration-property-value-disallowed-list */\n',""])
e.exports=t},"V/2H":function(e,t){(function(e){e.extend(mejs.MepDefaults,{speeds:["2.00","1.50","1.25","1.00","0.75"],defaultSpeed:"1.00",speedChar:"x",speedLabel:"Change playback speed"})
e.extend(MediaElementPlayer.prototype,{buildspeed:function(t,i,n,o){var a=this
var r
if("native"==a.media.pluginType){var s=null,l=null,d=null,u=null,c=null
var m=[]
var p=false
for(var f=0,h=a.options.speeds.length;f<h;f++){var g=a.options.speeds[f]
if("string"===typeof g){m.push({name:g+a.options.speedChar,value:g})
g===a.options.defaultSpeed&&(p=true)}else{m.push(g)
g.value===a.options.defaultSpeed&&(p=true)}}p||m.push({name:a.options.defaultSpeed+a.options.speedChar,value:a.options.defaultSpeed})
m.sort((function(e,t){return parseFloat(t.value)-parseFloat(e.value)}))
var b=function(e){for(f=0,h=m.length;f<h;f++)if(m[f].value===e)return m[f].name}
var v=function(e){return mejs.i18n.t(a.options.speedLabel+": Current speed "+b(e))}
var y='<div class="mejs-button mejs-speed-button"><button role="button" aria-haspopup="true" aria-controls="'+a.id+'" type="button" aria-label="'+v(a.options.defaultSpeed)+'" aria-live="assertive">'+b(a.options.defaultSpeed)+'</button><div class="mejs-speed-selector mejs-offscreen" role="menu" aria-expanded="false" aria-hidden="true"><ul>'
for(f=0,il=m.length;f<il;f++){u=a.id+"-speed-"+m[f].value
c=m[f].value===a.options.defaultSpeed
y+='<li><input type="radio" name="speed" role="menuitemradio"value="'+m[f].value+'" id="'+u+'" '+(c?' checked="checked"':"")+' aria-selected="'+c+'" aria-label="'+b(m[f].value)+'" tabindex="-1" /><label for="'+u+'" aria-hidden="true"'+(c?' class="mejs-speed-selected"':"")+">"+m[f].name+"</label></li>"}y+="</ul></div></div>"
t.speedButton=s=e(y).appendTo(i)
l=s.find(".mejs-speed-selector")
d=a.options.defaultSpeed
o.addEventListener("loadedmetadata",(function(e){d&&(o.playbackRate=parseFloat(d))}),true)
l.on("click",'input[type="radio"]',(function(){e(this).attr("aria-selected",true).attr("checked","checked")
e(this).closest(".mejs-speed-selector").find("input[type=radio]").not(this).attr("aria-selected","false").removeAttr("checked")
var t=e(this).attr("value")
d=t
var i=parseFloat(t)
o.playbackRate=i
a.options.playbackRate=i
s.find("button").html(b(t)).attr("aria-label",v(t))
s.find(".mejs-speed-selected").removeClass("mejs-speed-selected")
s.find('input[type="radio"]:checked').next().addClass("mejs-speed-selected")}))
s.one("mouseenter focusin",(function(){l.height(s.find(".mejs-speed-selector ul").outerHeight(true)+s.find(".mejs-speed-translations").outerHeight(true)).css("top",-1*l.height()+"px")})).hover((function(){clearTimeout(r)
t.showSpeedSelector()}),(function(){r=setTimeout((function(){t.hideSpeedSelector()}),a.options.menuTimeoutMouseLeave)})).on("keydown",(function(i){var n=i.keyCode
switch(n){case 32:mejs.MediaFeatures.isFirefox||t.showSpeedSelector()
e(this).find(".mejs-speed-selector").find("input[type=radio]:checked").first().focus()
break
case 13:t.showSpeedSelector()
e(this).find(".mejs-speed-selector").find("input[type=radio]:checked").first().focus()
break
case 27:t.hideSpeedSelector()
e(this).find("button").focus()
break
default:return true}})).on("focusout",mejs.Utility.debounce((function(i){setTimeout((function(){var i=e(document.activeElement).closest(".mejs-speed-selector")
i.length||t.hideSpeedSelector()}),0)}),100)).on("click","button",(function(i){if(e(this).siblings(".mejs-speed-selector").hasClass("mejs-offscreen")){t.showSpeedSelector()
e(this).siblings(".mejs-speed-selector").find("input[type=radio]:checked").first().focus()}else t.hideSpeedSelector()}))}},hideSpeedSelector:function(){this.speedButton.find(".mejs-speed-selector").addClass("mejs-offscreen").attr("aria-expanded","false").attr("aria-hidden","true").find("input[type=radio]").attr("tabindex","-1")},showSpeedSelector:function(){this.speedButton.find(".mejs-speed-selector").removeClass("mejs-offscreen").attr("aria-expanded","true").attr("aria-hidden","false").find("input[type=radio]").attr("tabindex","0")}})})(mejs.$)},XKWA:function(e,t,i){const n=i("ouhR")
var o,a,r,s=n({})
n.subscribe=o=function(e,t){if(n.isPlainObject(e))return n.each(e,(function(e,t){o(e,t)}))
function i(){return t.apply(this,Array.prototype.slice.call(arguments,1))}i.guid=t.guid=t.guid||n.guid++
s.bind(e,i)}
n.unsubscribe=a=function(){s.unbind.apply(s,arguments)}
n.publish=r=function(){s.trigger.apply(s,arguments)}
e.exports={subscribe:o,unsubscribe:a,publish:r}},"Yn//":function(e,t){if("undefined"!=typeof jQuery)mejs.$=jQuery
else if("undefined"!=typeof Zepto){mejs.$=Zepto
Zepto.fn.outerWidth=function(e){var t=$(this).width()
if(e){t+=parseInt($(this).css("margin-right"),10)
t+=parseInt($(this).css("margin-left"),10)}return t}}else"undefined"!=typeof ender&&(mejs.$=ender)},ZDlt:function(e,t){(function(e){e.extend(mejs.MepDefaults,{enableProgressTooltip:true,progressHelpText:""})
e.extend(MediaElementPlayer.prototype,{buildprogress:function(t,i,n,o){var a=this,r=false,s=0,l=false,d=t.options.autoRewind,u=(a.options.progressHelpText?a.options.progressHelpText:mejs.i18n.t("mejs.time-help-text"),t.options.enableProgressTooltip?'<span class="mejs-time-float"><span class="mejs-time-float-current">00:00</span><span class="mejs-time-float-corner"></span></span>':"")
e('<div class="mejs-time-rail"><span  class="mejs-time-total mejs-time-slider"><span class="mejs-time-buffering"></span><span class="mejs-time-loaded"></span><span class="mejs-time-current"></span><span class="mejs-time-handle"></span>'+u+"</span></div>").appendTo(i)
i.find(".mejs-time-buffering").hide()
a.total=i.find(".mejs-time-total")
a.loaded=i.find(".mejs-time-loaded")
a.current=i.find(".mejs-time-current")
a.handle=i.find(".mejs-time-handle")
a.timefloat=i.find(".mejs-time-float")
a.timefloatcurrent=i.find(".mejs-time-float-current")
a.slider=i.find(".mejs-time-slider")
var c=function(e){var i,n=a.total.offset(),s=a.total.width(),l=0,d=0,u=0
i=e.originalEvent&&e.originalEvent.changedTouches?e.originalEvent.changedTouches[0].pageX:e.changedTouches?e.changedTouches[0].pageX:e.pageX
if(o.duration){i<n.left?i=n.left:i>s+n.left&&(i=s+n.left)
u=i-n.left
l=u/s
d=l*o.duration
r&&d!==o.currentTime&&o.setCurrentTime(d)
if(!mejs.MediaFeatures.hasTouch){a.timefloat.css("left",u)
a.timefloatcurrent.html(mejs.Utility.secondsToTimeCode(d,t.options))
a.timefloat.show()}}},m=function(e){a.slider.attr(f(o.duration,o.currentTime))},p=function(){var e=new Date
e-s>=1e3&&o.play()},f=function(e,i){var n=mejs.i18n.t("mejs.time-slider"),o=mejs.Utility.secondsToTimeCode(i,t.options)
return{"aria-label":n,"aria-valuemin":0,"aria-valuemax":e,"aria-valuenow":i,"aria-valuetext":o,role:"slider",tabindex:0}}
a.slider.attr(f(0,0))
a.slider.bind("focus",(function(e){t.options.autoRewind=false}))
a.slider.bind("blur",(function(e){t.options.autoRewind=d}))
a.slider.bind("keydown",(function(e){new Date-s>=1e3&&(l=o.paused)
var i=e.keyCode,n=o.duration,a=o.currentTime,r=t.options.defaultSeekForwardInterval(o),d=t.options.defaultSeekBackwardInterval(o)
jumpForward=t.options.defaultJumpForwardInterval(o),jumpBackward=t.options.defaultJumpBackwardInterval(o)
switch(i){case 37:case 40:a-=d
break
case 39:case 38:a+=r
break
case 33:a+=jumpForward
break
case 34:a-=jumpBackward
break
case 36:a=0
break
case 35:a=n
break
case 32:case 13:o.paused?o.play():o.pause()
return
default:return}a=a<0?0:a>=n?n:Math.floor(a)
s=new Date
l||o.pause()
a<o.duration&&!l&&setTimeout(p,1100)
o.setCurrentTime(a)
e.preventDefault()
e.stopPropagation()
return false}))
a.total.bind("mousedown touchstart",(function(e){if(1===e.which||0===e.which){r=true
c(e)
a.globalBind("mousemove.dur touchmove.dur",(function(e){c(e)}))
a.globalBind("mouseup.dur touchend.dur",(function(e){r=false
"undefined"!==typeof a.timefloat&&a.timefloat.hide()
a.globalUnbind(".dur")}))}})).bind("mouseenter",(function(e){true
a.globalBind("mousemove.dur",(function(e){c(e)}))
"undefined"===typeof a.timefloat||mejs.MediaFeatures.hasTouch||a.timefloat.show()})).bind("mouseleave",(function(e){false
if(!r){a.globalUnbind(".dur")
"undefined"!==typeof a.timefloat&&a.timefloat.hide()}}))
o.addEventListener("progress",(function(e){t.setProgressRail(e)
t.setCurrentRail(e)}),false)
o.addEventListener("timeupdate",(function(e){t.setProgressRail(e)
t.setCurrentRail(e)
m(e)}),false)
a.container.on("controlsresize",(function(e){t.setProgressRail(e)
t.setCurrentRail(e)}))},setProgressRail:function(e){var t=this,i=void 0!==e?e.target:t.media,n=null
var o=i&&i.buffered
o&&o.length>0&&o.end&&i.duration?n=o.end(o.length-1)/i.duration:i&&void 0!==i.bytesTotal&&i.bytesTotal>0&&void 0!==i.bufferedBytes?n=i.bufferedBytes/i.bytesTotal:e&&e.lengthComputable&&0!==e.total&&(n=e.loaded/e.total)
if(null!==n){n=Math.min(1,Math.max(0,n))
t.loaded&&t.total&&t.loaded.width(t.total.width()*n)}},setCurrentRail:function(){var e=this
if(void 0!==e.media.currentTime&&e.media.duration&&e.total&&e.handle){var t=Math.round(e.total.width()*e.media.currentTime/e.media.duration),i=t-Math.round(e.handle.outerWidth(true)/2)
e.current.width(t)
e.handle.css("left",i)}}})})(mejs.$)},ZgOa:function(e,t,i){var n=i("+XDm")
"string"===typeof n&&(n=[[e.i,n,""]])
var o
var a={hmr:true}
a.transform=o
a.insertInto=void 0
i("aET+")(n,a)
n.locals&&(e.exports=n.locals)
false},"aET+":function(e,t,i){var n={}
var o=function(e){var t
return function(){"undefined"===typeof t&&(t=e.apply(this,arguments))
return t}}
var a=o((function(){return window&&document&&document.all&&!window.atob}))
var r=function(e,t){if(t)return t.querySelector(e)
return document.querySelector(e)}
var s=(l={},function(e,t){if("function"===typeof e)return e()
if("undefined"===typeof l[e]){var i=r.call(this,e,t)
if(window.HTMLIFrameElement&&i instanceof window.HTMLIFrameElement)try{i=i.contentDocument.head}catch(e){i=null}l[e]=i}return l[e]})
var l
var d=null
var u=0
var c=[]
var m=i("9tPo")
e.exports=function(e,t){if("undefined"!==typeof DEBUG&&DEBUG&&"object"!==typeof document)throw new Error("The style-loader cannot be used in a non-browser environment")
t=t||{}
t.attrs="object"===typeof t.attrs?t.attrs:{}
t.singleton||"boolean"===typeof t.singleton||(t.singleton=a())
t.insertInto||(t.insertInto="head")
t.insertAt||(t.insertAt="bottom")
var i=f(e,t)
p(i,t)
return function(e){var o=[]
for(var a=0;a<i.length;a++){var r=i[a]
var s=n[r.id]
s.refs--
o.push(s)}if(e){var l=f(e,t)
p(l,t)}for(a=0;a<o.length;a++){s=o[a]
if(0===s.refs){for(var d=0;d<s.parts.length;d++)s.parts[d]()
delete n[s.id]}}}}
function p(e,t){for(var i=0;i<e.length;i++){var o=e[i]
var a=n[o.id]
if(a){a.refs++
for(var r=0;r<a.parts.length;r++)a.parts[r](o.parts[r])
for(;r<o.parts.length;r++)a.parts.push(k(o.parts[r],t))}else{var s=[]
for(r=0;r<o.parts.length;r++)s.push(k(o.parts[r],t))
n[o.id]={id:o.id,refs:1,parts:s}}}}function f(e,t){var i=[]
var n={}
for(var o=0;o<e.length;o++){var a=e[o]
var r=t.base?a[0]+t.base:a[0]
var s=a[1]
var l=a[2]
var d=a[3]
var u={css:s,media:l,sourceMap:d}
n[r]?n[r].parts.push(u):i.push(n[r]={id:r,parts:[u]})}return i}function h(e,t){var i=s(e.insertInto)
if(!i)throw new Error("Couldn't find a style target. This probably means that the value for the 'insertInto' parameter is invalid.")
var n=c[c.length-1]
if("top"===e.insertAt){n?n.nextSibling?i.insertBefore(t,n.nextSibling):i.appendChild(t):i.insertBefore(t,i.firstChild)
c.push(t)}else if("bottom"===e.insertAt)i.appendChild(t)
else{if("object"!==typeof e.insertAt||!e.insertAt.before)throw new Error("[Style Loader]\n\n Invalid value for parameter 'insertAt' ('options.insertAt') found.\n Must be 'top', 'bottom', or Object.\n (https://github.com/webpack-contrib/style-loader#insertat)\n")
var o=s(e.insertAt.before,i)
i.insertBefore(t,o)}}function g(e){if(null===e.parentNode)return false
e.parentNode.removeChild(e)
var t=c.indexOf(e)
t>=0&&c.splice(t,1)}function b(e){var t=document.createElement("style")
void 0===e.attrs.type&&(e.attrs.type="text/css")
if(void 0===e.attrs.nonce){var i=j()
i&&(e.attrs.nonce=i)}y(t,e.attrs)
h(e,t)
return t}function v(e){var t=document.createElement("link")
void 0===e.attrs.type&&(e.attrs.type="text/css")
e.attrs.rel="stylesheet"
y(t,e.attrs)
h(e,t)
return t}function y(e,t){Object.keys(t).forEach((function(i){e.setAttribute(i,t[i])}))}function j(){false
return i.nc}function k(e,t){var i,n,o,a
if(t.transform&&e.css){a="function"===typeof t.transform?t.transform(e.css):t.transform.default(e.css)
if(!a)return function(){}
e.css=a}if(t.singleton){var r=u++
i=d||(d=b(t))
n=T.bind(null,i,r,false)
o=T.bind(null,i,r,true)}else if(e.sourceMap&&"function"===typeof URL&&"function"===typeof URL.createObjectURL&&"function"===typeof URL.revokeObjectURL&&"function"===typeof Blob&&"function"===typeof btoa){i=v(t)
n=S.bind(null,i,t)
o=function(){g(i)
i.href&&URL.revokeObjectURL(i.href)}}else{i=b(t)
n=_.bind(null,i)
o=function(){g(i)}}n(e)
return function(t){if(t){if(t.css===e.css&&t.media===e.media&&t.sourceMap===e.sourceMap)return
n(e=t)}else o()}}var w=(x=[],function(e,t){x[e]=t
return x.filter(Boolean).join("\n")})
var x
function T(e,t,i,n){var o=i?"":n.css
if(e.styleSheet)e.styleSheet.cssText=w(t,o)
else{var a=document.createTextNode(o)
var r=e.childNodes
r[t]&&e.removeChild(r[t])
r.length?e.insertBefore(a,r[t]):e.appendChild(a)}}function _(e,t){var i=t.css
var n=t.media
n&&e.setAttribute("media",n)
if(e.styleSheet)e.styleSheet.cssText=i
else{while(e.firstChild)e.removeChild(e.firstChild)
e.appendChild(document.createTextNode(i))}}function S(e,t,i){var n=i.css
var o=i.sourceMap
var a=void 0===t.convertToAbsoluteUrls&&o;(t.convertToAbsoluteUrls||a)&&(n=m(n))
o&&(n+="\n/*# sourceMappingURL=data:application/json;base64,"+btoa(unescape(encodeURIComponent(JSON.stringify(o))))+" */")
var r=new Blob([n],{type:"text/css"})
var s=e.href
e.href=URL.createObjectURL(r)
s&&URL.revokeObjectURL(s)}},aq8L:function(e,t,i){"use strict"
var n=i("HGxv")
var o=n["default"].scoped("instructure_misc_plugins")
var a=i("ouhR")
var r=i.n(a)
var s=i("gI0r")
var l=i("3PZ/")
i("dhbk")
i("ESjL")
i("65NJ")
i("w2hD")
r.a.fn.setOptions=function(e,t){let i=e?"<option value=''>"+Object(s["a"])(e)+"</option>":""
null==t&&(t=[])
t.forEach(e=>{const t=Object(s["a"])(e)
i+='<option value="'+t+'">'+t+"</option>"})
return this.html(r.a.raw(i))}
r.a.fn.ifExists=function(e){this.length&&e.call(this,this)
return this}
r.a.fn.scrollbarWidth=function(){const e=r()('<div style="width:50px;height:50px;overflow:hidden;position:absolute;top:-200px;left:-200px;"><div style="height:100px;"></div>').appendTo(this),t=e.find("div")
const i=t.innerWidth()
e.css("overflow-y","scroll")
const n=t.innerWidth()
e.remove()
return i-n}
r.a.fn.dim=function(e){return this.animate({opacity:.4},e)}
r.a.fn.undim=function(e){return this.animate({opacity:1},e)}
r.a.fn.confirmDelete=function(e){e=r.a.extend({},r.a.fn.confirmDelete.defaults,e)
const t=this
let i=null
let n=true
e.noMessage=e.noMessage||e.no_message
const a=function(){if(!n){e.cancelled&&r.a.isFunction(e.cancelled)&&e.cancelled.call(t)
return}e.confirmed||(e.confirmed=function(){t.dim()})
e.confirmed.call(t)
if(e.url){e.success||(e.success=function(e){t.fadeOut("slow",()=>{t.remove()})})
const n=e.prepareData?e.prepareData.call(t,i):{}
n.authenticity_token=Object(l["a"])()
r.a.ajaxJSON(e.url,"DELETE",n,i=>{e.success.call(t,i)},(i,n,o,a)=>{e.error&&r.a.isFunction(e.error)?e.error.call(t,i,n,o,a):r.a.ajaxJSON.unhandledXHRs.push(n)})}else{e.success||(e.success=function(){t.fadeOut("slow",()=>{t.remove()})})
e.success.call(t)}}
if(e.message&&!e.noMessage&&!r.a.skipConfirmations){if(e.dialog){n=false
const t="object"===typeof e.dialog?e.dialog:{}
const s=e.url.includes("assignments")?"btn-danger":"btn-primary"
i=r()(e.message).dialog(r.a.extend({},{modal:true,close:a,buttons:[{text:o.t("#buttons.cancel","Cancel"),click(){r()(this).dialog("close")}},{text:o.t("#buttons.delete","Delete"),class:s,click(){n=true
r()(this).dialog("close")}}]},t))
return}n=confirm(e.message)}a()}
r.a.fn.confirmDelete.defaults={get message(){return o.t("confirms.default_delete_thing","Are you sure you want to delete this?")}}
r.a.fn.fragmentChange=function(e){if(e&&true!==e){const i=(window.location.search||"").replace(/^\?/,"").split("&")
let n=null
for(var t=0;t<i.length;t++){const e=i[t]
e&&0===e.indexOf("hash=")&&(n="#"+e.substring(5))}this.bind("document_fragment_change",e)
const o=this
let a=false
for(t=0;t<r.a._checkFragments.fragmentList.length;t++){const e=r.a._checkFragments.fragmentList[t]
e.doc[0]==o[0]&&(a=true)}a||r.a._checkFragments.fragmentList.push({doc:o,fragment:""})
r()(window).bind("hashchange",r.a._checkFragments)
setTimeout(()=>{n&&n.length>0?o.triggerHandler("document_fragment_change",n):o&&o[0]&&o[0].location&&o[0].location.hash.length>0&&o.triggerHandler("document_fragment_change",o[0].location.hash)},500)}else this.triggerHandler("document_fragment_change",this[0].location.hash)
return this}
r.a._checkFragments=function(){const e=r.a._checkFragments.fragmentList
for(let t=0;t<e.length;t++){const i=e[t]
const n=i.doc
if(n[0].location.hash!=i.fragment){n.triggerHandler("document_fragment_change",n[0].location.hash)
i.fragment=n[0].location.hash
r.a._checkFragments.fragmentList[t]=i}}}
r.a._checkFragments.fragmentList=[]
r.a.fn.clickLink=function(){const e=this.eq(0)
e.hasClass("disabled_link")||e.click()}
r.a.fn.showIf=function(e){if(r.a.isFunction(e))return this.each((function(t){r()(this).showIf(e.call(this))}))
e?this.show():this.hide()
return this}
r.a.fn.disableIf=function(e){r.a.isFunction(e)&&(e=e.call(this))
this.prop("disabled",!!e)
return this}
r.a.fn.indicate=function(e){e=e||{}
let t
if("remove"==e){t=this.data("indicator")
t&&t.remove()
return}r()(".indicator_box").remove()
let i=this.offset()
e&&e.offset&&(i=e.offset)
const n=this.width()
const o=this.height()
const a=(e.container||this).zIndex()
t=r()(document.createElement("div"))
t.css({width:n+6,height:o+6,top:i.top-3,left:i.left-3,zIndex:a+1,position:"absolute",display:"block","-moz-border-radius":5,opacity:.8,border:"2px solid #870",backgroundColor:"#fd0"})
t.addClass("indicator_box")
t.mouseover((function(){r()(this).stop().fadeOut("fast",(function(){r()(this).remove()}))}))
this.data("indicator")&&this.indicate("remove")
this.data("indicator",t)
r()("body").append(t)
e&&e.singleFlash?t.hide().fadeIn().animate({opacity:.8},500).fadeOut("slow",(function(){r()(this).remove()})):t.hide().fadeIn().animate({opacity:.8},500).fadeOut("slow").fadeIn("slow").animate({opacity:.8},2500).fadeOut("slow",(function(){r()(this).remove()}))
e&&e.scroll&&r()("html,body").scrollToVisible(t)}
r.a.fn.hasScrollbar=function(){return this.length&&this[0].clientHeight<this[0].scrollHeight}
r.a.fn.log=function(e){console.log("%s: %o",e,this)
return this}
r.a.fn.fillWindowWithMe=function(e){const t=r.a.extend({minHeight:400},e),i=r()(this),n=r()("#wrapper"),o=r()("#main"),a=r()("#not_right_side"),s=r()(window),l=r()(this).add(t.alsoResize)
function d(){l.height(0)
const e=s.height()-(n.offset().top+n.outerHeight())+(o.height()-a.height()),d=Math.max(400,e)
l.height(d)
r.a.isFunction(t.onResize)&&t.onResize.call(i,d)}d()
s.unbind("resize.fillWindowWithMe").bind("resize.fillWindowWithMe",d)
return this}
r.a.fn.autoGrowInput=function(e){e=r.a.extend({maxWidth:1e3,minWidth:0,comfortZone:70},e)
this.filter("input:text").each((function(){let t=e.minWidth||r()(this).width(),i="",n=r()(this),o=r()("<tester/>").css({position:"absolute",top:-9999,left:-9999,width:"auto",fontSize:n.css("fontSize"),fontFamily:n.css("fontFamily"),fontWeight:n.css("fontWeight"),letterSpacing:n.css("letterSpacing"),whiteSpace:"nowrap"}),a=function(){setTimeout(()=>{if(i===(i=n.val()))return
o.text(i)
const a=o.width(),r=a+e.comfortZone>=t?a+e.comfortZone:t,s=n.width(),l=r<s&&r>=t||r>t&&r<e.maxWidth
l&&n.width(r)})}
o.insertAfter(n)
r()(this).bind("keyup keydown blur update change",a)}))
return this}
r.a},elqR:function(e,t,i){e.exports=i.p+"15e1ac8cbacc2efdf1ac2677de48a253.png"},gH2L:function(e,t){(function(e){e.extend(mejs.MepDefaults,{stopText:"Stop"})
e.extend(MediaElementPlayer.prototype,{buildstop:function(t,i,n,o){var a=this
e('<div class="mejs-button mejs-stop-button mejs-stop"><button type="button" aria-controls="'+a.id+'" title="'+a.options.stopText+'" aria-label="'+a.options.stopText+'"></button></div>').appendTo(i).click((function(){o.paused||o.pause()
if(o.currentTime>0){o.setCurrentTime(0)
o.pause()
i.find(".mejs-time-current").width("0px")
i.find(".mejs-time-handle").css("left","0px")
i.find(".mejs-time-float-current").html(mejs.Utility.secondsToTimeCode(0,t.options))
i.find(".mejs-currenttime").html(mejs.Utility.secondsToTimeCode(0,t.options))
n.find(".mejs-poster").show()}}))}})})(mejs.$)},gopi:function(e,t,i){e.exports=i.p+"76b326f4d44222126fee21076595bef5.gif"},"iG+V":function(e,t){(function(e){e.extend(mejs.MepDefaults,{googleAnalyticsTitle:"",googleAnalyticsCategory:"Videos",googleAnalyticsEventPlay:"Play",googleAnalyticsEventPause:"Pause",googleAnalyticsEventEnded:"Ended",googleAnalyticsEventTime:"Time"})
e.extend(MediaElementPlayer.prototype,{buildgoogleanalytics:function(e,t,i,n){n.addEventListener("play",(function(){"undefined"!=typeof _gaq&&_gaq.push(["_trackEvent",e.options.googleAnalyticsCategory,e.options.googleAnalyticsEventPlay,""===e.options.googleAnalyticsTitle?e.media.currentSrc:e.options.googleAnalyticsTitle])}),false)
n.addEventListener("pause",(function(){"undefined"!=typeof _gaq&&_gaq.push(["_trackEvent",e.options.googleAnalyticsCategory,e.options.googleAnalyticsEventPause,""===e.options.googleAnalyticsTitle?e.media.currentSrc:e.options.googleAnalyticsTitle])}),false)
n.addEventListener("ended",(function(){"undefined"!=typeof _gaq&&_gaq.push(["_trackEvent",e.options.googleAnalyticsCategory,e.options.googleAnalyticsEventEnded,""===e.options.googleAnalyticsTitle?e.media.currentSrc:e.options.googleAnalyticsTitle])}),false)}})})(mejs.$)},ldnB:function(e,t,i){e.exports=i.p+"716436fb3df0d29e6b37dd62d952676a.png"},mVe5:function(e,t){},md8m:function(e,t,i){e.exports=i.p+"703c659e4bf563a05c6338a1727e006c.png"},okCx:function(e,t){(function(e){e.extend(mejs.MepDefaults,{sourcechooserText:""})
e.extend(MediaElementPlayer.prototype,{sources:[],buildsourcechooser:function(t,i,n,o){var a,r=this,s=r.options.sourcechooserText?r.options.sourcechooserText:mejs.i18n.t("mejs.source-chooser")
t.sourcechooserButton=e('<div class="mejs-button mejs-sourcechooser-button"><button type="button" role="button" aria-haspopup="true" aria-controls="'+r.id+'" title="'+s+'" aria-label="'+s+'" aria-live="assertive"></button><div class="mejs-sourcechooser-selector mejs-offscreen" role="menu" aria-expanded="false" aria-hidden="true"><ul></ul></div></div>').appendTo(i).hover((function(){clearTimeout(a)
t.showSourcechooserSelector()}),(function(){a=setTimeout((function(){t.hideSourcechooserSelector()}),r.options.menuTimeoutMouseLeave)})).on("keydown",(function(i){var n=i.keyCode
switch(n){case 32:mejs.MediaFeatures.isFirefox||t.showSourcechooserSelector()
e(this).find(".mejs-sourcechooser-selector").find("input[type=radio]:checked").first().focus()
break
case 13:t.showSourcechooserSelector()
e(this).find(".mejs-sourcechooser-selector").find("input[type=radio]:checked").first().focus()
break
case 27:t.hideSourcechooserSelector()
e(this).find("button").focus()
break
default:return true}})).on("focusout",mejs.Utility.debounce((function(i){setTimeout((function(){var i=e(document.activeElement).closest(".mejs-sourcechooser-selector")
i.length||t.hideSourcechooserSelector()}),0)}),100)).delegate("input[type=radio]","click",(function(){e(this).attr("aria-selected",true).attr("checked","checked")
e(this).closest(".mejs-sourcechooser-selector").find("input[type=radio]").not(this).attr("aria-selected","false").removeAttr("checked")
var t=this.value
if(o.currentSrc!=t){var i=o.currentTime
var n=o.paused
o.pause()
o.setSrc(t)
o.addEventListener("loadedmetadata",(function(e){o.currentTime=i}),true)
var a=function(e){n||o.play()
o.removeEventListener("canplay",a,true)}
o.addEventListener("canplay",a,true)
o.load()}r.setSourcechooserAriaLabel(o)})).delegate("button","click",(function(i){if(e(this).siblings(".mejs-sourcechooser-selector").hasClass("mejs-offscreen")){t.showSourcechooserSelector()
e(this).siblings(".mejs-sourcechooser-selector").find("input[type=radio]:checked").first().focus()}else t.hideSourcechooserSelector()}))
for(var l in this.node.children){var d=this.node.children[l]
if("SOURCE"===d.nodeName&&("probably"==o.canPlayType(d.type)||"maybe"==o.canPlayType(d.type))){r.sources.push(d)
t.addSourceButton(d.src,d.title,d.type,o.src==d.src)}}r.setSourcechooserAriaLabel(o)},setSourcechooserAriaLabel:function(e){var t=this.options.sourcechooserText?this.options.sourcechooserText:mejs.i18n.t("mejs.source-chooser")
var i=this.currentSource(e)
i&&(t+=": "+i)
this.sourcechooserButton.find("button").attr("aria-label",t).attr("title",t)},addSourceButton:function(t,i,n,o){var a=this
""!==i&&void 0!=i||(i=t)
n=n.split("/")[1]
a.sourcechooserButton.find("ul").append(e('<li><input type="radio" name="'+a.id+'_sourcechooser" id="'+a.id+"_sourcechooser_"+i+n+'" role="menuitemradio" value="'+t+'" '+(o?'checked="checked"':"")+'aria-selected="'+o+'" aria-label="'+i+'" tabindex="-1" /><label for="'+a.id+"_sourcechooser_"+i+n+'" aria-hidden="true">'+i+" ("+n+")</label></li>"))
a.adjustSourcechooserBox()},currentSource:function(e){var t=this.sources.filter((function(t){return t.src==e.src}))[0]
if(t)return t.title||""
return""},adjustSourcechooserBox:function(){var e=this
e.sourcechooserButton.find(".mejs-sourcechooser-selector").height(e.sourcechooserButton.find(".mejs-sourcechooser-selector ul").outerHeight(true))},hideSourcechooserSelector:function(){this.sourcechooserButton.find(".mejs-sourcechooser-selector").addClass("mejs-offscreen").attr("aria-expanded","false").attr("aria-hidden","true").find("input[type=radio]").attr("tabindex","-1")},showSourcechooserSelector:function(){this.sourcechooserButton.find(".mejs-sourcechooser-selector").removeClass("mejs-offscreen").attr("aria-expanded","true").attr("aria-hidden","false").find("input[type=radio]").attr("tabindex","0")}})})(mejs.$)},stQK:function(e,t,i){"use strict"
var n=i("HGxv")
var o=n["default"].scoped("closedCaptionLanguages")
const a={get af(){return o.t("Afrikaans")},get sq(){return o.t("Albanian")},get ar(){return o.t("Arabic")},get be(){return o.t("Belarusian")},get bg(){return o.t("Bulgarian")},get ca(){return o.t("Catalan")},get zh(){return o.t("Chinese")},get hr(){return o.t("Croatian")},get cs(){return o.t("Czech")},get da(){return o.t("Danish")},get nl(){return o.t("Dutch")},get en(){return o.t("English")},get et(){return o.t("Estonian")},get fl(){return o.t("Filipino")},get fi(){return o.t("Finnish")},get fr(){return o.t("French")},get gl(){return o.t("Galician")},get de(){return o.t("German")},get el(){return o.t("Greek")},get ht(){return o.t("Haitian Creole")},get hi(){return o.t("Hindi")},get hu(){return o.t("Hungarian")},get is(){return o.t("Icelandic")},get id(){return o.t("Indonesian")},get ga(){return o.t("Irish")},get it(){return o.t("Italian")},get ja(){return o.t("Japanese")},get ko(){return o.t("Korean")},get lv(){return o.t("Latvian")},get lt(){return o.t("Lithuanian")},get mk(){return o.t("Macedonian")},get ms(){return o.t("Malay")},get mt(){return o.t("Maltese")},get no(){return o.t("Norwegian")},get fa(){return o.t("Persian")},get pl(){return o.t("Polish")},get pt(){return o.t("Portuguese")},get ro(){return o.t("Romanian")},get ru(){return o.t("Russian")},get sr(){return o.t("Serbian")},get sk(){return o.t("Slovak")},get sl(){return o.t("Slovenian")},get es(){return o.t("Spanish")},get sw(){return o.t("Swahili")},get sv(){return o.t("Swedish")},get tl(){return o.t("Tagalog")},get th(){return o.t("Thai")},get tr(){return o.t("Turkish")},get uk(){return o.t("Ukrainian")},get vi(){return o.t("Vietnamese")},get cy(){return o.t("Welsh")},get yi(){return o.t("Yiddish")},get"en-CA"(){return o.t("English (Canada)")},get"en-AU"(){return o.t("English (Australia)")},get"en-GB"(){return o.t("English (United Kingdom)")},get"fr-CA"(){return o.t("French (Canada)")},get he(){return o.t("Hebrew")},get hy(){return o.t("Armenian")},get mi(){return o.t("Māori (New Zealand)")},get nb(){return o.t("Norwegian Bokmål")},get nn(){return o.t("Norwegian Nynorsk")},get"zh-Hans"(){return o.t("Chinese Simplified")},get"zh-Hant"(){return o.t("Chinese Traditional")}}
t["a"]=a},tSde:function(e,t,i){e.exports=i.p+"cd6dc830eb45b3a5a96bbc936ff54846.png"},uCtj:function(e,t,i){e.exports=i.p+"746c3af7a145a09239a36e5ef61cfea0.svg"},ucra:function(e,t){function i(e,t,i){if(!isNaN(t.duration)&&t.duration>0){if(e.isVideo){e.showControls()
e.startControlsTimer()}var n=Math.min(Math.max(0,i),t.duration)
t.setCurrentTime(n)}}(function(e){mejs.MepDefaults={poster:"",hidePosterOnPlay:true,showPosterWhenEnded:false,defaultVideoWidth:480,defaultVideoHeight:270,videoWidth:-1,videoHeight:-1,defaultAudioWidth:400,defaultAudioHeight:30,defaultSeekBackwardInterval:function(e){return.05*e.duration},defaultSeekForwardInterval:function(e){return.05*e.duration},defaultJumpBackwardInterval:function(e){return.05*e.duration},defaultJumpForwardInterval:function(e){return.05*e.duration},setDimensions:true,audioWidth:-1,audioHeight:-1,startVolume:.8,loop:false,autoRewind:true,enableAutosize:true,timeFormat:"",alwaysShowHours:false,showTimecodeFrameCount:false,framesPerSecond:25,autosizeProgress:true,alwaysShowControls:false,hideVideoControlsOnLoad:false,clickToPlayPause:true,controlsTimeoutDefault:1500,controlsTimeoutMouseEnter:2500,controlsTimeoutMouseLeave:1e3,menuTimeoutMouseLeave:500,iPadUseNativeControls:false,iPhoneUseNativeControls:false,AndroidUseNativeControls:false,features:["playpause","current","progress","duration","tracks","volume","fullscreen"],isVideo:true,stretching:"auto",enableKeyboard:true,pauseOtherPlayers:true,keyActions:[{keys:[32,179],action:function(e,t,i,n){mejs.MediaFeatures.isFirefox||(t.paused||t.ended?t.play():t.pause())}},{keys:[38],action:function(e,t,i,n){e.container.find(".mejs-volume-slider").css("display","block")
if(e.isVideo){e.showControls()
e.startControlsTimer()}var o=Math.min(t.volume+.1,1)
t.setVolume(o)}},{keys:[40],action:function(e,t,i,n){e.container.find(".mejs-volume-slider").css("display","block")
if(e.isVideo){e.showControls()
e.startControlsTimer()}var o=Math.max(t.volume-.1,0)
t.setVolume(o)}},{keys:[37,227],action:function(e,t,i,n){if(!isNaN(t.duration)&&t.duration>0){if(e.isVideo){e.showControls()
e.startControlsTimer()}var o=Math.max(t.currentTime-e.options.defaultSeekBackwardInterval(t),0)
t.setCurrentTime(o)}}},{keys:[39,228],action:function(e,t,i,n){if(!isNaN(t.duration)&&t.duration>0){if(e.isVideo){e.showControls()
e.startControlsTimer()}var o=Math.min(t.currentTime+e.options.defaultSeekForwardInterval(t),t.duration)
t.setCurrentTime(o)}}},{keys:[33],action:function(e,t){var n=t.currentTime+e.options.defaultJumpBackwardInterval(t)
i(e,t,n)}},{keys:[34],action:function(e,t){var n=t.currentTime+e.options.defaultJumpForwardInterval(t)
i(e,t,n)}},{keys:[70],action:function(e,t,i,n){"undefined"!=typeof e.enterFullScreen&&(e.isFullScreen?e.exitFullScreen():e.enterFullScreen())}},{keys:[77],action:function(e,t,i,n){e.container.find(".mejs-volume-slider").css("display","block")
if(e.isVideo){e.showControls()
e.startControlsTimer()}e.media.muted?e.setMuted(false):e.setMuted(true)}}]}
mejs.mepIndex=0
mejs.players={}
mejs.MediaElementPlayer=function(t,i){if(!(this instanceof mejs.MediaElementPlayer))return new mejs.MediaElementPlayer(t,i)
var n=this
n.$media=n.$node=e(t)
n.node=n.media=n.$media[0]
if(!n.node)return
if("undefined"!=typeof n.node.player)return n.node.player
"undefined"==typeof i&&(i=n.$node.data("mejsoptions"))
n.options=e.extend({},mejs.MepDefaults,i)
if(!n.options.timeFormat){n.options.timeFormat="mm:ss"
n.options.alwaysShowHours&&(n.options.timeFormat="hh:mm:ss")
n.options.showTimecodeFrameCount&&(n.options.timeFormat+=":ff")}mejs.Utility.calculateTimeFormat(0,n.options,n.options.framesPerSecond||25)
n.id="mep_"+mejs.mepIndex++
mejs.players[n.id]=n
n.init()
return n}
mejs.MediaElementPlayer.prototype={hasFocus:false,controlsAreVisible:true,init:function(){var t=this,i=mejs.MediaFeatures,n=e.extend(true,{},t.options,{success:function(e,i){t.meReady(e,i)},error:function(e){t.handleError(e)}}),o=t.media.tagName.toLowerCase()
t.isDynamic="audio"!==o&&"video"!==o
t.isDynamic?t.isVideo=t.options.isVideo:t.isVideo="audio"!==o&&t.options.isVideo
if(i.isiPad&&t.options.iPadUseNativeControls||i.isiPhone&&t.options.iPhoneUseNativeControls){t.$media.attr("controls","controls")
i.isiPad&&null!==t.media.getAttribute("autoplay")&&t.play()}else if(i.isAndroid&&t.options.AndroidUseNativeControls);else if(t.isVideo||!t.isVideo&&t.options.features.length){t.$media.removeAttr("controls")
var a=t.isVideo?mejs.i18n.t("mejs.video-player"):mejs.i18n.t("mejs.audio-player")
t.options.titleText&&(a=t.options.titleText)
e('<span class="mejs-offscreen">').text(a).insertBefore(t.$media)
t.container=e('<div id="'+t.id+'" class="mejs-container '+(mejs.MediaFeatures.svgAsImg?"svg":"no-svg")+'" tabindex="0" role="application"><div class="mejs-inner"><div class="mejs-mediaelement"></div><div class="mejs-layers"></div><div class="mejs-controls"></div><div class="mejs-clear"></div></div></div>').attr("aria-label",a).addClass(t.$media[0].className).insertBefore(t.$media).focus((function(e){if(!t.controlsAreVisible&&!t.hasFocus&&t.controlsEnabled){t.showControls(true)
if(!t.hasMsNativeFullScreen){var i=".mejs-playpause-button > button"
mejs.Utility.isNodeAfter(e.relatedTarget,t.container[0])&&(i=".mejs-controls .mejs-button:last-child > button")
var n=t.container.find(i)
n.focus()}}}))
t.options.features.length||t.container.css("background","transparent").find(".mejs-controls").hide()
if(t.isVideo&&"fill"===t.options.stretching&&!t.container.parent("mejs-fill-container").length){t.outerContainer=t.$media.parent()
t.container.wrap('<div class="mejs-fill-container"/>')}t.container.addClass((i.isAndroid?"mejs-android ":"")+(i.isiOS?"mejs-ios ":"")+(i.isiPad?"mejs-ipad ":"")+(i.isiPhone?"mejs-iphone ":"")+(t.isVideo?"mejs-video ":"mejs-audio "))
t.container.find(".mejs-mediaelement").append(t.$media)
t.node.player=t
t.controls=t.container.find(".mejs-controls")
t.layers=t.container.find(".mejs-layers")
var r=t.isVideo?"video":"audio",s=r.substring(0,1).toUpperCase()+r.substring(1)
t.options[r+"Width"]>0||t.options[r+"Width"].toString().indexOf("%")>-1?t.width=t.options[r+"Width"]:""!==t.media.style.width&&null!==t.media.style.width?t.width=t.media.style.width:null!==t.media.getAttribute("width")?t.width=t.$media.attr("width"):t.width=t.options["default"+s+"Width"]
t.options[r+"Height"]>0||t.options[r+"Height"].toString().indexOf("%")>-1?t.height=t.options[r+"Height"]:""!==t.media.style.height&&null!==t.media.style.height?t.height=t.media.style.height:null!==t.$media[0].getAttribute("height")?t.height=t.$media.attr("height"):t.height=t.options["default"+s+"Height"]
t.setPlayerSize(t.width,t.height)
n.pluginWidth=t.width
n.pluginHeight=t.height}else t.isVideo||t.options.features.length||t.$media.hide()
mejs.MediaElement(t.$media[0],n)
"undefined"!==typeof t.container&&t.options.features.length&&t.controlsAreVisible&&t.container.trigger("controlsshown")},showControls:function(e){var t=this
e="undefined"==typeof e||e
if(t.controlsAreVisible)return
if(e){t.controls.removeClass("mejs-offscreen").stop(true,true).fadeIn(200,(function(){t.controlsAreVisible=true
t.container.trigger("controlsshown")}))
t.container.find(".mejs-control").removeClass("mejs-offscreen").stop(true,true).fadeIn(200,(function(){t.controlsAreVisible=true}))}else{t.controls.removeClass("mejs-offscreen").css("display","block")
t.container.find(".mejs-control").removeClass("mejs-offscreen").css("display","block")
t.controlsAreVisible=true
t.container.trigger("controlsshown")}t.setControlsSize()},hideControls:function(t){var i=this
t="undefined"==typeof t||t
if(!i.controlsAreVisible||i.options.alwaysShowControls||i.keyboardAction||i.media.paused||i.media.ended)return
if(t){i.controls.stop(true,true).fadeOut(200,(function(){e(this).addClass("mejs-offscreen").css("display","block")
i.controlsAreVisible=false
i.container.trigger("controlshidden")}))
i.container.find(".mejs-control").stop(true,true).fadeOut(200,(function(){e(this).addClass("mejs-offscreen").css("display","block")}))}else{i.controls.addClass("mejs-offscreen").css("display","block")
i.container.find(".mejs-control").addClass("mejs-offscreen").css("display","block")
i.controlsAreVisible=false
i.container.trigger("controlshidden")}},controlsTimer:null,startControlsTimer:function(e){var t=this
e="undefined"!=typeof e?e:t.options.controlsTimeoutDefault
t.killControlsTimer("start")
t.controlsTimer=setTimeout((function(){t.hideControls()
t.killControlsTimer("hide")}),e)},killControlsTimer:function(e){var t=this
if(null!==t.controlsTimer){clearTimeout(t.controlsTimer)
delete t.controlsTimer
t.controlsTimer=null}},controlsEnabled:true,disableControls:function(){var e=this
e.killControlsTimer()
e.hideControls(false)
this.controlsEnabled=false},enableControls:function(){var e=this
e.showControls(false)
e.controlsEnabled=true},meReady:function(t,i){var n,o,a=this,r=mejs.MediaFeatures,s=i.getAttribute("autoplay"),l=!("undefined"==typeof s||null===s||"false"===s)
if(a.created)return
a.created=true
a.media=t
a.domNode=i
if(!(r.isAndroid&&a.options.AndroidUseNativeControls)&&!(r.isiPad&&a.options.iPadUseNativeControls)&&!(r.isiPhone&&a.options.iPhoneUseNativeControls)){if(!a.isVideo&&!a.options.features.length){l&&"native"==t.pluginType&&a.play()
a.options.success&&("string"==typeof a.options.success?window[a.options.success](a.media,a.domNode,a):a.options.success(a.media,a.domNode,a))
return}a.buildposter(a,a.controls,a.layers,a.media)
a.buildkeyboard(a,a.controls,a.layers,a.media)
a.buildoverlays(a,a.controls,a.layers,a.media)
a.findTracks()
for(n in a.options.features){o=a.options.features[n]
if(a["build"+o])try{a["build"+o](a,a.controls,a.layers,a.media)}catch(e){console.log("error building "+o)
console.log(e)}}a.container.trigger("controlsready")
a.setPlayerSize(a.width,a.height)
a.setControlsSize()
if(a.isVideo){if(mejs.MediaFeatures.hasTouch&&!a.options.alwaysShowControls)a.$media.bind("touchstart",(function(){a.controlsAreVisible?a.hideControls(false):a.controlsEnabled&&a.showControls(false)}))
else{a.clickToPlayPauseCallback=function(){if(a.options.clickToPlayPause){a.media.paused?a.play():a.pause()
var e=a.$media.closest(".mejs-container").find(".mejs-overlay-button"),t=e.attr("aria-pressed")
e.attr("aria-pressed",!t)}}
a.media.addEventListener("click",a.clickToPlayPauseCallback,false)
a.container.bind("mouseenter",(function(){if(a.controlsEnabled&&!a.options.alwaysShowControls){a.killControlsTimer("enter")
a.showControls()
a.startControlsTimer(a.options.controlsTimeoutMouseEnter)}})).bind("mousemove",(function(){if(a.controlsEnabled&&!a.options.alwaysShowControls){a.showControls()
a.startControlsTimer(a.options.controlsTimeoutMouseEnter)}})).bind("mouseleave",(function(){a.controlsEnabled&&(a.media.paused||a.options.alwaysShowControls||a.startControlsTimer(a.options.controlsTimeoutMouseLeave))}))
a.controls.on("focusin",(function(){a.controlsEnabled&&(a.options.alwaysShowControls||a.showControls())}))}a.options.hideVideoControlsOnLoad&&a.hideControls(false)
l&&!a.options.alwaysShowControls&&a.hideControls()
a.options.enableAutosize&&a.media.addEventListener("loadedmetadata",(function(e){if(a.options.videoHeight<=0&&null===a.domNode.getAttribute("height")&&!isNaN(e.target.videoHeight)){a.setPlayerSize(e.target.videoWidth,e.target.videoHeight)
a.setControlsSize()
a.media.setVideoSize(e.target.videoWidth,e.target.videoHeight)}}),false)}a.media.addEventListener("play",(function(){var e
for(e in mejs.players){var t=mejs.players[e]
t.id==a.id||!a.options.pauseOtherPlayers||t.paused||t.ended||t.pause()
t.hasFocus=false}a.hasFocus=true}),false)
a.media.addEventListener("ended",(function(t){if(a.options.autoRewind)try{a.media.setCurrentTime(0)
window.setTimeout((function(){e(a.container).find(".mejs-overlay-loading").parent().hide()}),20)}catch(e){}"youtube"===a.media.pluginType?a.media.stop():a.media.pause()
a.setProgressRail&&a.setProgressRail()
a.setCurrentRail&&a.setCurrentRail()
a.options.loop?a.play():!a.options.alwaysShowControls&&a.controlsEnabled&&a.showControls()}),false)
a.media.addEventListener("loadedmetadata",(function(){mejs.Utility.calculateTimeFormat(a.duration,a.options,a.options.framesPerSecond||25)
a.updateDuration&&a.updateDuration()
a.updateCurrent&&a.updateCurrent()
if(!a.isFullScreen){a.setPlayerSize(a.width,a.height)
a.setControlsSize()}}),false)
var d=null
a.media.addEventListener("timeupdate",(function(){if(d!==this.duration){d=this.duration
mejs.Utility.calculateTimeFormat(d,a.options,a.options.framesPerSecond||25)
a.updateDuration&&a.updateDuration()
a.updateCurrent&&a.updateCurrent()
a.setControlsSize()}}),false)
a.container.focusout((function(t){if(t.relatedTarget){var i=e(t.relatedTarget)
if(a.keyboardAction&&0===i.parents(".mejs-container").length){a.keyboardAction=false
a.isVideo&&!a.options.alwaysShowControls&&a.hideControls(true)}}}))
setTimeout((function(){a.setPlayerSize(a.width,a.height)
a.setControlsSize()}),50)
a.globalBind("resize",(function(){a.isFullScreen||mejs.MediaFeatures.hasTrueNativeFullScreen&&document.webkitIsFullScreen||a.setPlayerSize(a.width,a.height)
a.setControlsSize()}))
if("youtube"==a.media.pluginType){a.container.find(".mejs-overlay-play").hide()
a.container.find(".mejs-poster").hide()}}l&&"native"==t.pluginType&&a.play()
a.options.success&&("string"==typeof a.options.success?window[a.options.success](a.media,a.domNode,a):a.options.success(a.media,a.domNode,a))},handleError:function(e){var t=this
t.controls&&t.controls.hide()
t.options.error&&t.options.error(e)},setPlayerSize:function(e,t){var i=this
if(!i.options.setDimensions)return false
"undefined"!=typeof e&&(i.width=e)
"undefined"!=typeof t&&(i.height=t)
switch(i.options.stretching){case"fill":i.isVideo?this.setFillMode():this.setDimensions(i.width,i.height)
break
case"responsive":this.setResponsiveMode()
break
case"none":this.setDimensions(i.width,i.height)
break
default:true===this.hasFluidMode()?this.setResponsiveMode():this.setDimensions(i.width,i.height)}},hasFluidMode:function(){var e=this
return e.height.toString().indexOf("%")>0||"none"!==e.$node.css("max-width")&&"t.width"!==e.$node.css("max-width")||e.$node[0].currentStyle&&"100%"===e.$node[0].currentStyle.maxWidth},setResponsiveMode:function(){var t=this
var i=t.isVideo?t.media.videoWidth&&t.media.videoWidth>0?t.media.videoWidth:null!==t.media.getAttribute("width")?t.media.getAttribute("width"):t.options.defaultVideoWidth:t.options.defaultAudioWidth
var n=t.isVideo?t.media.videoHeight&&t.media.videoHeight>0?t.media.videoHeight:null!==t.media.getAttribute("height")?t.media.getAttribute("height"):t.options.defaultVideoHeight:t.options.defaultAudioHeight
var o=t.container.parent().closest(":visible").width(),a=t.container.parent().closest(":visible").height(),r=t.isVideo||!t.options.autosizeProgress?parseInt(o*n/i,10):n;(isNaN(r)||0!==a&&r>a&&a>n)&&(r=a)
if(t.container.parent().length>0&&"body"===t.container.parent()[0].tagName.toLowerCase()){o=e(window).width()
r=e(window).height()}if(r&&o){t.container.width(o).height(r)
t.$media.add(t.container.find(".mejs-shim")).width("100%").height("100%")
t.isVideo&&t.media.setVideoSize&&t.media.setVideoSize(o,r)
t.layers.children(".mejs-layer").width("100%").height("100%")}},setFillMode:function(){var e=this,t=e.outerContainer
t.width()||t.height(e.$media.width())
t.height()||t.height(e.$media.height())
var i=t.width(),n=t.height()
e.setDimensions("100%","100%")
e.container.find(".mejs-poster img").css("display","block")
targetElement=e.container.find("object, embed, iframe, video")
var o=e.height,a=e.width,r=i,s=o*i/a,l=a*n/o,d=n,u=!(l>i),c=u?Math.floor(r):Math.floor(l),m=u?Math.floor(s):Math.floor(d)
if(u){targetElement.height(m).width(i)
e.media.setVideoSize&&e.media.setVideoSize(i,m)}else{targetElement.height(n).width(c)
e.media.setVideoSize&&e.media.setVideoSize(c,n)}targetElement.css({"margin-left":Math.floor((i-c)/2),"margin-top":0})},setDimensions:function(e,t){var i=this
i.container.width(e).height(t)
i.layers.children(".mejs-layer").width(e).height(t)},setControlsSize:function(){var t=this,i=0,n=0,o=t.controls.find(".mejs-time-rail"),a=t.controls.find(".mejs-time-total"),r=o.siblings().filter(":visible"),s=r.last(),l=null,d=t.options&&!t.options.autosizeProgress
if(!t.container.is(":visible")||!o.length||!o.is(":visible"))return
d&&(n=parseInt(o.css("width"),10))
if(0===n||!n){r.each((function(){var t=e(this)
"absolute"!=t.css("position")&&(i+=e(this).outerWidth(true))}))
n=t.controls.width()-i-(o.outerWidth(true)-o.width())}do{d||o.width(n)
a.width(n-(a.outerWidth(true)-a.width()))
if("absolute"!=s.css("position")){l=s.length?s.position():null
n--}}while(null!==l&&l.top.toFixed(2)>0&&n>0)
t.container.trigger("controlsresize")},buildposter:function(t,i,n,o){var a=this,r=e('<div class="mejs-poster mejs-layer"></div>').appendTo(n),s=t.$media.attr("poster")
""!==t.options.poster&&(s=t.options.poster)
s?a.setPoster(s):r.hide()
o.addEventListener("play",(function(){t.options.hidePosterOnPlay&&r.hide()}),false)
t.options.showPosterWhenEnded&&t.options.autoRewind&&o.addEventListener("ended",(function(){r.show()}),false)},setPoster:function(t){var i=this,n=i.container.find(".mejs-poster"),o=n.find("img")
0===o.length&&(o=e('<img width="100%" height="100%" alt="" />').appendTo(n))
o.attr("src",t)
n.css({"background-image":"url("+t+")"})},buildoverlays:function(t,i,n,o){var a=this
if(!t.isVideo)return
var r=e('<div class="mejs-overlay mejs-layer"><div class="mejs-overlay-loading"><span></span></div></div>').hide().appendTo(n),s=e('<div class="mejs-overlay mejs-layer"><div class="mejs-overlay-error"></div></div>').hide().appendTo(n),l=e('<div class="mejs-overlay mejs-layer mejs-overlay-play"><div class="mejs-overlay-button" role="button" aria-label="'+mejs.i18n.t("mejs.play")+'" aria-pressed="false"></div></div>').appendTo(n).bind("click",(function(){if(a.options.clickToPlayPause){o.paused&&o.play()
var t=e(this).find(".mejs-overlay-button"),i=t.attr("aria-pressed")
t.attr("aria-pressed",!!i)}}))
o.addEventListener("play",(function(){l.hide()
r.hide()
i.find(".mejs-time-buffering").hide()
s.hide()}),false)
o.addEventListener("playing",(function(){l.hide()
r.hide()
i.find(".mejs-time-buffering").hide()
s.hide()}),false)
o.addEventListener("seeking",(function(){r.show()
i.find(".mejs-time-buffering").show()}),false)
o.addEventListener("seeked",(function(){r.hide()
i.find(".mejs-time-buffering").hide()}),false)
o.addEventListener("pause",(function(){mejs.MediaFeatures.isiPhone||l.show()}),false)
o.addEventListener("waiting",(function(){r.show()
i.find(".mejs-time-buffering").show()}),false)
o.addEventListener("loadeddata",(function(){r.show()
i.find(".mejs-time-buffering").show()
mejs.MediaFeatures.isAndroid&&(o.canplayTimeout=window.setTimeout((function(){if(document.createEvent){var e=document.createEvent("HTMLEvents")
e.initEvent("canplay",true,true)
return o.dispatchEvent(e)}}),300))}),false)
o.addEventListener("canplay",(function(){r.hide()
i.find(".mejs-time-buffering").hide()
clearTimeout(o.canplayTimeout)}),false)
o.addEventListener("error",(function(e){a.handleError(e)
r.hide()
l.hide()
s.show()
s.find(".mejs-overlay-error").html("Error loading this resource")}),false)
o.addEventListener("keydown",(function(e){a.onkeydown(t,o,e)}),false)},buildkeyboard:function(t,i,n,o){var a=this
a.container.keydown((function(){a.keyboardAction=true}))
a.globalBind("keydown",(function(i){t.hasFocus=0!==e(i.target).closest(".mejs-container").length&&0===e(i.target).closest(".mejs-keyboard-insulator").length&&e(i.target).closest(".mejs-container").attr("id")===t.$media.closest(".mejs-container").attr("id")
return a.onkeydown(t,o,i)}))
a.globalBind("click",(function(i){t.hasFocus=0!==e(i.target).closest(".mejs-container").length&&0===e(i.target).closest(".mejs-keyboard-insulator").length}))},onkeydown:function(e,t,i){if(e.hasFocus&&e.options.enableKeyboard)for(var n=0,o=e.options.keyActions.length;n<o;n++){var a=e.options.keyActions[n]
for(var r=0,s=a.keys.length;r<s;r++)if(i.keyCode==a.keys[r]){"function"==typeof i.preventDefault&&i.preventDefault()
a.action(e,t,i.keyCode,i)
return false}}return true},findTracks:function(){var t=this,i=t.$media.find("track")
t.tracks=[]
i.each((function(i,n){n=e(n)
t.tracks.push({srclang:n.attr("srclang")?n.attr("srclang").toLowerCase():"",src:n.attr("src"),kind:n.attr("kind"),label:n.attr("label")||"",entries:[],isLoaded:false})}))},changeSkin:function(e){this.container[0].className="mejs-container "+e
this.setPlayerSize(this.width,this.height)
this.setControlsSize()},play:function(){this.load()
this.media.play()},pause:function(){try{this.media.pause()}catch(e){}},load:function(){this.isLoaded||this.media.load()
this.isLoaded=true},setMuted:function(e){this.media.setMuted(e)},setCurrentTime:function(e){this.media.setCurrentTime(e)},getCurrentTime:function(){return this.media.currentTime},setVolume:function(e){this.media.setVolume(e)},getVolume:function(){return this.media.volume},setSrc:function(e){var t=this
if("youtube"===t.media.pluginType){var i
if("string"!==typeof e){var n,o
for(n=0;n<e.length;n++){o=e[n]
if(this.canPlayType(o.type)){e=o.src
break}}}if(-1!==e.lastIndexOf("youtu.be")){i=e.substr(e.lastIndexOf("/")+1);-1!==i.indexOf("?")&&(i=i.substr(0,i.indexOf("?")))}else{var a=e.match(/[?&]v=([^&#]+)|&|#|$/)
a&&(i=a[1])}null!==t.media.getAttribute("autoplay")?t.media.pluginApi.loadVideoById(i):t.media.pluginApi.cueVideoById(i)}else t.media.setSrc(e)},remove:function(){var e,t,i=this
i.container.prev(".mejs-offscreen").remove()
for(e in i.options.features){t=i.options.features[e]
if(i["clean"+t])try{i["clean"+t](i)}catch(e){}}if(i.isDynamic)i.$node.insertBefore(i.container)
else{i.$media.prop("controls",true)
i.$node.clone().insertBefore(i.container).show()
i.$node.remove()}"native"!==i.media.pluginType&&i.media.remove()
delete mejs.players[i.id]
"object"==typeof i.container&&i.container.remove()
i.globalUnbind()
delete i.node.player},rebuildtracks:function(){var e=this
e.findTracks()
e.buildtracks(e,e.controls,e.layers,e.media)},resetSize:function(){var e=this
setTimeout((function(){e.setPlayerSize(e.width,e.height)
e.setControlsSize()}),50)}};(function(){var t=/^((after|before)print|(before)?unload|hashchange|message|o(ff|n)line|page(hide|show)|popstate|resize|storage)\b/
function i(i,n){var o={d:[],w:[]}
e.each((i||"").split(" "),(function(e,i){var a=i+"."+n
if(0===a.indexOf(".")){o.d.push(a)
o.w.push(a)}else o[t.test(i)?"w":"d"].push(a)}))
o.d=o.d.join(" ")
o.w=o.w.join(" ")
return o}mejs.MediaElementPlayer.prototype.globalBind=function(t,n,o){var a=this
var r=a.node?a.node.ownerDocument:document
t=i(t,a.id)
t.d&&e(r).bind(t.d,n,o)
t.w&&e(window).bind(t.w,n,o)}
mejs.MediaElementPlayer.prototype.globalUnbind=function(t,n){var o=this
var a=o.node?o.node.ownerDocument:document
t=i(t,o.id)
t.d&&e(a).unbind(t.d,n)
t.w&&e(window).unbind(t.w,n)}})()
if("undefined"!=typeof e){e.fn.mediaelementplayer=function(t){false===t?this.each((function(){var t=e(this).data("mediaelementplayer")
t&&t.remove()
e(this).removeData("mediaelementplayer")})):this.each((function(){e(this).data("mediaelementplayer",new mejs.MediaElementPlayer(this,t))}))
return this}
e(document).ready((function(){e(".mejs-player").mediaelementplayer()}))}window.MediaElementPlayer=mejs.MediaElementPlayer})(mejs.$)},uwCX:function(e,t){(function(e){e.extend(mejs.MepDefaults,{usePluginFullScreen:true,newWindowCallback:function(){return""},fullscreenText:""})
e.extend(MediaElementPlayer.prototype,{isFullScreen:false,isNativeFullScreen:false,fullscreenMode:"",buildfullscreen:function(t,i,n,o){if(!t.isVideo)return
o.addEventListener("loadstart",(function(){t.detectFullscreenMode()}))
var a=this,r=null,s=a.options.fullscreenText?a.options.fullscreenText:mejs.i18n.t("mejs.fullscreen"),l=e('<div class="mejs-button mejs-fullscreen-button"><button type="button" aria-controls="'+a.id+'" title="'+s+'" aria-label="'+s+'" aria-live="assertive"></button></div>').appendTo(i).on("click",(function(){var e=mejs.MediaFeatures.hasTrueNativeFullScreen&&mejs.MediaFeatures.isFullScreen()||t.isFullScreen
e?t.exitFullScreen():t.enterFullScreen()})).on("mouseover",(function(){if("plugin-hover"==a.fullscreenMode){if(null!==r){clearTimeout(r)
delete r}var e=l.offset(),i=t.container.offset()
o.positionFullscreenButton(e.left-i.left,e.top-i.top,true)}})).on("mouseout",(function(){if("plugin-hover"==a.fullscreenMode){if(null!==r){clearTimeout(r)
delete r}r=setTimeout((function(){o.hideFullscreenButton()}),1500)}}))
t.fullscreenBtn=l
t.fullscreenBtn.setLabel=function(e){var i=mejs.i18n.t(e)
t.fullscreenBtn.find("button").attr("aria-label",i).attr("title",i)}
a.globalBind("keydown",(function(e){27==e.keyCode&&(mejs.MediaFeatures.hasTrueNativeFullScreen&&mejs.MediaFeatures.isFullScreen()||a.isFullScreen)&&t.exitFullScreen()}))
a.normalHeight=a.normalHeight||a.container.height()
a.normalWidth=a.normalWidth||a.container.width()
if(mejs.MediaFeatures.hasTrueNativeFullScreen){var d=function(e){if(t.isFullScreen)if(mejs.MediaFeatures.isFullScreen()){t.isNativeFullScreen=true
t.setControlsSize()}else{t.isNativeFullScreen=false
t.exitFullScreen()}}
t.globalBind(mejs.MediaFeatures.fullScreenEventName,d)}},detectFullscreenMode:function(){var e=this,t="",i=mejs.MediaFeatures
if(i.hasTrueNativeFullScreen&&"native"===e.media.pluginType)t="native-native"
else if(i.hasTrueNativeFullScreen&&"native"!==e.media.pluginType&&!i.hasFirefoxPluginMovingProblem)t="plugin-native"
else if(e.usePluginFullScreen)if(mejs.MediaFeatures.supportsPointerEvents){t="plugin-click"
e.createPluginClickThrough()}else t="plugin-hover"
else t="fullwindow"
e.fullscreenMode=t
return t},isPluginClickThroughCreated:false,createPluginClickThrough:function(){var t=this
if(t.isPluginClickThroughCreated)return
var i,n,o=false,a=function(){if(o){for(var e in r)r[e].hide()
t.fullscreenBtn.css("pointer-events","")
t.controls.css("pointer-events","")
t.media.removeEventListener("click",t.clickToPlayPauseCallback)
o=false}},r={},s=["top","left","right","bottom"],l=function(){var e=fullscreenBtn.offset().left-t.container.offset().left,n=fullscreenBtn.offset().top-t.container.offset().top,o=fullscreenBtn.outerWidth(true),a=fullscreenBtn.outerHeight(true),s=t.container.width(),l=t.container.height()
for(i in r)r[i].css({position:"absolute",top:0,left:0})
r["top"].width(s).height(n)
r["left"].width(e).height(a).css({top:n})
r["right"].width(s-e-o).height(a).css({top:n,left:e+o})
r["bottom"].width(s).height(l-a-n).css({top:n+a})}
t.globalBind("resize",(function(){l()}))
for(i=0,n=s.length;i<n;i++)r[s[i]]=e('<div class="mejs-fullscreen-hover" />').appendTo(t.container).mouseover(a).hide()
fullscreenBtn.on("mouseover",(function(){if(!t.isFullScreen){var e=fullscreenBtn.offset(),n=player.container.offset()
media.positionFullscreenButton(e.left-n.left,e.top-n.top,false)
t.fullscreenBtn.css("pointer-events","none")
t.controls.css("pointer-events","none")
t.media.addEventListener("click",t.clickToPlayPauseCallback)
for(i in r)r[i].show()
l()
o=true}}))
media.addEventListener("fullscreenchange",(function(e){t.isFullScreen=!t.isFullScreen
t.isFullScreen?t.media.removeEventListener("click",t.clickToPlayPauseCallback):t.media.addEventListener("click",t.clickToPlayPauseCallback)
a()}))
t.globalBind("mousemove",(function(e){if(o){var i=fullscreenBtn.offset()
if(e.pageY<i.top||e.pageY>i.top+fullscreenBtn.outerHeight(true)||e.pageX<i.left||e.pageX>i.left+fullscreenBtn.outerWidth(true)){fullscreenBtn.css("pointer-events","")
t.controls.css("pointer-events","")
o=false}}}))
t.isPluginClickThroughCreated=true},cleanfullscreen:function(e){e.exitFullScreen()},containerSizeTimeout:null,enterFullScreen:function(){var t=this
if(mejs.MediaFeatures.isiOS&&mejs.MediaFeatures.hasiOSFullScreen&&"function"===typeof t.media.webkitEnterFullscreen){t.media.webkitEnterFullscreen()
return}e(document.documentElement).addClass("mejs-fullscreen")
t.normalHeight=t.container.height()
t.normalWidth=t.container.width()
"native-native"===t.fullscreenMode||"plugin-native"===t.fullscreenMode?mejs.MediaFeatures.requestFullScreen(t.container[0]):t.fullscreeMode
t.container.addClass("mejs-container-fullscreen").width("100%").height("100%")
t.containerSizeTimeout=setTimeout((function(){t.container.css({width:"100%",height:"100%"})
t.setControlsSize()}),500)
if("native"===t.media.pluginType)t.$media.width("100%").height("100%")
else{t.container.find(".mejs-shim").width("100%").height("100%")
setTimeout((function(){var i=e(window),n=i.width(),o=i.height()
t.media.setVideoSize(n,o)}),500)}t.layers.children("div").width("100%").height("100%")
t.fullscreenBtn&&t.fullscreenBtn.removeClass("mejs-fullscreen").addClass("mejs-unfullscreen")
t.setControlsSize()
t.isFullScreen=true
var i=Math.min(screen.width/t.width,screen.height/t.height)
t.container.find(".mejs-captions-text").css("font-size",100*i+"%")
t.container.find(".mejs-captions-text").css("line-height","normal")
t.container.find(".mejs-captions-position").css("bottom","45px")
t.fullscreenBtn.setLabel("Exit Fullscreen")
t.container.trigger("enteredfullscreen")},exitFullScreen:function(){var t=this
clearTimeout(t.containerSizeTimeout)
mejs.MediaFeatures.hasTrueNativeFullScreen&&(mejs.MediaFeatures.isFullScreen()||t.isFullScreen)&&mejs.MediaFeatures.cancelFullScreen()
e(document.documentElement).removeClass("mejs-fullscreen")
t.container.removeClass("mejs-container-fullscreen").width(t.normalWidth).height(t.normalHeight)
if("native"===t.media.pluginType)t.$media.width(t.normalWidth).height(t.normalHeight)
else{t.container.find(".mejs-shim").width(t.normalWidth).height(t.normalHeight)
t.media.setVideoSize(t.normalWidth,t.normalHeight)}t.layers.children("div").width(t.normalWidth).height(t.normalHeight)
t.fullscreenBtn.removeClass("mejs-unfullscreen").addClass("mejs-fullscreen")
t.setControlsSize()
t.isFullScreen=false
t.container.find(".mejs-captions-text").css("font-size","")
t.container.find(".mejs-captions-text").css("line-height","")
t.container.find(".mejs-captions-position").css("bottom","")
t.fullscreenBtn.setLabel("Enter Fullscreen")
t.container.trigger("exitedfullscreen")}})})(mejs.$)}}])

//# sourceMappingURL=41-c-6ace5eb620.js.map