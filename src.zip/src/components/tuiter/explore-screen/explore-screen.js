import React from "react";
import ExploreComponent from "../ExploreComponent/ExploreComponent";

const ExploreScreen = () => {
    return(


            <div className="row mt-2">

                <div style={{"position": "relative"}}>
                    <ExploreComponent/>
                </div>

            </div>
    );
};
export default ExploreScreen;
