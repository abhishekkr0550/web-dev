import EditProfile from "./edit-profile";

const EditProfileScreen = () => {
    return (
            <div className="row mt-2">

                    <EditProfile/>


            </div>
    );
};
export default EditProfileScreen;