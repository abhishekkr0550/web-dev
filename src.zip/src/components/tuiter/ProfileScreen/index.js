import ProfileComp from "./profile";

const ProfileScreen = () => {

    return (
            <div className="row mt-2">

                    <ProfileComp/>


            </div>
    );
};
export default ProfileScreen;