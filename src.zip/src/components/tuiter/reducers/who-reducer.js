import whoJson from '../data/who.json';

const whoReducer = (state = whoJson) => {
    return(state);
};

export default whoReducer;